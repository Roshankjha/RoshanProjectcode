/**********************************************************************************
 * Class-name - MyApp
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MyApp page. 
 * MyApp have methods implementation to perform  initializeApp,connectToWebSocketForChat,logout
 * sessionRefresh and refreshSessionDialog
 *
 **********************************************************************************/
import { Component, ViewChild, NgZone } from '@angular/core';
import { Nav, Platform, LoadingController, App, Events } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';

import { HomePage } from '../pages/home/home';
import { DigitalLibraryPage } from '../pages/digital-library/digital-library';
import { AssessmentPage } from '../pages/assessment/assessment';
import { NotificationsPage } from '../pages/notifications/notifications';
import { LoginPage } from '../pages/login/login';
import { ApiProvider } from '../providers/api/api';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { FriendListPage } from '../pages/friend-list/friend-list';
import { WebSocketConnectionProvider } from '../providers/web-socket-connection/web-socket-connection';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { SplashPage } from '../pages/splash/splash';
import { MockTestPage } from '../pages/mock-test/mock-test';
import { AllNotesPage } from '../pages/all-notes/all-notes';
import { UpdateValidatorProvider } from '../providers/update-validator/update-validator';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any;

  pages: Array<{title: string, component: any, icon: any}>;

  jsonStirng:any;
  logoutApiCall:any;

  clientIpAddress:any;
  sessionRefreshApiCall:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  userName:any;
  userEmail:any;
  userImage:any;
  friendsId:any;

  currentActivePage:any;

  constructor(public platform: Platform, public statusBar: StatusBar, public events: Events,public apiProvider :ApiProvider,
  public loading: LoadingController,private network: Network,public app: App,public websocket:WebSocketConnectionProvider,
  private _ngZone: NgZone,private localNotifications: LocalNotifications,public updateVallidator:UpdateValidatorProvider) {
    this.initializeApp();
    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Home', component: HomePage, icon:'md-home' },
      { title: 'Digital Library', component: DigitalLibraryPage,icon: 'md-book' },
      { title: 'Assessment', component: AssessmentPage, icon: 'md-copy' },
      { title: 'Mock Test', component: MockTestPage, icon: 'md-cog' },
      { title: 'Notification', component: NotificationsPage, icon:'md-notifications' },
      { title: 'Chat', component: FriendListPage, icon: 'chatbubbles' },
      { title: 'My Notes', component: AllNotesPage, icon: 'clipboard' }
    ];

    events.subscribe('chat:friend', (friendId) => {
      this.friendsId=friendId;
    });
    app.viewDidEnter.subscribe((view) => {
      this.currentActivePage = view.instance.constructor.name;
    });
   
  }

  /**
   * Start an event when the menu is closed
   */
  menuClosed(){
    this.events.publish('menu:closed', '');
  }
  /**
   * Start an event when the menu is open
   */
  menuOpened(){
    this.events.publish('menu:opened', '');
  }
  /**
   * In the checkNetwork method there are two subscriptions.
   * Each subscription checks for the network availability and
   * stores the value as online in data if network is available and
   * stores the value as offline in data if network is not available.
   */
  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.updateVallidator.networkUpdateToast(data.type);
    // for checking Network to again subscribe the FriendID
    this.events.subscribe('chat:friend', (friendId) => {
      this.friendsId=friendId;
    });
      this.connectToWebSocketForChat();
    }, error => console.error(error)); 
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.websocket.closeSession();
      this.networkType=data.type;
      this.updateVallidator.connectionErrorAlert("Connection Dismissed","Check your connection and try again later");
    },error => console.error(error));
  }
  /**
   * ionViewWillLeave is a life cycle method where the subscribed methods will be unsubscribed
   *  when the  ionview leaves.
   */
  ionViewWillLeave(){
    this.events.unsubscribe('chat:friend');
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

  ionViewDidLeave(){
    this.websocket.closeSession();
  }

  /**
   * Here the initializeApp is called to check platform reay are not,once platform ready
   * then it will check checkNetwork,checkAuthentication and connectToWebSocketForChat
   */
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.rootPage = SplashPage;
      this.checkNetwork();
      this.events.subscribe('user:created', () => {
        this.userName=window.localStorage.getItem('user_name');
        this.userEmail=window.localStorage.getItem('user_email');
        this.userImage =this.apiProvider.fileAccessURL+ window.localStorage.getItem('userImagePath');
        this.connectToWebSocketForChat();
      });
    }); 
  }
  
  /**
   * Reset the content nav to have just this page
   * we wouldn't want the back button to show in this scenario
   * @param page 
   */
  openPage(page) {
    this.nav.setRoot(page.component);
  }
  
  /**
   *  Here the connectToWebSocketForChat is called to connect the web socket connection
   * and recive the server notification message then send push notification message
   */
  connectToWebSocketForChat(){
    this.websocket.GetInstanceStatus().subscribe((result) => {
      this._ngZone.run(() => {
          let serverMsg=JSON.parse(result)
          this.events.publish('chat:dataArrived', serverMsg);
          if(this.currentActivePage === 'ChatPage'){
            if(this.friendsId == serverMsg.id){
            }else{
                this.localNotifications.schedule({  // for push notification 
                id: serverMsg.id,
                title: serverMsg.name,
                text: serverMsg.message,
                data:{mydata:"My Notification message this is"} 
              });
            }
          }else if(this.currentActivePage === 'FriendListPage'){

          }else{
            this.localNotifications.schedule({
              id: serverMsg.id,
              title: serverMsg.name,
              text: serverMsg.message,
              data:{mydata:"My Notification message this is"} 
            });
          }
       });
    });
  }
  /**
   * Here the logout service is called to sign of the session
   * jsonStirng : constructing json string
   * @param userId
   * @param ThreadId
   * apiProvider : to connect the server and get the data
   * @param url
   * @param requestMapping('String')
   * @param jsonString ('String')
   * @param requestMethod(POST/GET)
   */
  logout(){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("No Internet Connection","Try again after sometime");
    }
    else{
      let loader = this.loading.create({content : "Logging you out..."});  
      loader.present().then(() => {
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"ThreadId":window.localStorage.getItem('threadid')};
        this.logoutApiCall = this.apiProvider.post('logout',this.jsonStirng,'POST');
        this.logoutApiCall.subscribe(data => {
          if(data.Logout==="Success"){           
            window.localStorage.clear();
            this.events.unsubscribe('user:created', ()=>{
              this.websocket.closeSession();
            });
            this.websocket.closeSession();
            loader.dismiss();          
            this.nav.setRoot(LoginPage);
          }
          else if(data.Logout==="Failure"){         
            loader.dismiss();
          }
        }, (err) => {        
          loader.dismiss();
        });
      });
    }
  }
}
