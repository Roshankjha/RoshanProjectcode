/* List of all default angular and ionic components*/
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { HttpClientModule } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';
import { DatePipe } from '@angular/common';
/* List of all cordova plugins*/
import { FileTransfer } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { YoutubeVideoPlayer } from '@ionic-native/youtube-video-player'
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';
import { Network } from '@ionic-native/network';
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { Device } from '@ionic-native/device';
import { LocalNotifications } from '@ionic-native/local-notifications';
/* List of all external plugins*/
import { QuillModule } from 'ngx-quill'
import { PdfViewerModule } from 'ng2-pdf-viewer';
/* List of all providers*/
import { ApiProvider } from '../providers/api/api';
import { UpdateValidatorProvider } from '../providers/update-validator/update-validator';
import { WebSocketConnectionProvider } from '../providers/web-socket-connection/web-socket-connection';
/* List of all pages*/
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { DigitalLibraryPage } from '../pages/digital-library/digital-library';
import { AssessmentPage } from '../pages/assessment/assessment';
import { NotificationsPage } from '../pages/notifications/notifications';
import { NotificationDetailsPage } from '../pages/notification-details/notification-details';
import { ChatPage } from '../pages/chat/chat';
import { LoginPage } from '../pages/login/login';
import { ProgramCoursesPage } from '../pages/program-courses/program-courses';
import { CourseContentPage } from '../pages/course-content/course-content';
import { ContentDetailsPage } from '../pages/content-details/content-details';
import { AssessmentCourseContentPage } from '../pages/assessment-course-content/assessment-course-content';
import { AssessmentContentDetailsPage } from '../pages/assessment-content-details/assessment-content-details';
import { FilterPage } from '../pages/filter/filter';
import { EventDetailsPage } from '../pages/event-details/event-details';
import { FriendListPage } from '../pages/friend-list/friend-list';
import { SplashPage } from '../pages/splash/splash';
import { MyNotesPage } from '../pages/my-notes/my-notes';
import { NoteDetailsPage } from '../pages/note-details/note-details';
import { CreateNotePage } from '../pages/create-note/create-note';
import { NoteInfoPage } from '../pages/note-info/note-info';
import { AllNotesPage } from '../pages/all-notes/all-notes';
import { ShareViaEmailPage } from '../pages/share-via-email/share-via-email';
import { MockTestPage } from '../pages/mock-test/mock-test';
import { MockTestContentPage } from '../pages/mock-test-content/mock-test-content';
import { MockTestEvaluatedPage } from '../pages/mock-test-evaluated/mock-test-evaluated';
import { MockTestInfoPage } from '../pages/mock-test-info/mock-test-info';
import { MockTestOnlineQuizPage } from '../pages/mock-test-online-quiz/mock-test-online-quiz';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    HomePage,
    DigitalLibraryPage,
    AssessmentPage,
    NotificationsPage,
    NotificationDetailsPage,
    ChatPage,
    ProgramCoursesPage,
    CourseContentPage,
    ContentDetailsPage,
    AssessmentCourseContentPage,
    AssessmentContentDetailsPage,
    FilterPage,
    EventDetailsPage,
    FriendListPage,
    SplashPage,
    MyNotesPage,
    NoteDetailsPage,
    CreateNotePage,
    NoteInfoPage,
    AllNotesPage,
    ShareViaEmailPage,
    MockTestPage,
    MockTestContentPage,
    MockTestEvaluatedPage,
    MockTestInfoPage,
    MockTestOnlineQuizPage,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    PdfViewerModule,
    QuillModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    HomePage,
    DigitalLibraryPage,
    AssessmentPage,
    NotificationsPage,
    NotificationDetailsPage,
    ChatPage,
    ProgramCoursesPage,
    CourseContentPage,
    ContentDetailsPage,
    AssessmentCourseContentPage,
    AssessmentContentDetailsPage,
    FilterPage,
    EventDetailsPage,
    FriendListPage,
    SplashPage,
    MyNotesPage,
    NoteDetailsPage,
    CreateNotePage,
    NoteInfoPage,
    AllNotesPage,
    ShareViaEmailPage,
    MockTestPage,
    MockTestContentPage,
    MockTestEvaluatedPage,
    MockTestInfoPage,
    MockTestOnlineQuizPage,
  ],
  providers: [
    Network,
    StatusBar,
    SplashScreen,
    FileTransfer,
    AndroidPermissions,
    File,
    FilePath,
    FileChooser,
    YoutubeVideoPlayer,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ApiProvider,
    WebSocketConnectionProvider,
    DatePipe,
    LocalNotifications,
    ScreenOrientation,
    Device,
    UpdateValidatorProvider
  ]
})
export class AppModule {}
