/**********************************************************************************
 * Class-name - AllNotes
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the AllNotes page. 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, ModalController, MenuController, Events } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { HomePage } from '../home/home';
import { File } from '@ionic-native/file';
import { ContentDetailsPage } from '../content-details/content-details';

import { ShareViaEmailPage } from '../share-via-email/share-via-email';
import { NoteDetailsPage } from '../note-details/note-details';
import { Network } from '@ionic-native/network';
import { Subscription } from 'rxjs/Subscription';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';


@IonicPage()
@Component({
  selector: 'page-all-notes',
  templateUrl: 'all-notes.html',
})
export class AllNotesPage {

  noteListType:string="text";

  headerList:any;
  hideNoNotes_TextList:boolean=true;
  hideNoNotes_FreehandList:boolean=true;

  jsonStirng:any;
  allNoteListApiCall:any;
  deleteNoteApiCall:any;
  editAllNoteApiCall:any;
  exportNoteApiCall:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  fileTransfer: FileTransferObject = this.transfer.create();

  imagepath:any;

  menuOpened:boolean;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,public loading: LoadingController,
  public apiProvider: ApiProvider,public modalCtrl: ModalController,private file: File,public updateVallidator:UpdateValidatorProvider,
  private network: Network,private androidPermissions: AndroidPermissions,private transfer: FileTransfer,
  public events: Events,public menuCtrl: MenuController) {
    this.checkNetwork();
    this.getListOfAllNotes();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });

    this.imagepath = this.apiProvider.fileAccessURL;
  }

  /*
  This method is used to perform the back action which goes to the previous page on clicking 
  the back button in the device.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }else{
        this.navCtrl.setRoot(HomePage);
      }
    });
  }

  /*
  This method there are two subscriptions.
  Each subscription checks for the network availability and 
  stores the value as online in data if network is available and
  stores the value as offline in data if network is not available.
  */
  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
 
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }

  /**
   * This method is used to call the service to edit the note details
   * @param roleId
   * @param noteId
   * @returns editnotelist 
   */
  edit(item){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng = { "roleId":window.localStorage.getItem('roleid'),"noteId":item.noteId};
      this.editAllNoteApiCall = this.apiProvider.post('editNote',this.jsonStirng,'POST');
      this.editAllNoteApiCall.subscribe(data =>{
        if(JSON.parse(data.EditNoteList).length > 0){
          this.navCtrl.push(ContentDetailsPage,{
            fromPage:"AllNotesPage",
            item:JSON.parse(data.EditNoteList)[0]
          });
        }else{
         
        }
        loader.dismiss();
      }, (err) => {
        console.log(err);
        loader.dismiss();
      });
    });
  }

  /**
   * This method is used to convert the string or note data from server into pdf format
   * @param item 
   */
  export(item){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      let loader = this.loading.create({content : "Exporting your content..."});
      loader.present().then(() => {
        this.jsonStirng = { "noteId":item.noteId,"roleLevelId": window.localStorage.getItem('rolelevelid')};
        this.exportNoteApiCall = this.apiProvider.post('getPdfExport',this.jsonStirng,'POST');
        this.exportNoteApiCall.subscribe(data =>{
          console.log("export response : ",data);
          console.log("file URL : ",data.FilePath);
          loader.dismiss();
          this.downloadPDF(item.noteTitle,data.FilePath);
        }, (err) => {
          console.log("export response : ",err);
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Error in fetching data from server");
        });
      });
    }
  }

 /**
  * This method is used to download pdf file and save to device
  * @param item 
  */
  downloadPDF(filename,fileURL){
    let loader = this.loading.create({content : "Downloading your file..."});
    loader.present().then(() => {
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );
      const dnldURL = this.apiProvider.fileAccessURL+fileURL.replace(/\s/g, "%20");
      var destfolder = this.file.externalApplicationStorageDirectory+ '/Download/MyNotes/' + filename+".pdf";
      this.fileTransfer.download(dnldURL, destfolder,true).then((entry) => {
        this.updateVallidator.downloadUpdateAlert("Export Successful","File is exproted to Android/data/com.srmri.atihaLMS/Download/MyNotes",destfolder,true);
        loader.dismiss();
      }, (error) => {
        this.updateVallidator.downloadUpdateAlert("Export Failed","File export failed due to server error","",false);
        loader.dismiss();
      });
    });
  }

  exportFh(item){
    let loader = this.loading.create({content : "Exporting your content..."});
    loader.present().then(() => {
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );
      const dnldURL = this.apiProvider.fileAccessURL+item.noteHandwritingImage.replace(/\s/g, "%20");
      const destfolder = this.file.externalApplicationStorageDirectory+ '/Download/MyNotes/' + item.noteTitle+".png";
      this.fileTransfer.download(dnldURL, destfolder,true).then((entry) => {
        this.updateVallidator.downloadUpdateAlert("Export Successful","File is exproted to Android/data/com.srmri.atihaLMS/Download/MyNotes",destfolder,true);
        loader.dismiss();
      }, (error) => {
        this.updateVallidator.downloadUpdateAlert("Export Failed","File export failed due to server error","",false);
        loader.dismiss();
      });
    });
  }

  /**
   * This method is used to navigate share via emial page
   * @param item 
   */
  share(item){
    let modelCtrl = this.modalCtrl.create(ShareViaEmailPage,{item:item});
    modelCtrl.present({});
  }

 /**
   * This method is used to call service to delete the note
   * @param roleId
   * @param noteId 
   * @returns note deleted successfully/failed 
   */
  delete(item){
    let loader = this.loading.create({content : "Deleting ,please wait..."});
    loader.present().then(() => {
      this.jsonStirng = { "roleId":window.localStorage.getItem('roleid'),"noteId":item.noteId};
      this.deleteNoteApiCall = this.apiProvider.post('deleteNote',this.jsonStirng,'POST');
      this.deleteNoteApiCall.subscribe(data =>{
        loader.dismiss();
        if(data.message==="Note deleted successfully!!"){
          this.updateVallidator.deleteUpdate("Note Deletion",data.message);
          for(let i = 0; i < this.headerList.length; i++){
            var header = this.headerList[i];
            for(let j=0;j<header.myNotesbean.length;j++){
              if(header.myNotesbean[j] == item){
                header.myNotesbean.splice(j, 1);
              }
            }
          }
        }
        else{
          this.updateVallidator.deleteUpdate("Note Deletion",data.message);
        }
      },(err) => {
        loader.dismiss();
        this.updateVallidator.deleteUpdate("Note Deletion","Error in deleting note..try again later");
      });
    });
  }

  /**
   * show the details of the note in a popover/modals
   * @param item 
   */
  noteDetails(item){
    let modelCtrl = this.modalCtrl.create(NoteDetailsPage,{
      fromPage:"AllNotes",
      Item:item
    });
    modelCtrl.present({
    });
  }

  /**
   * This method for calling service to get the all notes data
   * @param roleLevelId
   * @returns NotePageList
   */
  getListOfAllNotes(){
    let loader = this.loading.create({content : "Fetching notes ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng = { "roleLevelId":window.localStorage.getItem('rolelevelid')};
      this.allNoteListApiCall = this.apiProvider.post('MyNotes',this.jsonStirng,'POST');
      this.allNoteListApiCall.subscribe(data =>{
        if(data.NoteList===""){
          this.hideNoNotes_TextList = false;
        }else{
          this.headerList = JSON.parse(data.NoteList);
          console.log("AllnoteList : ",this.headerList);
        }
        loader.dismiss();
      }, (err) => {
        loader.dismiss();
      });
    });
  }
}
