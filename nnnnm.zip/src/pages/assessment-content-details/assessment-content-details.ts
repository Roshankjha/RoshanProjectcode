/**********************************************************************************
 * Class-name - AssessmentContentDetailsPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the AssessmentContentDetailsPage page. 
 * AssessmentContentDetailsPage have methods implementation to, 
 * display in detail about the content available on the particular course and content.
 * It also displays any contents if available e.g PDF.
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, LoadingController } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FileTransferObject, FileTransfer } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { ApiProvider } from '../../providers/api/api';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-assessment-content-details',
  templateUrl: 'assessment-content-details.html',
})
export class AssessmentContentDetailsPage {
  item: any;
  contentTypeName: any;

  pdfURL:string;

  fileTransfer: FileTransferObject = this.transfer.create();
  fileToBeDownloadedFrom:string;
  downloadurl:any;

  hideAssignmentContainer:boolean=true;
  hideAssignmentTable:boolean=true;
  hideAssignmentSubmissionTable:boolean=true;
  hideExamTestContainer:boolean=true;
  hidedownload:boolean=true;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,private apiProvider:ApiProvider,
    private network: Network,private file: File,public updateVallidator:UpdateValidatorProvider,
    private androidPermissions: AndroidPermissions,public loading: LoadingController,private transfer: FileTransfer) {
    this.checkNetwork();
    this.item = navParams.get('item');
    this.contentTypeName = navParams.get('contentTypeName');
    this.pdfURL = this.apiProvider.fileAccessURL + this.item.filePath;
    this.validateUI();
  }
/*
This method is used to perform the back action which goes to the previous page on clicking 
the back button in the device.
*/
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
  /*
  This method is used to display the corresponding container.
  There are different containers one for Assignment, test and for exam.
  The container whose condition is true will be displayed and the others will be hidden.
  */
  validateUI(){
    if(this.contentTypeName==='view_all_assignments'||this.contentTypeName==='view_opened_Assignments'){
      this.hideAssignmentContainer = false;
      this.hideExamTestContainer = true;
      this.hideAssignmentTable = false;
      this.hideAssignmentSubmissionTable = true;
      this.hidedownload = false;
    }
    else if(this.contentTypeName==='view_my_assignment_submissions'){
      this.hideAssignmentContainer = false;
      this.hideExamTestContainer = true;
      this.hideAssignmentTable = true;
      this.hideAssignmentSubmissionTable = false;
      this.hidedownload = true;
    }
    else if(this.contentTypeName==='view_all_tests'||this.contentTypeName==='view_all_exams'){
      this.hideAssignmentContainer = true;
      this.hideExamTestContainer = false;
    }
  }
/*
This method is there are two subscriptions.
Each subscription checks for the network availability and 
stores the value as online in data if network is available and
stores the value as offline in data if network is not available.
*/
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.pdfURL = this.apiProvider.fileAccessURL + this.item.filePath;
    }, error => console.error(error));
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /*
  This method is where the subscribed methods will be unsubscribed when the 
  ionview leaves.
  */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

/**
* This method check network type offline/online .
* if offline show error message'Check your connection and try again later'.otherwise download file
* and check androidPermissions 
*/
  downloadFile(){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE));
        
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        if(this.item.fileName===""){
          this.updateVallidator.serverErrorAlert("Server Error","File Does not Exist");
        }else{
          this.fileToBeDownloadedFrom = this.item.filePath;    
          this.downloadurl = this.apiProvider.fileAccessURL+this.fileToBeDownloadedFrom.replace(/\s/g, "%20");
          var destPath = this.file.externalApplicationStorageDirectory+ '/Download/Assignments/' + this.item.fileName;
          this.fileTransfer.download(this.downloadurl,destPath,true).then((entry) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Successfull","File is downloaded to Android/data/com.srmri.atihaLMS/Download/Assignments",destPath,true);
          }, (error) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Failed","File is failed/interupted due to some error in server","",false);
          });
        }
      });
    }
  }
}
