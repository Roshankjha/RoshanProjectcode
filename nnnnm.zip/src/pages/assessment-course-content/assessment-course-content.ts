/**********************************************************************************
 * Class-name - AssessmentCourseContentPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the AssessmentCourseContentPage page. 
 * AssessmentCourseContentPage have methods implementation to display courses available, download and upload.
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform } from 'ionic-angular';
import { Item } from '../../models/item';
import { ApiProvider } from '../../providers/api/api';
import { AssessmentContentDetailsPage } from '../assessment-content-details/assessment-content-details';
import { FileChooser } from '@ionic-native/file-chooser';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FileTransfer, FileTransferObject, FileUploadOptions } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { FilePath } from '@ionic-native/file-path';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-assessment-course-content',
  templateUrl: 'assessment-course-content.html',
})
export class AssessmentCourseContentPage{
  item: any;
  jsonStirng:any;
  public courseContent: any[];
  courseCont:any;  
  contentTypeName: any;
  currentItems: Item[];
  testExamLastfieldName : String;
  hideAssignments:boolean = true;
  hideAssignmentSubmission:boolean = true;
  hideTestOrExams:boolean = true;
  hideTestOrExamMarks:boolean = true;
  hidedownloadBtn:boolean = true;
  hideUploadBtn:boolean = true;

  selectedFileURI:any;
  selectedFileName:any;
  filePathName: string;
  fileToBeDownloadedFrom:string;
  fileTransfer: FileTransferObject = this.transfer.create();

  nodataText:string="";

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,
    public loading: LoadingController,public apiProvider: ApiProvider,public fileChooser: FileChooser,
    private transfer: FileTransfer,private file: File,private filePath: FilePath,private androidPermissions: AndroidPermissions,
    private network: Network,public updateVallidator:UpdateValidatorProvider) {

    this.checkNetwork();
      
    this.item = navParams.get('item');
    this.contentTypeName = navParams.get('contentTypeName');
    this.toggleListUI(this.contentTypeName);
    this.hideAndShowSlidingButtons(this.contentTypeName);
    this. assessmentCourseContentServiceCall();
  }
  /*
This method is used to perform the back action which goes to the previous page on clicking 
the back button in the device.
*/
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
/*
This method there are two subscriptions.
Each subscription checks for the network availability and 
stores the value as online in data if network is available and
stores the value as offline in data if network is not available.
*/
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this. assessmentCourseContentServiceCall();
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /*
  This method where the subscribed methods will be unsubscribed when the 
  ionview leaves.
  */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
/*  This method is invoked when the upload button is clicked.
It initially checks for the network connection, if its online it asks to select the file else it will 
send a toast message "Check your connection and try again later". 
Else it asks the user to select the path to upload the file. HAving selected the path and file the uploading happens

*/
  selectFile(item: Item){
    if(item.status==="Closed"){
      this.updateVallidator.serverErrorAlert("Assignmnet is closed","You cannot upload file to this assignment as the assignment status is closed");
    }else{
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      this.fileChooser.open().then(uri => {
        this.filePath.resolveNativePath(uri).then((filePath) => {
            this.filePathName =filePath.substring(filePath.lastIndexOf("/")+1);                
            let options: FileUploadOptions = {
              fileKey: 'file',
              fileName:this.filePathName,
              chunkedMode : false,
              params: {       
                userId:window.localStorage.getItem('userid'),
                roleId:window.localStorage.getItem('roleid'),
                assignmentId:item.assignmentId,
                assignmentType:'open'          
              }
            }
            let loader = this.loading.create({content : "Loading ,please wait..."});  
            loader.present().then(() => {
              this.fileTransfer.upload(uri, this.apiProvider.url+'uploadAssignmentSubmission', options).then((data) => {
                loader.dismiss();
                this.updateVallidator.uploadUpdateAlert("File Upload Successful","Your file "+this.filePathName+" is uploaded successfully");
              },(err)=>{
                loader.dismiss();
                this.updateVallidator.uploadUpdateAlert("File Upload Failed","Error in uploading ... Please try again");
              });   
            });
        }, (err) => { 
          this.updateVallidator.fileSelectionErrorToast(this.filePathName,"corrupted !!!!");    
        })
      }).catch(e => console.log(e));
    }
  }
  }

/*
This method is invoked when the download button is clicked.
It initially checks for the network connection, if its online it starts download else it will send a toast message 
"Check your connection and try again later". Else it checks for permission to access the external storage and
starts downloading.  
*/
  download(item: Item){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );
  
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        if(item.fileName===""){
          this.updateVallidator.serverErrorAlert("Server Error","File Does not Exist");
          //this.downloadUpdateToast("File Does not Exist",false);
        }else{
          this.fileToBeDownloadedFrom = item.filePath;
          const url = this.apiProvider.fileAccessURL+this.fileToBeDownloadedFrom.replace(/\s/g, "%20");
          var destPath = this.file.externalApplicationStorageDirectory+ '/Download/Assignments/' + item.fileName;
          this.fileTransfer.download(url,destPath,true).then((entry) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Successfull","File is downloaded to Android/data/com.srmri.atihaLMS/Download/Assignments",destPath,true);
            //this.downloadUpdateToast(item.fileName,true);
          }, (error) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Failed","File is failed/interupted due to some error in server","",false);
            //this.downloadUpdateToast("File is corrupted",false);
          });
        }
      });
    }
  }
/*
This method is used to navigate to assessment content detail page
 On click of any of the course content 
*/
  goToAssessmentContentDetails(item: Item){
    if (!item) item = {};
    if(this.contentTypeName==='student_test_marks'|| this.contentTypeName==='student_exam_marks'){
      // Show toast that no details to show
    }else{
      this.navCtrl.push(AssessmentContentDetailsPage,{
        item: item,
        contentTypeName : this.contentTypeName
      });
    }
  }
/*
This method is used to display either of the pages among view all assignments,
view opened assignments, view my assignment submission, view all tests,view all exams, student test marks &
student exam marks.
*/
  toggleListUI(type:String){
    if(type === 'view_all_assignments'){
      this.hideAssignments= false;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = true;
      this.hideTestOrExamMarks = true;
    }
    if(type === 'view_opened_Assignments'){
      this.hideAssignments= false;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = true;
      this.hideTestOrExamMarks = true;
    }
    if(type === 'view_my_assignment_submissions'){
      this.hideAssignments= true;
      this.hideAssignmentSubmission = false;
      this.hideTestOrExams = true;
      this.hideTestOrExamMarks = true;
    }
    if(type === 'view_all_tests'){
      this.hideAssignments= true;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = false;
      this.hideTestOrExamMarks = true;
    }
    if(type === 'view_all_exams'){
      this.hideAssignments= true;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = false;
      this.hideTestOrExamMarks = true;
    }
    if(type === 'student_test_marks'){
      this.hideAssignments= true;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = true;
      this.hideTestOrExamMarks = false;
    }
    if(type === 'student_exam_marks'){
      this.hideAssignments= true;
      this.hideAssignmentSubmission = true;
      this.hideTestOrExams = true;
      this.hideTestOrExamMarks = false;
    }
  }
/*
This method having the sliding option available in the course content page of each page.
Here the user can upload or download using the upload or download button which appears on sliding the list item from 
right to left.
*/
  hideAndShowSlidingButtons(type:String){
    if(type === 'view_all_assignments'){
      this.hidedownloadBtn = false;
      this.hideUploadBtn = true;
    }
    else if(type === 'view_opened_Assignments'){
      this.hidedownloadBtn = false;
      this.hideUploadBtn = false;
    }
    else if(type === 'view_my_assignment_submissions'){
      this.hidedownloadBtn = false;
      this.hideUploadBtn = true;
    }
    else if(type === 'view_all_tests'){
      this.hidedownloadBtn = true;
      this.hideUploadBtn = true;
    }
    else if(type === 'view_all_exams'){
      this.hidedownloadBtn = true;
      this.hideUploadBtn = true;
    }
    else if(type === 'student_test_marks'){
      this.hidedownloadBtn = true;
      this.hideUploadBtn = true;
    }
    else if(type === 'student_exam_marks'){
      this.hidedownloadBtn = true;
      this.hideUploadBtn = true;
    }
  }

/*
This Service Call is mainly used to populate the lists with all the program courses,
course content and the details of content in the content detail page. 
*/
  assessmentCourseContentServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      if (this.contentTypeName=="view_all_assignments") {
        this.jsonStirng={"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId,"courseClass":this.item.courseClass};
        this.courseCont = this.apiProvider.post('qaGetStudentFilterAssignmentList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => { 
          this.courseContent = JSON.parse(data.assignmentContentList);   
          loader.dismiss();
          if(this.courseContent.length==0){
            this.nodataText = "No Assignments Found";
          }else{this.nodataText = "";} 
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="view_opened_Assignments") {
        this.jsonStirng={"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId,"courseClass":this.item.courseClass};
        this.courseCont = this.apiProvider.post('qaGetStudentFilterOpenAssignmentList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => { 
          this.courseContent = JSON.parse(data.assignmentContentList);   
          loader.dismiss();   
          if(this.courseContent.length==0){
            this.nodataText = "No Opened Assignments Found";
          }else{this.nodataText = "";} 
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="view_my_assignment_submissions") {
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid'),"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId,"courseClass":this.item.courseClass};
        this.courseCont = this.apiProvider.post('qaGetMyStudentAssignmentSubmissions',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => {
          this.courseContent = JSON.parse(data.assignmentSubmissionContentList);  
          loader.dismiss();
          if(this.courseContent.length==0){
            this.nodataText = "No Assignment Submission Found";
          }else{this.nodataText = "";}    
        },(err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="view_all_tests") {
        this.jsonStirng={"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId,"courseClass":this.item.courseClass};
        this.courseCont = this.apiProvider.post('qaGetStudentFilteredTestList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => {
          this.courseContent = JSON.parse(data.testContentList);  
          loader.dismiss();
          if(this.courseContent.length==0){
            this.nodataText = "No Tests Found";
          }else{this.nodataText = "";}
        },(err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="student_test_marks") {
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId,"courseClass":this.item.courseClass};
        this.courseCont = this.apiProvider.post('qaGetStudentFilteredTestMarksList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => {
          this.courseContent = JSON.parse(data.testMarksList);    
          loader.dismiss();   
          if(this.courseContent.length==0){
            this.nodataText = "No Test Marks Found";
          }else{this.nodataText = "";} 
        },(err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="view_all_exams") {
        this.jsonStirng={"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId};
        this.courseCont = this.apiProvider.post('qaGetStudentFilteredExamList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => {
          this.courseContent = JSON.parse(data.examContentList);  
          loader.dismiss();     
          if(this.courseContent.length==0){
            this.nodataText = "No Exams Found";
          }else{this.nodataText = "";}
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if (this.contentTypeName=="student_exam_marks") {
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"programCourseMapId":this.item.programCourseMapId,"courseDepartmentMapId":this.item.courseDepartmentMapId};
        this.courseCont = this.apiProvider.post('qaGetStudentFilteredExamMarksList',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data => {
          this.courseContent = JSON.parse(data.examMarksList);   
          loader.dismiss();     
          if(this.courseContent.length==0){
            this.nodataText = "No Exam Marks Found";
          }else{this.nodataText = "";}
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }
    });
  }
}
