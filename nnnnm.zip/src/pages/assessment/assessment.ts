/**********************************************************************************
 * Class-name - AssessmentPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology
 *  and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the AssessmentPage page. 
 * AssessmentPage have methods implementation to display assignments,test and exams.
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, Events, MenuController } from 'ionic-angular';
import { ProgramCoursesPage } from '../program-courses/program-courses';
import { Network } from '@ionic-native/network';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-assessment',
  templateUrl: 'assessment.html',
})
export class AssessmentPage {
  assignmentListItems: any[];
  testListItems: any[];
  examListItems: any[];

  hideAssignments:boolean=true;
  hideTest:boolean=true;
  hideExam:boolean=true;

  assessmentIcon: string = "add";
  testIcon: string = "add";
  examIcon: string = "add";

  menuOpened:boolean;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,
  public loading: LoadingController,public network: Network,public events: Events,public menuCtrl: MenuController) {
    this.loadUI();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });
  }
/*
This method is used to perform the back action which goes to the Home Page on clicking 
the back button in the device.
*/
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }else{
        this.navCtrl.setRoot(HomePage);
      }
    });
  }
/*
This method is used to load the list of options available in Assignment,Test and Exam.
*/
  loadUI() {
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.assignmentListItems = [
        {
          "title":"View All Assignments",
          "id":"view_all_assignments"
        },
        {
          "title":"View Opened Assignments",
          "id":"view_opened_Assignments"
        },
        {
          "title":"View My Assignment Submissions",
          "id":"view_my_assignment_submissions"
        }
      ];
  
      this.testListItems = [
        {
          "title":"View All Tests",
          "id":"view_all_tests"
        },
        {
          "title":"Student Test Marks",
          "id":"student_test_marks"
        }
      ];
  
      this.examListItems = [
        {
          "title":"View All Exams",
          "id":"view_all_exams"
        },
        {
          "title":"Student Exam Marks",
          "id":"student_exam_marks"
        }
      ];
      loader.dismiss();
    });
  }
/*
This method is used to view the list of options available in Exam on click of the toggle button.
*/
  toggleAssignment(){
    this.hideAssignments = !this.hideAssignments;
    if (this.assessmentIcon === 'remove') {
      this.assessmentIcon = "add";
    }else if (this.assessmentIcon === 'add') {
      this.assessmentIcon = "remove";
    }
  }
/*
This method is used to view the list of options available in Exam on click of the toggle button.
*/
  toggleTest(){
    this.hideTest = !this.hideTest;
    if (this.testIcon === 'remove') {
      this.testIcon = "add";
    }else if (this.testIcon === 'add') {
      this.testIcon = "remove";
    }
  }
/*
This method is used to view the list of options available in Exam on click of the toggle button.
*/
  toggleExam(){
    this.hideExam = !this.hideExam;
    if (this.examIcon === 'remove') {
      this.examIcon = "add";
    }else if (this.examIcon === 'add') {
      this.examIcon = "remove";
    }
  }
/*
This method is used On click of any options available in Assignments,Test & Exam
The user will be navigated to the program courses page which displays the list of all courses available.
*/
  goToProgramCourses(item){
    this.navCtrl.push(ProgramCoursesPage,{
      contentType: item,
      fromPage:'Assessment',
      contentModule:'assessment'
    });
  }
}
