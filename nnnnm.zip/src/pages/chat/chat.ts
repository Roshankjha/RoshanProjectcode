/**********************************************************************************
 * Class-name - ChatPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the ChatPage page. 
 * ChatPage have methods implementation to perform the chat and chat history load.  
 *
 **********************************************************************************/
import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Content, Events, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { DatePipe } from '@angular/common';
import { WebSocketConnectionProvider } from '../../providers/web-socket-connection/web-socket-connection';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html',
})
export class ChatPage{
  @ViewChild(Content) content: Content;

  receiverName:any;
  friendId:any;
  senderName:any;
  senderId:any;
  serverData:any;
  NotificationMsg:any;
  
  chatHistoryApiCall:any;
  jsonStirng:any;
  messagesList: any[] = [];
  wrappedMessage:any;
  typedmsg:any;
  timeStamp:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,
  public apiProvider: ApiProvider,public websocket:WebSocketConnectionProvider, public _date:DatePipe,
  private network: Network,public events: Events,public updateVallidator:UpdateValidatorProvider) {
    this.receiverName=this.navParams.get('friendName');
    this.friendId=this.navParams.get('friendId');
    this.senderName=this.navParams.get('senderName');
    this.senderId=this.navParams.get('senderId');
    this.checkNetwork();
    this.getChatHistoryServiceCall();
    if(this.serverData){
      if(this.serverData.id == this.senderId){
        this.events.unsubscribe('chat:friend');
        this.events.publish('chat:friend', this.senderId);
      }else{
        this.events.unsubscribe('chat:friend');
        this.events.publish('chat:friend', this.friendId);
      }
    }else{
      this.events.publish('chat:friend', this.friendId);
    }
    
    events.subscribe('chat:dataArrived', (serverMsg) => {  
      console.log('ServerMessage : ',serverMsg);
      this.serverData = serverMsg;
      if(this.serverData.id == this.friendId ){
        this.messagesList.push({
          senderId: this.serverData.id,
          dateSent: this.serverData.time,
          senderMessage: this.serverData.message
        });
        this.scrollToBottom();
      }
      else if(this.serverData.id == this.senderId){
        this.senderId=this.serverData.id;
        this.messagesList.push({
          senderId: this.serverData.id,
          dateSent: this.serverData.time,
          senderMessage: this.serverData.message
        });  
        this.scrollToBottom();
      }
    });
  }

  /**
   * This method is used to scroll to the bottom of the page
   */
  scrollToBottom(){
    try{
      this.content.scrollToBottom(0);
    }catch(e){
      console.log(e);
    }
  }

  /**
   * In this method back buttn is registered and the view is poped when pressed.
   * scroll to bottom method is also called in this method
   */
  ionViewDidEnter(){
    this.scrollToBottom();
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }

  /**
   * In the checkNetwork method there are two subscriptions.
   * Each subscription checks for the network availability and
   * stores the value as online in data if network is available and
   * stores the value as offline in data if network is not available.
   */
  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      console.log(data)
      this.networkType=data.type;
      //this.events.publish('chat:friend', this.friendId);
      //get chat history either from service or from local 
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      console.log(data)
      this.networkType=data.type;
      //unsubscribe the friend event
    }, error => console.error(error));
  }

/**
 * This method is used to get the history of the chat
 * @param senderId 
 * @param receiverId 
 * @returns chat history list between sender & receiver
 */
  getChatHistoryServiceCall(){
    //check network and then call the service
    this.jsonStirng={"senderRoleAssignmentId":window.localStorage.getItem('roleAssignmentId'),"receiverRoleAssignmentId":this.friendId};
    this.chatHistoryApiCall = this.apiProvider.post('getTheChatHistoryMobile',this.jsonStirng,'POST'); 
    this.chatHistoryApiCall.subscribe(data => { 
    console.log('chatHistoryList  : ',data);
    for (let _i = 0; _i < data.length; _i++) {
      this.messagesList.push({
        senderId: data[_i].id,
        dateSent: data[_i].time,
        senderMessage: data[_i].message
      });
    }
    console.log("MessageList:  ",this.messagesList);
    },(err) => {
      console.log(err);
    });
  }

  /**
   * This methos is used to send message to the receiver
   */
  sendMessage(): void {
    //check network before sending message
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Lost","No internet connection");
    }
    else{
      this.timeStamp=new Date()
      let latest_date=this._date.transform(this.timeStamp, 'dd-MM-yyyy HH.mm');
      this.wrappedMessage= this.friendId+"|"+this.typedmsg+"|"+window.localStorage.getItem('chatFilePath')+"|"+window.localStorage.getItem('userImagePath');
      console.log("Wrapped MEssage: ",this.wrappedMessage);
      this.websocket.sendMessage(this.wrappedMessage);
      this.messagesList.push({
        senderId: this.senderId,
        dateSent: latest_date,
        senderMessage: this.typedmsg,
      });
      this.typedmsg = ' ';
    }
    this.scrollToBottom();
  }
}
