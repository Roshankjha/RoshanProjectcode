/**********************************************************************************
 * Class-name - ContentDetailsPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 * Generated class for the ContentDetailsPage page.
 * ContentDetailsPage have methods implementation to perform checkNetwork status ,displayNetworkUpdate method  
 * updateVideoUrl,getSlideShareEncodedURL,updateSlideshareURL,checkExtension,downloadFile method and check androidPermissions also,
 * validateUI and  notificationDetailsServiceCall service.
 
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, Platform, ModalController } from 'ionic-angular';
import { DomSanitizer } from '@angular/platform-browser';
import { YoutubeVideoPlayer } from '@ionic-native/youtube-video-player';
import { ApiProvider } from '../../providers/api/api';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { CreateNotePage } from '../create-note/create-note';
import { NoteDetailsPage } from '../note-details/note-details';
import { MyNotesPage } from '../my-notes/my-notes';
import { NoteInfoPage } from '../note-info/note-info';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';


/**
 * Generated class for the ContentDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-content-details',
  templateUrl: 'content-details.html',
})
export class ContentDetailsPage {
  fromPage:any;
  item: any;
  notificationCode:any;
  notificationURL:any;
  notificationParam:any;

  notificationDetailsApiCall:any;
  jsonStirng:any;
  notificationDetail:any;

  YOUTUBE_VIDEO_KEY:any="";
  pdfURL:string="";
  downloadurl:any;
  normalVideoURL:any="";

  fileType:any;
  tableName:any;
  typeOfContentId:any;

  hideTextContent:boolean = true;
  hidePdfViewer:boolean = true;
  hideYoutubeViewer:boolean = true;
  hideSlideShare:boolean = true;
  hideVideo:boolean = true;
  hideIonicCard:boolean=true;

  fileTransfer: FileTransferObject = this.transfer.create();
  fileToBeDownloadedFrom:string;

  array:string[];
  array1:string[];
  encodedUrl:string;
  slideshareURL:string="";
  slideApiCall:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  alert:any;
  isCreateAlertPresent:boolean = false;

  constructor(public platform: Platform,public navCtrl: NavController, navParams: NavParams, public sanitizer: DomSanitizer,
    public youtube: YoutubeVideoPlayer,public apiProvider: ApiProvider,private androidPermissions: AndroidPermissions,
    public loading: LoadingController,private transfer: FileTransfer,private file: File,public alertCtrl: AlertController,
    private network: Network,public modalCtrl: ModalController,public updateVallidator:UpdateValidatorProvider) {
      this.checkNetwork();
      this.fromPage = navParams.get('fromPage');
      if(this.fromPage==="Notification"){
        this.notificationCode=navParams.get('notificationCode');
        this.notificationURL=navParams.get('notificationUrl');
        this.notificationParam=navParams.get('notificationParameters');
        this.notificationDetailsServiceCall();
        this.fileType = this.checkExtension(this.notificationDetail.fileName);
        if(this.fileType==='pdf'){
          this.pdfURL = this.apiProvider.fileAccessURL+'files/' + this.notificationDetail.fileName;
        }else if(this.fileType==='mp3'||this.fileType==='wma'||this.fileType==='ram'||this.fileType==='avi'||
        this.fileType==='ogv'||this.fileType==='wav'||this.fileType==='dvr'||this.fileType==='webm'||
        this.fileType==='wmv'||this.fileType==='mov'||this.fileType==='mp4'||this.fileType==='flv'||
        this.fileType==='mpg'||this.fileType==='rm'||this.fileType==='mpeg'){
          this.normalVideoURL = this.apiProvider.fileAccessURL+'files/' + this.notificationDetail.fileName;
          this.normalVideoURL = this.normalVideoURL.replace(/\s/g, "%20")
        }
        this.validateUI(this.notificationDetail.fileName);
      }
      else if(this.fromPage==="AllNotesPage"){
        this.item = navParams.get('item');
        this.fileType = this.checkExtension(this.item.fileUrl);
        this.tableName = this.item.tableNameVal;
        if(this.tableName === "programTable"){
          this.typeOfContentId = this.item.noteTaking.contentProgramCourseId;
        }else{
          this.typeOfContentId = this.item.noteTaking.contentCourseId;
        }
        if(this.fileType==='pdf'){
          this.pdfURL = this.apiProvider.fileAccessURL+ 'files/' + this.item.fileUrl;         
        }else if(this.fileType==='mp3'||this.fileType==='wma'||this.fileType==='ram'||this.fileType==='avi'||
        this.fileType==='ogv'||this.fileType==='wav'||this.fileType==='dvr'||this.fileType==='webm'||
        this.fileType==='wmv'||this.fileType==='mov'||this.fileType==='mp4'||this.fileType==='flv'||
        this.fileType==='mpg'||this.fileType==='rm'||this.fileType==='mpeg'){
          this.normalVideoURL = this.apiProvider.fileAccessURL+ 'files/' + this.item.fileUrl;
          this.normalVideoURL = this.normalVideoURL.replace(/\s/g, "%20")
        }
        this.validateUI(this.item.fileUrl);
  
        let modal = this.modalCtrl.create(CreateNotePage,{
          fromPage:'ContentDetailsPage',
          noteDetails:this.item
        
        });
        modal.present({
        });
      }
      else{
        this.item = navParams.get('item');
        this.fileType = this.checkExtension(this.item.fileUrl);
        this.tableName = navParams.data.tableName;
        if(this.tableName === "programTable"){
          this.typeOfContentId = this.item.digitalLibraryProgramCourseId;
        }else{
          this.typeOfContentId = this.item.digitalLibraryCourseId;
        }
       if(this.fileType==='pdf'){
          this.pdfURL = this.apiProvider.fileAccessURL+ 'files/' + this.item.fileUrl;
        }else if(this.fileType==='mp3'||this.fileType==='wma'||this.fileType==='ram'||this.fileType==='avi'||
        this.fileType==='ogv'||this.fileType==='wav'||this.fileType==='dvr'||this.fileType==='webm'||
        this.fileType==='wmv'||this.fileType==='mov'||this.fileType==='mp4'||this.fileType==='flv'||
        this.fileType==='mpg'||this.fileType==='rm'||this.fileType==='mpeg'){
          this.normalVideoURL = this.apiProvider.fileAccessURL+ 'files/' + this.item.fileUrl;
          this.normalVideoURL = this.normalVideoURL.replace(/\s/g, "%20")
        }
        this.validateUI(this.item.fileUrl);
      }
  }

  /**
   * In this method back buttn is registered and the view is poped when pressed.
   */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.isCreateAlertPresent==false){
        this.navCtrl.pop();
      }else{
        this.alert.dismiss();
        this.isCreateAlertPresent = false;
      }
      
    });
  }
/**
 * check network status 'connect/disconnect' if connect then call notification details service otherwise show error. 
 */
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      if(this.fromPage==="Notification"){
        this.notificationDetailsServiceCall();
        this.fileType = this.checkExtension(this.notificationDetail.fileName);
        if(this.fileType==='pdf'){
          this.pdfURL = this.apiProvider.fileAccessURL+ 'files/' + this.notificationDetail.fileName;
        }
        this.validateUI(this.notificationDetail.fileName);
      }
      else{
        this.fileType = this.checkExtension(this.item.fileUrl);
       if(this.fileType==='pdf'){
          this.pdfURL = this.apiProvider.fileAccessURL+ 'files/' + this.item.fileUrl;
        }
        this.validateUI(this.item.fileUrl);
      }
    }, error => console.error(error)); 
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  
  /**
   * connection event for the network check is unsubscribed
   */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

/**
 * update youtube video url. 
 * @param id 
 */
  updateVideoUrl(id: string) {
    if(id===''){
      return '';
    }else{
      let dangerousVideoUrl = 'https://www.youtube.com/embed/' + id + '?rel=0&showinfo=0';
      return this.sanitizer.bypassSecurityTrustResourceUrl(dangerousVideoUrl);
    }
  }
/**
 * Encoded slide share url
 * @param id 
 */
  getSlideShareEncodedURL(id: string){
     let tempUrl = 'https://www.slideshare.net/api/oembed/2?url=' + id + '&format=json';
     this.slideApiCall = this.apiProvider.getSlide(tempUrl,'GET'); 
     this.slideApiCall.subscribe(data => { 
       this.slideshareURL = data.html; 
      if(this.slideshareURL.includes('src')){
       this.array= this.slideshareURL.split('width');
       this.array1 = this.array[0].split('"');
       this.encodedUrl = this.array1[1];
      }  
    }, (err) => {
      this.updateVallidator.networkUpdateToast(this.networkType);
    });
  }
/**
 * Display frame with slide
 * @param encodedUrl 
 */
  updateSlideshareURL(encodedUrl:string){
    return this.sanitizer.bypassSecurityTrustResourceUrl(encodedUrl); 
  }

/**
 * check file extension
 * @param fileurl 
 */
  checkExtension(fileurl:string){
    if(fileurl.lastIndexOf(".") != -1 && fileurl.lastIndexOf(".") != 0){
      return fileurl.substring(fileurl.lastIndexOf(".") + 1);
    }
    else{
      return "";
    }
  }
/**
 * this method check network type offline/online .
 * if offline show error message'Check your connection and try again later'.otherwise download file
 * and check androidPermissions 
 */
  downloadFile(){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }
    else{
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE)
      );
  
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        if(this.fromPage==="Notification"){
          if(this.notificationDetail.fileName===""){
            this.updateVallidator.serverErrorAlert("Server Error","File Does not Exist");
          }else{
            this.fileToBeDownloadedFrom = this.notificationDetail.fileName;
            this.downloadurl = this.apiProvider.fileAccessURL+'files/'+this.fileToBeDownloadedFrom.replace(/\s/g, "%20");
            var destPath = this.file.externalApplicationStorageDirectory+ '/Download/DigitalLibrary/' + this.notificationDetail.fileName;
            this.fileTransfer.download(this.downloadurl,destPath,true).then((entry) => {
              loader.dismiss();
              this.updateVallidator.downloadUpdateAlert("Download Successfull","File is downloaded to Android/data/com.srmri.atihaLMS/Download/DigitalLibrary",destPath,true);
            },(error) => {
              loader.dismiss();
              this.updateVallidator.downloadUpdateAlert("Download Failed","File is failed/interupted due to some error in server","",false);
            });
          }
        }
        else{
          if(this.item.fileUrl===""){
            this.updateVallidator.serverErrorAlert("Server Error","File Does not Exist");
          }else{
            this.fileToBeDownloadedFrom = this.item.fileUrl;
            this.downloadurl = this.apiProvider.fileAccessURL+'files/'+this.fileToBeDownloadedFrom.replace(/\s/g, "%20");
            var destiPath = this.file.externalApplicationStorageDirectory+ '/Download/DigitalLibrary/' + this.item.fileUrl;
            this.fileTransfer.download(this.downloadurl,destiPath,true).then((entry) => {
              loader.dismiss();
              this.updateVallidator.downloadUpdateAlert("Download Successfull","File is downloaded to Android/data/com.srmri.atihaLMS/Download/DigitalLibrary",destiPath,true);
          }, (error) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Failed","File is failed/interupted due to some error in server","",false);
          });
          }
        }
      });
    }
  }
/**
 * 
 * check file type and url.
 * @param urlString 
 */
  validateUI(urlString:string){
    if(urlString.includes('http:') || urlString.includes('https:') || urlString.includes('ftp:')){
      if(urlString.includes("youtube")){
        if(urlString.lastIndexOf("=") != -1 && urlString.lastIndexOf("=") != 0){
          this.YOUTUBE_VIDEO_KEY =  urlString.substring(urlString.lastIndexOf("=") + 1);
        }
        console.log("You tube key = ", this.YOUTUBE_VIDEO_KEY);
        this.hideTextContent= true;
        this.hidePdfViewer= true;
        this.hideYoutubeViewer= false;
        this.hideSlideShare= true;
        this.hideVideo = true;
        this.hideIonicCard = false;
      }
      else if(urlString.includes('slideshare')){
        this.hideTextContent= true;
        this.hidePdfViewer= true;
        this.hideYoutubeViewer= true;
        this.hideSlideShare= false;
        this.hideVideo = true;
        this.hideIonicCard = false;
        this.getSlideShareEncodedURL(urlString);
    }
  }
  else
  {
    if(this.fileType==='pdf')
    {
      this.hideTextContent= false;
      this.hidePdfViewer= false;
      this.hideYoutubeViewer= true;
      this.hideSlideShare= true;
      this.hideVideo = true;
      this.hideIonicCard = false;
    }
    else if(this.fileType==='odt'||this.fileType==='arff'||this.fileType==='doc'||this.fileType==='docx'||
    this.fileType==='ppt'||this.fileType==='pptx'||this.fileType==='ppsx'||this.fileType==='xls'||
    this.fileType==='xslx'||this.fileType==='txt'||this.fileType==='jpg'||this.fileType==='gif'||
    this.fileType==='png'||this.fileType==='jpeg'||this.fileType==='png')
    {
      this.hideTextContent= false;
      this.hidePdfViewer= true;
      this.hideYoutubeViewer= true;
      this.hideSlideShare= true;
      this.hideVideo = true;
      this.hideIonicCard = true;
    }
    else if(this.fileType==='mp3'||this.fileType==='wma'||this.fileType==='ram'||this.fileType==='avi'||
    this.fileType==='ogv'||this.fileType==='wav'||this.fileType==='dvr'||this.fileType==='webm'||
    this.fileType==='wmv'||this.fileType==='mov'||this.fileType==='mp4'||this.fileType==='flv'||
    this.fileType==='mpg'||this.fileType==='rm'||this.fileType==='mpeg')
    {
      this.hideTextContent= false;
      this.hidePdfViewer= true;
      this.hideYoutubeViewer= true;
      this.hideSlideShare= true;
      this.hideVideo = false;
      this.hideIonicCard = false;
    }
  }
}
/**
 * This method for notification and call apiprovider.
 */
  notificationDetailsServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"parameterValues":this.notificationParam};
      this.notificationDetailsApiCall = this.apiProvider.post(this.notificationURL,this.jsonStirng,'POST'); 
      this.notificationDetailsApiCall.subscribe(data => { 
      this.notificationDetail = JSON.parse(data.ContentManagementNotificationDetails);  
       loader.dismiss();
      }, (err) => {
        loader.dismiss();
      });
    });
  }
  /**
   * this method display options to choose the type of note creation text/freehand
   */
  createNote(){
    this.isCreateAlertPresent = true;
    this.alert = this.alertCtrl.create({
      title: 'Choose your Editor',
      message: 'Click on any option to choose your type of editor',
      buttons: [
        {
          text: 'Text',
          handler: () => {
            console.log('Text clicked');
            let modal = this.modalCtrl.create(CreateNotePage,{
              fromPage:'ContentDetailsPage',
              typeOfEditor: 'text',
              filetype: this.fileType,
              tableName:this.tableName,
              typeOfContentId:this.typeOfContentId
            });
            modal.present({
            });
            this.isCreateAlertPresent = false;
          }
        },
        {
          text: 'FreeHand',
          handler: () => {
            console.log('FreeHand clicked');
            let modal = this.modalCtrl.create(CreateNotePage,{ 
              fromPage:'ContentDetailsPage',
              typeOfEditor: 'freeHand',
              filetype: this.fileType,
              tableName:this.tableName,
              typeOfContentId:this.typeOfContentId
            });
            modal.present({
            });
            this.isCreateAlertPresent = false;
          }
        }
      ]
    });
    this.alert.present();
  }
/**
 * this methos displays details of note
 */
  openNoteDetails(){
    let modal = this.modalCtrl.create(NoteDetailsPage);
    modal.present({
    });
  }
/**
 * this method displays the list of all notes for current pdf/video
 */
  openMyNotes(){
    let modal = this.modalCtrl.create(MyNotesPage,{
      tableName:this.tableName,
      typeOfContentId:this.typeOfContentId,
      pdfTitle:this.item.title
    });
    modal.present({
    });
  }
/**
 * this method is info window related to note creation
 */
  openInfoWindow(){
    let modal = this.modalCtrl.create(NoteInfoPage);
    modal.present({
    });
  }
}

