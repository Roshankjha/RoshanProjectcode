/**********************************************************************************
 * Class-name - CourseContentPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 * Generated class for the CourseContentPage page. 
 * CourseContentPage have methods implementation 
 * goToContentDetail method impletment for navigate ContentDetailsPage.
 * Implement goToFilter method for filtering contents.
 * download file implement download method.
 * For check network status implement checkNetwork method.
 * display download toast message implement downloadUpdateToast method.
 * For display course content implement service courseContentServiceCall.
 * Implement noDataToast if data not available then show toast message.  
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ViewController, Platform} from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Item } from '../../models/item';
import { ContentDetailsPage } from '../content-details/content-details';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { FilterPage } from '../filter/filter';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-course-content',
  templateUrl: 'course-content.html',
})
export class CourseContentPage {

  fromPage:any;
  item: any;
  contentTypeName: any;
  courseId:any;
  programId:any;
  tableName:any;
  contentTypeId:any;
  nodataText:string="";

  jsonStirng:any;
  public courseContent: any[];
  courseCont:any;
  destinationFolder:any;
  fileToBeDownloadedFrom:string;

  hideFilter:boolean=true;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  constructor(public platform: Platform,public navCtrl: NavController, private viewCtrl: ViewController,navParams: NavParams,public loading: LoadingController,
  public apiProvider: ApiProvider,private transfer: FileTransfer, private file: File,private androidPermissions: AndroidPermissions,
  private network: Network,public updateVallidator:UpdateValidatorProvider) {
      this.checkNetwork();
      this.fromPage = navParams.get('fromPage');
      if(this.fromPage==='ProgramCourse'){
        this.item = navParams.get('item');
        this.courseId = this.item.courseId;
        this.programId = this.item.programId;
        this.tableName = this.item.tableName;
        this.contentTypeId = 0;
        this.contentTypeName = navParams.get('contentTypeName');
        this.courseContentServiceCall();
      }
      else if(this.fromPage==='Filter'){
        this.courseId = navParams.get('courseId');
        this.programId = navParams.get('programId');
        this.tableName = navParams.get('tableName');
        this.contentTypeId = 0;
        this.contentTypeName = navParams.get('contentTypeName');
        this.courseContentServiceCall();
      }
      this.validateUI();
  }

  /**
   * In this method back buttn is registered and the view is poped when pressed.
   */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
/*
 this method  to check network status 'connect/disconnect' if connect then call course Content Service otherwise show error 
*/
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.courseContentServiceCall();
    }, error => console.error(error));  
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  } 

   /**
   * connection event for the network check is unsubscribed
   */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

   /**
   * This method is used to hide and show the filters based on content type
   */
  validateUI(){
    if(this.contentTypeName==='browseContent'||this.contentTypeName==='courseContent'){
      this.hideFilter = false;
    }
    else{
      this.hideFilter = true;
    }
  }
/** 
 * this method impletment for navigate ContentDetailsPage.
*/
  goToContentDetails(item: Item){
    if (!item) item = {};
    this.navCtrl.push(ContentDetailsPage,{
      item: item,
      tableName:this.tableName
    });
  }
/**
 * this method for filter out content according to user type in search bar.
 */
  goToFilter(){
    this.navCtrl.push(FilterPage,{
      fromPage: "CourseContent",
      contentTypeName: this.contentTypeName,
      courseId:this.courseId,
      programId:this.programId,
      tableName:this.tableName
    }).then(() => {
      // first we find the index of the current view controller:
      const index = this.viewCtrl.index;
      // then we remove it from the navigation stack
      this.navCtrl.remove(index);
    });
  }

/** 
 * this method check network type offline/online if offline show alert message
   connection error'Check your connection and try again later'.
   if online then download items.
*/
  download(item: Item){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE));
  
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        if(item.fileUrl===""){
          this.updateVallidator.serverErrorAlert("Server Error","File Does not Exist");
        }else{
          this.fileToBeDownloadedFrom = item.fileUrl;
          const fileTransfer: FileTransferObject = this.transfer.create();
          const url = this.apiProvider.fileAccessURL+"files/"+this.fileToBeDownloadedFrom.replace(/\s/g, "%20");
          var destPath = this.file.externalApplicationStorageDirectory+ '/Download/DigitalLibrary/' + item.fileUrl;
          fileTransfer.download(url,destPath,true).then((entry) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Successfull","File is downloaded to Android/data/com.srmri.atihaLMS/Download/DigitalLibrary",destPath,true);
          },(error) => {
            loader.dismiss();
            this.updateVallidator.downloadUpdateAlert("Download Failed","File is failed/interupted due to some error in server","",false);
          });
        }
      });
    }
  }

  /** 
   *  this is course content service call for showing browse Content,program Course Content List,
      Program handouts,
  */
  courseContentServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      if(this.contentTypeId=== 0){
        if (this.contentTypeName=="browseContent"){
          this.jsonStirng={"roleId":window.localStorage.getItem('roleid'),"tableName":this.tableName,"courseId":this.courseId};
          this.courseCont = this.apiProvider.post('BrowseContent',this.jsonStirng,'POST'); 
          this.courseCont.subscribe(data =>{
            this.courseContent = JSON.parse(data.programCourseContentList); 
            loader.dismiss();
            if(this.courseContent.length==0){
              this.nodataText = "No data for Course Content found";
            }else{this.nodataText = "";}
          }, (err) => {
            loader.dismiss();
            this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
          });
        }else{
          if (this.contentTypeName=="handouts"){
            this.jsonStirng={"roleId":window.localStorage.getItem('roleid'),"contentType":this.contentTypeName,"programId":this.programId};
          }else{
            this.jsonStirng={"roleId":window.localStorage.getItem('roleid'),"contentType":this.contentTypeName,"tableName":this.tableName,"courseId":this.courseId};
          }
          this.courseCont = this.apiProvider.post('StudentContentType',this.jsonStirng,'POST'); 
          this.courseCont.subscribe(data => { 
            if (this.contentTypeName=="handouts"){
              this.courseContent = JSON.parse(data.programCourseContentList);
            }else{
              if(this.tableName=="courseTable"){
                this.courseContent = JSON.parse(data.courseContentList);
              }else{ 
                this.courseContent = JSON.parse(data.programCourseContentList);
              }
            }
            loader.dismiss();   
            if(this.courseContent.length==0){
              this.nodataText = "No data for Course Content found";
            }else{this.nodataText = "";}
          },(err) => {
            loader.dismiss();
            this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
          });
        }
      }
      else{
        this.jsonStirng={"contentTypeId":this.contentTypeId};
        this.courseCont = this.apiProvider.post('contentmanagementGetFilterCourseContentType',this.jsonStirng,'POST'); 
        this.courseCont.subscribe(data =>{ 
          this.courseContent = JSON.parse(data.filterContentList); 
          if(this.courseContent.length==0){
            this.nodataText = "No data for Course Content found";
          }else{this.nodataText = "";}
          loader.dismiss();
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }
    });
  }
}
