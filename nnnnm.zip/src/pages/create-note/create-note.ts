/**********************************************************************************
 * Class-name - CreateNotes
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the CreateNotes page. 
 *
 **********************************************************************************/
import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavParams, ViewController, Content, Platform, LoadingController, AlertController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';

/**
 * Generated class for the CreateNotePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-create-note',
  templateUrl: 'create-note.html',
})
export class CreateNotePage {


    @ViewChild('imageCanvas') canvas: any;
    @ViewChild(Content) content: Content;
    @ViewChild('fixedContainer') fixedContainer: any;
    canvasElement: any;
    saveX: number;
    saveY: number;
    storedImages = [];
    selectedColor = 'rgba(12, 180, 54, 0.993)';
  
    hidetextEditor:boolean=true;
    hideFreeHandEditor:boolean=true;
    noteTitle:any;
    pdfPageNumber:any;
    noteContent:any;
  
    modules = {};
  
    jsonStirng:any;
    createNoteApiProvider:any;
    createNoteResponse:any;


    headerTitle:string;


    constructor(public viewCtrl: ViewController, public navParams: NavParams,private plt: Platform,
    public loading: LoadingController,public apiProvider: ApiProvider,public alertCtrl: AlertController){
      if(navParams.data.fromPage==="ContentDetailsPage"){
        if( navParams.data.typeOfEditor==='text'){
          this.hidetextEditor=false;
          this.hideFreeHandEditor=true;
          this.headerTitle = "Create Note";
        }else if(navParams.data.typeOfEditor==='freeHand'){
          this.hidetextEditor=true;
          this.hideFreeHandEditor=false;
          this.headerTitle = "Create Note";
        }else{
          this.hidetextEditor=false;
          this.hideFreeHandEditor=true;
          this.headerTitle = "Edit Note";
          this.noteTitle = navParams.data.noteDetails.noteTaking.noteTitle
          this.pdfPageNumber = navParams.data.noteDetails.noteTaking.pageNumber
          this.noteContent = navParams.data.noteDetails.noteTaking.noteContent
        }
      }else{
        this.hidetextEditor=false;
        this.hideFreeHandEditor=true;
        this.headerTitle = "Edit Note";

        this.noteTitle = navParams.data.noteDetails.noteTitle
        this.pdfPageNumber = navParams.data.noteDetails.pageNumber
        this.noteContent = navParams.data.noteDetails.noteContent
      }
      
      this.modules = {
        formula: true,
        toolbar:[
          ['bold', 'italic', 'underline',],        
          [{ 'align': [] }],
          [{ 'indent': '-1'}, { 'indent': '+1' }],
          [{ 'list': 'ordered'}, { 'list': 'bullet' }],
          [{ 'color': [] }, { 'background': [] }],['image','clean']                 
        ]
      }
    }
/**
 * Get the height of the fixed item
 * Add preexisting scroll margin to fixed container size
 */ 
    ionViewDidEnter() {
      let itemHeight = this.fixedContainer.nativeElement.offsetHeight;
      let scroll = this.content.getScrollElement();
   
      itemHeight = Number.parseFloat(scroll.style.marginTop.replace("px", "")) + itemHeight;
      scroll.style.marginTop = itemHeight + 'px';
    }

   /**
    * Set the Canvas Element and its size
    */
    ionViewDidLoad() {
      this.canvasElement = this.canvas.nativeElement;
      this.canvasElement.width = this.plt.width() + '';
      this.canvasElement.height = 200;
    }

    /**
    * This method is used to close the view
    */
    closePopOver(){
      this.viewCtrl.dismiss();
    }
  
    /**
     * This method is used to close the view
     * @param ev 
     */
    startDrawing(ev) {
      var canvasPosition = this.canvasElement.getBoundingClientRect();
      this.saveX = ev.touches[0].pageX - canvasPosition.x;
      this.saveY = ev.touches[0].pageY - canvasPosition.y;
    }

    /**
     * This method is used to draw the canvas
     * @param ev 
     */
   moved(ev) {
      var canvasPosition = this.canvasElement.getBoundingClientRect();
     
      let ctx = this.canvasElement.getContext('2d');
      let currentX = ev.touches[0].pageX - canvasPosition.x;
      let currentY = ev.touches[0].pageY - canvasPosition.y;
     
      ctx.lineJoin = 'round';
      ctx.strokeStyle = this.selectedColor;
      ctx.lineWidth = 5;
     
      ctx.beginPath();
      ctx.moveTo(this.saveX, this.saveY);
      ctx.lineTo(currentX, currentY);
      ctx.closePath();
     
      ctx.stroke();
     
      this.saveX = currentX;
      this.saveY = currentY;
    }

    /**
    * This method is used to store the canvas in a file directory abd clear the canvas
    */
   saveCanvasImage() {
    var dataUrl = this.canvasElement.toDataURL();
    let name =this.noteTitle;
    var bas64data = dataUrl.split(',')[1];
    console.log("bas64data: ",bas64data);
    this.addFreeHandNoteServiceCall(bas64data,name);

    let ctx = this.canvasElement.getContext('2d');
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Clears the canvas
  }

  /**
   * This method is used to clear the content on the canvas drawn
   */
    clearCanvas(){
      let ctx = this.canvasElement.getContext('2d');
      ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);  
    }
   /**
    * This method is used to call the add note service call method
    */
    saveNote(){
      if(this.navParams.data.fromPage==="ContentDetailsPage"){
        if(this.hidetextEditor==false){
          this.addNoteServiceCall(0);
        }else if(this.hideFreeHandEditor==false){
          //save the canvas image to database
          this.saveCanvasImage();
        }
      }else{
        if(this.hidetextEditor==false){
          this.addNoteServiceCall(this.navParams.data.noteDetails.noteId);
        }else if(this.hideFreeHandEditor==false){
          //save the canvas image to database
          this.saveCanvasImage();
        }
      }
    }
  
    /**
     * This method is used to clear the the content of the text editor or the canvas
     */
    clear(){
      if(this.hidetextEditor==false){
        this.noteContent = '';
      }
      else if(this.hideFreeHandEditor==false){
        this.clearCanvas();
      }
    }
  /**
   * this method is used to display the toast message
   * @param keyword 
   */
    updateToast(keyword:string){
      let alert = this.alertCtrl.create({
        title: keyword,
        buttons: [
          {
            text: 'Ok',
            handler: () => {
              this.viewCtrl.dismiss();
            }
          },
        ]
      });
      alert.present();
    }
  /**
   * This method is used to call service to add note details 
   * @param noteId 
   * @param userId
   * @param roleId
   * @param contentId
   * @param tableName
   * @param noteTitle
   * @param noteContent
   * @param pageNumber
   * @param type
   * @returns message
   */
    addNoteServiceCall(noteId:any){
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        if(noteId===0){
          this.jsonStirng={ "userId":window.localStorage.getItem('userid'),
                            "roleId":window.localStorage.getItem('roleid'),
                            "contentId":this.navParams.data.typeOfContentId,
                            "tableName":this.navParams.data.tableName,
                            "noteId": noteId,
                            "noteTitle":this.noteTitle,
                            "noteContent":this.noteContent,
                            "pageNumber":this.pdfPageNumber,
                            "type":this.navParams.data.filetype
                          };
        }else{
          this.jsonStirng={ "roleId":window.localStorage.getItem('roleid'),
                            "noteId": noteId,
                            "noteTitle":this.noteTitle,
                            "noteContent":this.noteContent,
                            "pageNumber":this.pdfPageNumber
                          };
        }
        this.createNoteApiProvider = this.apiProvider.post('addNoteNewPDF',this.jsonStirng,'POST');
        this.createNoteApiProvider.subscribe(data => {
        this.updateToast(data.message);
        loader.dismiss();
        },(err)=>{
          loader.dismiss();
        });
      });
    }

    addFreeHandNoteServiceCall(imageData,imageName){
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
        this.jsonStirng={ "userId":window.localStorage.getItem('userid'),
                          "roleId":window.localStorage.getItem('roleid'),
                          "contentId":this.navParams.data.typeOfContentId,
                          "tableName":this.navParams.data.tableName,
                          "noteTitle":this.noteTitle,
                          "pageNumber":this.pdfPageNumber,
                          "type":this.navParams.data.filetype,
                          "noteHandwritingImage":imageData,
                          "fileName":imageName
                        };
        this.createNoteApiProvider = this.apiProvider.post('addFreeHandNote',this.jsonStirng,'POST');
        this.createNoteApiProvider.subscribe(data => {
          console.log("freehand create note response : ",data);
          this.updateToast(data.message);
          loader.dismiss();
        },(err)=>{
          loader.dismiss();
        });
      });
    }
}
