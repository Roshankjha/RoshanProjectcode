/**********************************************************************************
 * Class-name - DigitalLibraryPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the DigitalLibraryPage page. 
 * DigitalLibraryPage have methods implementation to perform,toggleDigilib,toggleCourseContent,loadUI,
 * goToProgramCourses,service implement graphServiceCall,checkNetwork for network status,
 *
 **********************************************************************************/
import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, Events, MenuController } from 'ionic-angular';
import { ProgramCoursesPage } from '../program-courses/program-courses';
import { Chart } from 'chart.js';
import { ApiProvider } from '../../providers/api/api';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { HomePage } from '../home/home';


/**
 * Generated class for the DigitalLibraryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-digital-library',
  templateUrl: 'digital-library.html',
})
export class DigitalLibraryPage {
  digilibListItems: any[];
  coursecntntListItems:any[];

  @ViewChild('barCanvas') barCanvas;

  barChart: any;
  public courseGraph: any;
  graphContent:any;
  jsonStirng:any;
  public courseCode:any[] = [];
  public courseCount:any[] = [];
  public courseName:any[] = [];
  //URL: string;

  dynamicColors:any[]=[];
  r:any;
  g:any;
  b:any;
  a:any;s

  hideDigilibList:boolean=true;
  hideCourseContentList:boolean=true;
  digilibIcon: string = "add";
  coursecontentIcon: string = "add";

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  menuOpened:boolean;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,public loading: LoadingController, 
    public apiProvider: ApiProvider, private network: Network,public events: Events,public menuCtrl: MenuController) {
    this.checkNetwork();
    this.loadUI();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });
  }

  /**
   * In this method back button is registered and on press view is set to root page(Home page)
   */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }else{
        this.navCtrl.setRoot(HomePage);
      }
    });
  }
/**
 * toggle digital library's list
 */
  toggleDigilib(){
    this.hideDigilibList = !this.hideDigilibList;
    if (this.digilibIcon === 'remove') {
      this.digilibIcon = "add";
    }else if (this.digilibIcon === 'add') {
      this.digilibIcon = "remove";
    }
  }
/**
 * toggle Course Content list 
 */
  toggleCourseContent(){
    this.hideCourseContentList = !this.hideCourseContentList;
    if (this.coursecontentIcon === 'remove') {
      this.coursecontentIcon = "add";
    }else if (this.coursecontentIcon === 'add') {
      this.coursecontentIcon = "remove";
    }
  }

   /**
   * In this method service call for graph is called UI is instantiated
   */
  loadUI(){ 
      this.graphServiceCall();
      this.digilibListItems = [
        { "title":"Browse Content", "id":"browseContent"},
        { "title":"Program Handouts",  "id":"handouts"},
        { "title":"Seminars", "id":"Seminars" },
        { "title":"General","id":"General" },
        { "title":"References", "id":"References" },
        { "title":"Supplementary Materials","id":"SupplementaryMaterials"}
      ]; 
      this.coursecntntListItems = [
        {"title":"All Course Content", "id":"courseContent"},
        { "title":"Course Syllabus", "id":"CourseSyllabus" },
        { "title":"eSLM","id":"eSLM"},
        { "title":"Lectures",  "id":"Lectures" },
        { "title":"Presentations", "id":"Presentations"},
        { "title":"Question Banks", "id":"QuestionBanks"}
      ];
  }
/**
 * this method used for navigate page
 * @param item 
 */
  goToProgramCourses(item){
    this.navCtrl.push(ProgramCoursesPage,{
      contentType: item,
      fromPage:"DigitalLibrary"      
    });
  }
/**
 * This graphservice call  generate statistics for courses.
 * @param url 
 */
  graphServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
      this.graphContent = this.apiProvider.post('CmIndexPage',this.jsonStirng,'POST');
      this.graphContent.subscribe(data => { 
      this.courseGraph = JSON.parse(data.studentCoursesPcList);     
      for (let _i = 0; _i < this.courseGraph.length; _i++) {
        var course = this.courseGraph[_i];
        this.courseCode.push(course.courseCode);
        this.courseCount.push(course.courseCount);
      }
      this.barChart = new Chart(this.barCanvas.nativeElement,{
        type: 'bar',
        zoomEnabled: true, 
        zoomType: "xy",
        data: {
          labels: this.courseCode,
          datasets: [{
            data: this.courseCount,
            backgroundColor: this.generateRGB(this.courseCode),
            borderColor:this.generateRGB(this.courseCode),
            borderWidth: 1
          }]
        },
        options: {
          legend: {
            display: false,
          },
          scales: {
            yAxes: [{
              ticks:{
                beginAtZero:true
              }
            }]
          }
        }
      });
    loader.dismiss();   
  },(err)=>{
    loader.dismiss();
  });
});
}

/**
 * Dynamic generation of the rgb color 
 * @param data 
 */
  generateRGB(data:any){
    for (let _i = 0; _i < data.length; _i++){
        this.r = Math.floor(Math.random() * 255);
        this.g = Math.floor(Math.random() * 255);
        this.b = Math.floor(Math.random() * 255);
        this.a = 0.5;
        var color ='rgba(' + this.r + ',' + this.g + ',' + this.b +','+ this.a + ')';
        this.dynamicColors.push(color);
    }
    return this.dynamicColors
}
/**
 * check network connection 'connect/disconnect' if connect then call graph service otherwise show error 
 */
checkNetwork(){
  this.connected = this.network.onConnect().subscribe(data => {
    this.networkType=data.type;
    this.graphServiceCall();
  }, error => console.error(error));
 
  this.disconnected = this.network.onDisconnect().subscribe(data => {
    this.networkType=data.type;
  }, error => console.error(error));
}

 /**
   * connection event to check network is unsubscribed
   */
ionViewWillLeave(){
  this.connected.unsubscribe();
  this.disconnected.unsubscribe();
}
}
