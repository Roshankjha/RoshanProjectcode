/**********************************************************************************
 * Class-name - EvantDetails
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the EvantDetails page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the EventDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-event-details',
  templateUrl: 'event-details.html',
})
export class EventDetailsPage {

  item: any;
  /**
   * constructor will call page loading and imports the classes and access the navPrams data
   * pass ths data to html template
   * @param viewCtrl 
   * @param navParams 
   */
  constructor(public viewCtrl: ViewController, public navParams: NavParams) {
    this.item = this.navParams.data;
  }

   /**
   * In this method view is closed
   */
  closePopOver(){
    this.viewCtrl.dismiss();
  }
}
