/**********************************************************************************
 * Class-name - FilterPage
 * Version - 1.0
 * Author -SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the FilterPage page. 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Item } from '../../models/item';
import { ProgramCoursesPage } from '../program-courses/program-courses';
import { CourseContentPage } from '../course-content/course-content';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

/**
 * Generated class for the FilterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-filter',
  templateUrl: 'filter.html',
})
export class FilterPage {

  fromPage:any;
  contentType: any;
  contentTypeName:any;
  courseId:any;
  programId:any='';
  tableName:any;
  departmentID:any='';
  contentTypeID:any='';


  deptApiCall:any;
  filterDepartment:any;
  programApiCall:any;
  filterProgram:any;
  contenttypeApiCall:any;
  filterContentType:any;
  jsonStirng:any;


  hideDepartments:boolean = true;
  hidePrograms:boolean = true;
  hideContentType:boolean = true;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  constructor(public platform: Platform,public navCtrl: NavController, private viewCtrl: ViewController,
  public navParams: NavParams,public apiProvider: ApiProvider,private network: Network,public updateVallidator:UpdateValidatorProvider){
      this.checkNetwork();
    this.fromPage = navParams.get('fromPage');
    if(this.fromPage==='ProgramCourse'){
      this.contentType = navParams.get('contentType');
      this.contentTypeName =  this.contentType.id;
    }else{
      this.courseId = navParams.get('courseId');
      this.programId = navParams.get('programId');
      this.tableName = navParams.get('tableName');
      this.contentTypeName = navParams.get('contentTypeName');
    }
    this.filtersVisibility();
  }
  /**
  * this method is handle back button function.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      //this.navCtrl.pop();
      this.updateVallidator.validationUpdateToast("Click on cancel to close filter");
    });
  }
/**
 * this method generate to check the network status. 
 */
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.filtersVisibility();
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /**
  * this method is life Cycle method of ionic.
  * unsubscribe the events of network connect and disconnected.
  */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
/**
 * filtersVisibility
 */
  filtersVisibility(){
    if(this.fromPage==='ProgramCourse'){
      if(this.contentTypeName==='browseContent'){
        this.serviceCallDepartments();
        this.hideDepartments = false;
        this.hidePrograms = true;
        this.hideContentType = true;
        }
    }
    else if(this.fromPage==='CourseContent'){
        if(this.contentTypeName==='browseContent' || this.contentTypeName==='courseContent'){
          this.hideDepartments = true;
          this.hidePrograms = true;
          this.hideContentType = false;
          this.serviceCallContentType();
        }
    }
}

/**
 * Service call to program is called on selection of the departments
 * @param item 
 */
selectDepartment(item:Item){
  this.departmentID = item.departmentId;
  if(item.departmentId!==''){
    this.hideDepartments = false;
    this.hidePrograms = false;
    this.serviceCallProgram();
    this.hideContentType = true;
  }
}

/**
 * programs is selected
 * @param item 
 */
selectPrograms(item:Item){
  this.programId = item.programId;
}

/**
 * content type is selected
 * @param item 
 */
selectContentType(item:Item){
  this.contentTypeID = item.contentTypeId
}

/**
 * this method is saved to the select filters
 */
saveFilters(){
  if(this.networkType==='offline'){
    this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
  }
  else{
    if(this.fromPage==='ProgramCourse'){
      if(this.departmentID===''||this.departmentID===null||this.departmentID==='undefined'){
        this.updateVallidator.validationUpdateToast("You need to select atleast one Department");
      }
      else{
        if(this.programId===''||this.programId===null||this.programId==='undefined'){
          this.navCtrl.push(ProgramCoursesPage,{
            fromPage:"Filter",
            contentType : this.contentType,
            departmentID: this.departmentID,
            programId: 0
          }).then(() => {
            // first we find the index of the current view controller:
            const index = this.viewCtrl.index;
            // then we remove it from the navigation stack
            this.navCtrl.remove(index);
          });
        }
        else{
          this.navCtrl.push(ProgramCoursesPage,{
            fromPage:"Filter",
            contentType : this.contentType,
            departmentID: this.departmentID,
            programId: this.programId
            //programId: 0
          }).then(() => {
            // first we find the index of the current view controller:
            const index = this.viewCtrl.index;
            // then we remove it from the navigation stack
            this.navCtrl.remove(index);
          });
        }
      }
    }
    else{
      if(this.contentTypeID=== ''|| this.contentTypeID=== null || this.contentTypeID=== 'undefined'){
        this.updateVallidator.validationUpdateToast("You need to select atleast one Content Type");
      }
      else{
        this.navCtrl.push(CourseContentPage,{
          fromPage:"Filter",
          courseId: this.courseId,
          programId: this.programId,
          tableName: this.tableName,
          contentTypeName : this.contentTypeName,
          contentTypeID: this.contentTypeID
        }).then(() => {
          // first we find the index of the current view controller:
          const index = this.viewCtrl.index;
          // then we remove it from the navigation stack
          this.navCtrl.remove(index);
        });
      }
    }
  }
}
/**
 * close the filter page
 */
cancelFilters(){
  if(this.fromPage==='ProgramCourse'){
    this.navCtrl.push(ProgramCoursesPage,{
      fromPage:"DigitalLibrary",
      contentType: this.contentType
    }).then(() => {
      // first we find the index of the current view controller:
      const index = this.viewCtrl.index;
      // then we remove it from the navigation stack
      this.navCtrl.remove(index);
    });
  }
  else if(this.fromPage==='CourseContent'){
    this.navCtrl.push(CourseContentPage,{
      fromPage :"Filter",
      courseId : this.courseId,
      programId: this.programId,
      tableName: this.tableName,
      contentTypeName : this.contentTypeName,
    }).then(() => {
      // first we find the index of the current view controller:
      const index = this.viewCtrl.index;
      // then we remove it from the navigation stack
      this.navCtrl.remove(index);
    });
  }
  else{
    this.navCtrl.pop();
  }
}
/**
 * this method call to get the departments 
 * @param url 
 */
serviceCallDepartments(){
  this.deptApiCall = this.apiProvider.get('contentmanagementGetDepartments','GET'); 
  this.deptApiCall.subscribe(data => { 
   this.filterDepartment = JSON.parse(data.DepartmentList);      
 });
}
/**
 *  this method call to get the departments program course
 * @param url 
 */
serviceCallProgram(){
  this.jsonStirng={"departmentId": this.departmentID};
  this.programApiCall = this.apiProvider.post('contentmanagementGetDepartmentProgramsCourses',this.jsonStirng,'POST'); 
  this.programApiCall.subscribe(data => { 
   this.filterProgram = JSON.parse(data.libraryPcmProgramList);  

 });
}
/**
 *  this method call to get the content type 
 * @param url 
 */
serviceCallContentType(){
  this.contenttypeApiCall = this.apiProvider.get('contentmanagementGetContentType','GET'); 
  this.contenttypeApiCall.subscribe(data => { 
   this.filterContentType = JSON.parse(data.ContentTypeList);    
 });
}
}
