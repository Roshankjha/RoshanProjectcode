/**********************************************************************************
 * Class-name - FriendListPage
 * Version - 1.0
 * Author -SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the FriendListPage page. 
 * FriendListPage have methods implementation to display all the online friends.  
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, Events, MenuController } from 'ionic-angular';
import { ChatPage } from '../chat/chat';
import { ApiProvider } from '../../providers/api/api';
import { WebSocketConnectionProvider } from '../../providers/web-socket-connection/web-socket-connection';
import { Subscription} from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  
  selector: 'page-friend-list',
  templateUrl: 'friend-list.html',
})
export class FriendListPage {

  apiCall:any;
  onlineFriendsList:any[]=[];
  notificationfriendId:any;
  notificationfriendMsg:any;
  msgnotify:any;
  counter:any=0;
  userImagePath:any;
  nodataText:string="";

  jsonStirng:any;
  onlineIds:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  menuOpened:boolean;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,public apiProvider: ApiProvider,
  public websocket:WebSocketConnectionProvider,private network: Network,public events: Events,public menuCtrl: MenuController){
    this.userImagePath = this.apiProvider.fileAccessURL;
    this.checkNetwork();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });

    this.events.subscribe('chat:dataArrived', (serverMsg) => {
      if(JSON.stringify(serverMsg).includes("[")){
        console.log('Live Users : ',serverMsg);
        this.onlineIds = serverMsg;
        this.onlineFriendsList = [];
        this.getOnlineFriendListServiceCall();
      }else{
        console.log('Message for friends page notification: ', serverMsg);
        this.notificationfriendId=serverMsg.id;
        this.notificationfriendMsg=serverMsg.message;
        this.counter++;
      }
    });
  }
/**
 * this method is handle back button function.
 */
ionViewDidEnter() {
  this.websocket.sendMessage("5|");
  
  this.platform.registerBackButtonAction(() => {
    if(this.menuOpened==true){
      this.menuCtrl.close();
    }else{
      this.navCtrl.setRoot(HomePage);
    }
  });
}
/**
 * this method generate to check the network status.
 */
checkNetwork(){
  this.connected = this.network.onConnect().subscribe(data => {
    this.networkType=data.type;
    //service call for friends list
  }, error => console.error(error));
 
  this.disconnected = this.network.onDisconnect().subscribe(data => {
    this.networkType=data.type;
  }, error => console.error(error));
}
/**
 * this method generate for searchinig the online friends using searchbar from the online friendList.
 */
searchFriends(ev:any){
  let servVal=ev.target.value;
  if(servVal && servVal.trim()!=''){
    this.onlineFriendsList = this.onlineFriendsList.filter((pc)=>{
      return (pc.name.toLowerCase().indexOf(servVal.toLowerCase()) > -1);
    })
  }else{
    this.getOnlineFriendListServiceCall();
  }
}
/** 
 * this method generate for Service call api to get the online friendList.
 * Iterate the list of online friend on UI.
*/
getOnlineFriendListServiceCall(){
  //check network type before service call
  this.jsonStirng = {"id": JSON.stringify(this.onlineIds)};
  this.apiCall = this.apiProvider.post('getTheLiveUsersList',this.jsonStirng,'POST'); 
  this.apiCall.subscribe(data => {
    console.log("Friends list data : ",data);
    if(data=="error"){
      this.nodataText = "No friends are online right now";
    }else{
      this.nodataText="";
      for (let _i = 0; _i < data.length; _i++) {
        var imgpath =  this.userImagePath + data[_i].imagePath;
        this.onlineFriendsList.push({
          roleAssignmentId: data[_i].roleAssignmentId,
          name: data[_i].name,
          imagePath: imgpath
        });
      }
     }
  },(err) => {
    console.log("Error from server : ",err);
  });
}
/**
 * this method generate for select a friend from the online friendlist and to go the chat page.
 * Check the network status.
 * @param params 
 */
onFriendListItemClick(params) {
  //check network and then go to the next page    
  this.navCtrl.push(ChatPage,{
    friendName:params.name,
    friendId:params.roleAssignmentId,
    senderName:window.localStorage.getItem('user_name'),
    senderId:window.localStorage.getItem('roleAssignmentId')
  });
  if(this.notificationfriendId == params.roleAssignmentId ){
    this.notificationfriendMsg=' ';
    this.counter=' ';
  }
}
  /** 
 * this method is unsubscribe the events of network connect and disconnected.
*/
ionViewWillLeave(){
  this.connected.unsubscribe();
  this.disconnected.unsubscribe();
}
}
