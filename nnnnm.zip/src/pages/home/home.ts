/**********************************************************************************
 * Class-name - HomePage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the HomePage page. 
 * HomePage have methods implementation to display pie charts,bar charts,Events and Notifications.
 *
 **********************************************************************************/
import { Component, ViewChild } from '@angular/core';
import { NavController, LoadingController, Slides, Platform, Events, MenuController, ModalController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Subscription} from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { Item } from '../../models/item';
import { EventDetailsPage } from '../event-details/event-details';
import { NotificationsPage } from '../notifications/notifications';
import { ContentDetailsPage } from '../content-details/content-details';
import { NotificationDetailsPage } from '../notification-details/notification-details';

import * as d3Scale from "d3-scale";
import * as d3Shape from "d3-shape";
import * as d3 from "d3";
import * as d3Array from "d3-array";
import * as d3Axis from "d3-axis";
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild('slides') slides: Slides;
  barshowbutton: boolean=true;
  title: string = 'pie chart';
  margin = {top: 35, right: 10, bottom: 40, left: 10};
  width: number;
  height: number;
  radius: number;
  
  arc: any;
  labelArc: any;
  labelPer:any;
  pie: any;
  color: any;
  svg:any;
  /*customization for amravati START*/
  //svg_ExamPerformance: any;
  /*customization for amravati END*/
  svg_Assignment:any;
  svg_MockTest:any;
  /*customization for amravati START*/
  //svg_TestPerformance:any;
  /*customization for amravati END*/
  svgchild:any;
  pietobar:boolean=false;
  barshow:boolean=true;
  barchildshow:boolean=true; 
  
  chartListDatachild:any[]=[];   
  pie_MockTestPerformance:any="pie_MockTestPerformance";
  pie_AssignmentPerformance:any='pie_AssignmentPerformance';
  /*customization for amravati START*/
  //pie_ExamPerformance:any='pie_ExamPerformance';
  //pie_RelativeTestPerformance:any='pie_RelativeTestPerformance';
  /*customization for amravati END*/
  barChartHeader:any;
  path:any;
  path_MockTest:any;
  path_Assignment:any;
  /*customization for amravati START*/
  //path_RelativeExam:any;
  //path_RelativeTest:any;
  /*customization for amravati END*/
  tooltip:any;
  x: any; y: any; g: any;
  red:any; green:any;blue:any;a:any;
  tooltips:any;
  childgraph:any;
  dynamicColors:any[]=[];
  color_add:any;
  /*customization for amravati START*/
  //public allExamMarks: any;
  //public allTestMarks: any;
  /*customization for amravati END*/
  public allAssignmentMarks: any;
  public allMockTestMarks: any;
  
  public mockTestList: any[];
  public assignmentMarksList:any[];
  /*customization for amravati START*/
  //public examMarksList:any[];
  //public testMarksList:any[];
  /*customization for amravati END*/
  
  // Event and Notification
  public eventList: any[];
  public notificationList: any[];
  notificatin:any;
  jsonStirng:any;
     
  hideNoEventsFound:boolean = true;
  hideNoNotification:boolean = true;
  
  notiUrl:string[];
  notiParam:string[];
  notificationCode:any;
  public notificationdetail: any;
  notificationDetailApiCall:any;
  public item:any;
  
  connected: Subscription;
  disconnected: Subscription;
  networkType:any; 
  menuOpened:boolean;
/**
 * constructor will call page loading and imports the classes
 * @param platform 
 * @param navCtrl  
 * @param network 
 * @param loading 
 * @param apiProvider 
 * @param popoverCtrl 
 * @param events 
 * @param menuCtrl 
 * @param modalCtrl 
 */
  constructor(public platform: Platform,public navCtrl: NavController,
  private network: Network,public loading: LoadingController,public apiProvider: ApiProvider,
  public modalCtrl: ModalController,public events: Events,public menuCtrl: MenuController,public updateVallidator:UpdateValidatorProvider) {
    this.checkNetwork();
    // d3js start
    this.width = 960 - this.margin.left - this.margin.right ;
    this.height = 500 - this.margin.top - this.margin.bottom;
    this.radius = Math.min(this.width, this.height) / 2;
  
    this.dashBoardServicecall();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });
  }
  /**
 * This method is  handle back button function.
 *
 */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }
      else{
        this.platform.exitApp();
      }
    });
  }
  /**
 * This method is generate to check the network status. 
 */
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.dashBoardServicecall();
    }, error => console.error(error));
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /**
  * This method is unsubscribe the events of network connect and disconnected.
  */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

/**
 * This method  for to getting data and
 * displaying the UI component.(graph data ,events and notifications)
 * @param url
 */
dashBoardServicecall(){
  let loader = this.loading.create({content : "Dashboard loading..."});  
  loader.present().then(() => {
    this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid'),"roleId":window.localStorage.getItem('roleid')};
    this.notificatin = this.apiProvider.post('dashboardGetNotifications',this.jsonStirng,'POST'); 
    this.notificatin.subscribe(data =>{
      this.allMockTestMarks = JSON.parse(data.allMockTestMarks); 
      this.mockTestList=this.allMockTestMarks;
      this.allAssignmentMarks = JSON.parse(data.allAssignmentMarks);
      this.assignmentMarksList=this.allAssignmentMarks;      
      /*customization for amravati START*/  
      //this.allExamMarks = JSON.parse(data.allExamMarks); 
      //this.examMarksList= this.allExamMarks;
      //this.allTestMarks = JSON.parse(data.allTestMarks);
      //this.testMarksList=this.allTestMarks;      
      /*customization for amravati END*/ 
      this.eventList = JSON.parse(data.eventList); 
      this.loadchart();
      this.notificationList = JSON.parse(data.notificationList);
      if(this.eventList.length===0){
        this.hideNoEventsFound = false;
      }else{
        this.hideNoEventsFound = true;
      }   
      if(this.notificationList.length===0){
        this.hideNoNotification = false;
      }else{
        this.hideNoNotification = true;
      }
      loader.dismiss();
    },(err) => {
      loader.dismiss();
    });
  });
}
/**
 * this methos is present the event details modal
 * @param item 
 */
showEventDetails(item: Item){ 
  let modal = this.modalCtrl.create(EventDetailsPage,item);
  modal.present({
  });
}
/**
 * this method is navigate to notification page
 */
goToNotification(){
  this.navCtrl.setRoot(NotificationsPage);
}
/**
 * this method is calling notofication details service call
 * @param params
*/
goToNotificationDetails(params){
  if(params.componentName==='QA'){
    this.notiUrl = (params.notificationURL).split('.'); 
    this.notiParam = (params.notificationURL).split('?');
    this.notificationCode = params.notificationCode;
    this.notificationDetailsServiceCall();
  }
  else if(params.componentName==='CM'){
    this.notiUrl = (params.notificationURL).split('.'); 
    this.notiParam = (params.notificationURL).split('?');
    this.notificationCode = params.notificationCode;
    this.navCtrl.push(ContentDetailsPage,{
      fromPage:"Notification",
      notificationCode: params.notificationCode,
      notificationUrl: this.notiUrl[0],
      notificationParameters: this.notiParam[1]
    });
  }
  else if(params.componentName==='MT'){
    this.updateVallidator.inProgressToast("Mock Test is in progress");
  }
  else{
    this.updateVallidator.inProgressToast("Details page is in progress");
  }
}
/**
 * this method is getting the notification data   
 */
 notificationDetailsServiceCall(){
  let loader = this.loading.create({content : "Loading ,please wait..."});  
  loader.present().then(() => {
    this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"parameterValues":this.notiParam[1]};
    this.notificationDetailApiCall = this.apiProvider.post(this.notiUrl[0],this.jsonStirng,'POST'); 
    this.notificationDetailApiCall.subscribe(data => {
      if(this.notificationCode==='QA001'){
        this.notificationdetail = JSON.parse(data.AssignmentNotificationDetails);
        for (let _i = 0; _i < this.notificationdetail.length; _i++) {
          this.item = this.notificationdetail[_i];
        }
        loader.dismiss();
        this.navCtrl.push(NotificationDetailsPage,{
          notificationCode: this.notificationCode,
          item:this.item
       });  
      }
      else if(this.notificationCode==='QA002'){
        this.notificationdetail = JSON.parse(data.TestNotificationDetails);
        for (let _i = 0; _i < this.notificationdetail.length; _i++) {
          this.item = this.notificationdetail[_i];
        }
        loader.dismiss();
        this.navCtrl.push(NotificationDetailsPage,{
          notificationCode: this.notificationCode,
          item:this.item
       });    
      }
      else if(this.notificationCode==='QA003'){
        this.notificationdetail = JSON.parse(data.ExamNotificationDetails);  
        for (let _i = 0; _i < this.notificationdetail.length; _i++) {
          this.item = this.notificationdetail[_i];
        }
        loader.dismiss();
        this.navCtrl.push(NotificationDetailsPage,{
          notificationCode: this.notificationCode,
          item:this.item
       });    
      }
      else if(this.notificationCode==='QA005'){
        this.notificationdetail = JSON.parse(data.AssignmentEvaluationNotificationDetails); 
        for (let _i = 0; _i < this.notificationdetail.length; _i++) {
          this.item = this.notificationdetail[_i];
        }
        loader.dismiss();
        this.navCtrl.push(NotificationDetailsPage,{
          notificationCode: this.notificationCode,
          item:this.item
       });     
      }
      else if(this.notificationCode==='QA006'){
        this.notificationdetail = JSON.parse(data.AssignmentSubmissionsNotificationDetails);
        for (let _i = 0; _i < this.notificationdetail.length; _i++) {
          this.item = this.notificationdetail[_i];
        }
        loader.dismiss();
        this.navCtrl.push(NotificationDetailsPage,{
          notificationCode: this.notificationCode,
          item:this.item
       });    
      }
    }, (err) => {
        loader.dismiss();
      });
   });
  }
/**
 * This method is used to load the all pie chart on the UI. 
 */
loadchart(){
  d3.select("#ioncardpie_MockTest").selectAll("svg").remove();
  d3.select("#ioncardpie_Assignment").selectAll("svg").remove();
  this.initSvgRelativeMockTest(this.mockTestList)
  this.drawPieRelativeMockTest(this.mockTestList);
  this.initSvgRelativeAssignment( this.assignmentMarksList)
  this.drawPieRelativeAssignment( this.assignmentMarksList);
  /*customization for amravati START*/
  //this.initSvgRelativeExam( this.examMarksList)
  //this.drawPieRelativeExam( this.examMarksList);
  //this.initSvgRelativeTest(this.testMarksList)
  //this.drawPieRelativeTest(this.testMarksList);   
  /*customization for amravati END*/
}
/**
 * this fuction is used to generate dynamic colors.
 * @param data 
 */
generateRGB(data:any){
  try {
    for (let _i = 0; _i < data.length; _i++){
      this.red = Math.floor(Math.random() * 255);
      this.green = Math.floor(Math.random() * 255);
      this.blue = Math.floor(Math.random() * 255);
      this.a = 0.7;
      this.color_add ='rgba(' + this.red + ',' + this.green + ',' + this.blue +','+ this.a + ')';
      this.dynamicColors.push(this.color_add);
  }
  return this.dynamicColors
  } catch (error) {
    alert("Please Try Again");
  }

}     
/************D3Js Pie chart**************************/
/**
 * This method is used to generate the SVG of RelativeMockTest pie chart.
 * @param pi
 * 
 */
initSvgRelativeMockTest(pi) {
  this.color = d3Scale.scaleOrdinal()
      .range(this.generateRGB(pi));
  this.arc = d3Shape.arc()
      .outerRadius(this.radius - 10)
      .innerRadius(0);
  this.labelArc = d3Shape.arc()
      .outerRadius(this.radius - 85)
      .innerRadius(this.radius - 100) ; 
  this.labelPer = d3Shape.arc()
      .outerRadius(this.radius -90)
      .innerRadius(this.radius -120);
  this.pie = d3Shape.pie()
      .sort(null)
      .value((d: any) => d.marks);  
      this.svg_MockTest = d3.select("#"+this.pie_MockTestPerformance)
      .append("svg")
      .attr("width", '100%')
      .attr("height", '100%')
      .attr('viewBox','0 0 '+Math.min(this.width,this.height)+' '+Math.min(this.width,this.height))
      .append("g")
      .attr("transform", "translate(" + Math.min(this.width,this.height) / 2 + "," + Math.min(this.width,this.height) / 2 + ")"); 
}
/**
 * This method is used draw arc of the RelativeMockTest  chart. 
 * @param pi 
 */
drawPieRelativeMockTest(pi) {
   let g= this.svg_MockTest.selectAll('.arc')
   .data(this.pie(pi))
   .enter()
   .append("g")
   .attr("class", "arc");
    this.path_MockTest= g.append("path").attr("d", this.arc)
    .style("fill", (d: any) => this.color(d.data.title,d.data.marks) )
    .style('stroke', 'white')
    .style('stroke-width', 2)
    .on("mouseover",(d)=>{
    this.tooltips = d3.select("#ioncardpie_MockTest")
    .append("div").attr("class","toolTip")
    .style("display", "block")
    .style('border','1px solid blue')
    .style('font-size','15px')
    .style("z-index", "10")
    .style("visibility", "hidden")
    .html((d.data.title) + " " + (d.data.marks) + "%");
    this.tooltips.style("visibility", "visible");})
    .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX-46)+"px");})
    .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");})
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")" )
     .attr("dy", "1.8em")
     .text((d: any) => d.data.title)
     .style("text-anchor", "middle");
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelPer.centroid(d) + ")" )
    .attr("dy", ".35em")
    .text((d: any) => d.data.marks + "%")
    .style("text-anchor", "middle")
    .attr("class", "arc")
  }
/**
  * This Method is used to generate the SVG of RelativeAssignment pie chart.
  * @param pi 
  */
  initSvgRelativeAssignment(pi) {  
    this.color = d3Scale.scaleOrdinal()
        .range(this.generateRGB(pi));
    this.arc = d3Shape.arc()
        .outerRadius(this.radius - 10)
        .innerRadius(0);
    this.labelArc = d3Shape.arc()
        .outerRadius(this.radius - 85)
        .innerRadius(this.radius - 100) ; 
    this.labelPer = d3Shape.arc()
        .outerRadius(this.radius -90)
        .innerRadius(this.radius -120);
    this.pie = d3Shape.pie()
        .sort(null)
        .value((d: any) => d.marks);  
    this.svg_Assignment = d3.select("#"+this.pie_AssignmentPerformance)
        .append("svg")
        .attr("width", '100%')
        .attr("height", '100%')
        .attr('viewBox','0 0 '+Math.min(this.width,this.height)+' '+Math.min(this.width,this.height))
        .append("g")
        .attr("transform", "translate(" + Math.min(this.width,this.height) / 2 + "," + Math.min(this.width,this.height) / 2 + ")");     
  } 
/**
 * This method is used draw an arc of the RelativeAssignment pie chart. 
 * @param pi 
 */
 drawPieRelativeAssignment(pi) {
        let g= this.svg_Assignment.selectAll('.arc')
        .data(this.pie(pi))
        .enter()
        .append("g")
        .attr("class", "arc");     
    this.path_Assignment= g.append("path").attr("d", this.arc)
        .style("fill", (d: any) => this.color(d.data.title,d.data.marks) )
        .style('stroke', 'white')
        .style('stroke-width', 2)
        .on("mouseover",(d)=>{
    this.tooltips = d3.select("#ioncardpie_Assignment")
        .append("div").attr("class","toolTip")
        .style("display", "block")
        .style('border','1px solid blue')
        .style('font-size','15px')
        .style("z-index", "1")
        .style("visibility", "hidden")
        .html((d.data.title) + " " + (d.data.marks) + "%");
    this.tooltips.style("visibility", "visible");})
        .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX-46)+"px");})
        .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");}) 
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")" )
        .attr("dy", "1.8em")
        .text((d: any) => d.data.title)
        .style("text-anchor", "middle");      
   g.append("text").attr("transform", (d: any) => "translate(" + this.labelPer.centroid(d) + ")" )
        .attr("dy", ".35em")
        .text((d: any) => d.data.marks + "%")
        .style("text-anchor", "middle")
        .attr("class", "arc")
   }

              /*customization for amravati START*/
/**
 * This method is used to generate the SVG of RelativeExam pie chart.
 * @param pi 
 * Comented as per atihaLMS(amravati) customization guidelines
 */
  // initSvgRelativeExam(pi) { 
  //   this.color = d3Scale.scaleOrdinal()
  //     .range(this.generateRGB(pi));
  //   this.arc = d3Shape.arc()
  //     .outerRadius(this.radius - 10)
  //     .innerRadius(0);
  //   this.labelArc = d3Shape.arc()
  //     .outerRadius(this.radius - 85)
  //     .innerRadius(this.radius - 100) ;  
  //   this.labelPer = d3Shape.arc()
  //     .outerRadius(this.radius -90)
  //     .innerRadius(this.radius -120);
  //   this.pie = d3Shape.pie()
  //     .sort(null)
  //     .value((d: any) => d.marks);   
  //   this.svg_ExamPerformance = d3.select("#"+this.pie_ExamPerformance)
  //     .append("svg")
  //     .attr("width", '100%')
  //     .attr("height", '100%')
  //     .attr('viewBox','0 0 '+Math.min(this.width,this.height)+' '+Math.min(this.width,this.height))
  //     .append("g")
  //     .attr("transform", "translate(" + Math.min(this.width,this.height) / 2 + "," + Math.min(this.width,this.height) / 2 + ")")  ;  
  //  }
/**
  * This is used draw an arc of the draw RelativeExam Pie chart. 
  * @param pi 
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // drawPieRelativeExam(pi) {
  //     let g=this.svg_ExamPerformance.selectAll('.arc')
  //     .data(this.pie(pi))
  //     .enter()
  //     .append("g")
  //     .attr("class", "arc");   
  //   this.path_RelativeExam= g.append("path").attr("d", this.arc)
  //     .style("fill", (d: any) => this.color(d.data.courseName,d.data.marks) )
  //     .style('stroke', 'white')
  //     .style('stroke-width', 1)
  //     .on("mouseover",(d)=>{
  //   this.tooltips = d3.select("#ioncardpie_ExamPerformance")
  //     .append("div").attr("class","toolTip")
  //     .style("position", "absolute")
  //     .style("display", "block")
  //     .style('border','1px solid blue')
  //     .style('font-size','15px')
  //     .style("z-index", "10")
  //     .style("visibility", "hidden")
  //     .html((d.data.courseName) + " " + (d.data.marks) + "%");    
  //   this.tooltips.style("visibility", "visible");})
  //     .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX- 46)+"px");})
  //     .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");})
  //   g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")" )
  //     .attr("dy", "1.8em")
  //     .text((d: any) => d.data.courseName)
  //     .style("text-anchor", "middle") ;     
  //   g.append("text").attr("transform", (d: any) => "translate(" + this.labelPer.centroid(d) + ")" )
  //     .attr("dy", ".35em")
  //     .text((d: any) => d.data.marks + "%")
  //     .style("text-anchor", "middle")
  //     .attr("class", "arc")   
  // }
/**
  * This method is used to generate the SVG of initSvgRelativeTest pie chart.
  * @param pi 
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // initSvgRelativeTest(pi) {
  //   this.color = d3Scale.scaleOrdinal()
  //     .range(this.generateRGB(pi)) ;
  //   this.arc = d3Shape.arc()
  //     .outerRadius(this.radius - 10)
  //     .innerRadius(0);
  //   this.labelArc = d3Shape.arc()
  //     .outerRadius(this.radius - 85)
  //     .innerRadius(this.radius - 100) ;
  //   this.labelPer = d3Shape.arc()
  //     .outerRadius(this.radius -90)
  //     .innerRadius(this.radius -120);
  //   this.pie = d3Shape.pie()
  //     .sort(null)
  //     .value((d: any) => d.marks);   
  //   this.svg_TestPerformance = d3.select("#"+this.pie_RelativeTestPerformance)
  //     .append("svg")
  //     .attr("width", '100%')
  //     .attr("height", '100%')
  //     .attr('viewBox','0 0 '+Math.min(this.width,this.height)+' '+Math.min(this.width,this.height))
  //     .append("g")
  //     .attr("transform", "translate(" + Math.min(this.width,this.height) / 2 + "," + Math.min(this.width,this.height) / 2 + ")");    
  // }
/**
  * This method is used draw an arc of the RelativeTest pie chart. 
  * @param pi 
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // drawPieRelativeTest(pi) { 
  //   let g=this.svg_TestPerformance.selectAll('.arc')
  //     .data(this.pie(pi))
  //     .enter()
  //     .append("g")
  //     .attr("class", "arc");  
  //   this.path_RelativeTest= g.append("path").attr("d", this.arc)
  //     .style("fill", (d: any) => this.color(d.data.courseName,d.data.marks) )
  //     .style('stroke', 'white')
  //     .style('stroke-width', 1)
  //     .on("mouseover",(d)=>{
  //   this.tooltips = d3.select("#ioncardpie_TestPerformance")
  //     .append("div").attr("class","toolTip")
  //     .style("position", "absolute")
  //     .style("display", "block")
  //     .style('border','1px solid blue')
  //     .style('font-size','15px')
  //     .style("z-index", "10")
  //     .style("visibility", "hidden")
  //     .html((d.data.courseName) + " " + (d.data.marks) + "%");     
  //   this.tooltips.style("visibility", "visible");})
  //     .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX-46)+"px");})
  //     .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");}) 
  //   g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")" )
  //     .attr("dy", "1.8em")
  //     .text((d: any) => d.data.courseName)
  //     .style("text-anchor", "middle");         
  //   g.append("text").attr("transform", (d: any) => "translate(" + this.labelPer.centroid(d) + ")" )
  //     .attr("dy", ".35em")
  //     .text((d: any) => d.data.marks + "%")
  //     .style("text-anchor", "middle")
  //     .attr("class", "arc")    
  // }

            /*customization for amravati END*/

//**************************bar chart********************************* */     
 /**
  * This method is used to call the all barchart design method.
  * @param bar  
  */
  BarChartMockTest_Assignment(bar){
    this.barSvgMockTest_Assignment(bar);
    this.initAxisMockTest_Assignment(bar);
    this.drawAxisMockTest_Assignment();
    this.drawBarsMockTest_Assignment(bar);
   }
/**
  * This method is used to generate the svg of the MockTest and Assignment bar chart.
  * @param bar  
  */
  barSvgMockTest_Assignment(bar) {
    let currentIndex = this.slides.getActiveIndex();
    if(currentIndex==0){
        this.barChartHeader="Mock Test Result";   
    }if(currentIndex==1){
      this.barChartHeader="Assignment Result";
    } 
    this.color = d3Scale.scaleOrdinal()
    .range(this.generateRGB(bar));
    this.svg = d3.select("#parentbarchart")
      .append("svg")
      .attr("width", '100%')
      .attr("height", '100%')
      .attr('viewBox','0 0 960 600')
      .append("g")
    this.svg.append("text")
      .attr("x",(this.width)/2)
      .attr("y",(this.margin.top))
      .attr("text-anchor","middle")
      .attr('fill','blue')
      .attr("font-weight","bold")
      .style("font-size","35px")
      .style("text-decoration","underline")
      .text(this.barChartHeader);
  var legend = this.svg.selectAll(".legend")
      .data(bar.slice())
      .enter().append("g")
      .attr("class", "legend")
      .attr("y",(this.margin.top+5))
      .attr("transform", function(d, i) { return "translate(0," + i * 30 + ")"; });
  legend.append("rect")
      .attr("x", this.width)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill",(d) => this.color(d.title));
  legend.append("text")
      .attr("x", this.width - 8)
      .attr("y", 10)
      .attr("dy", ".30em")
      .style("class","legend_text")
      .style("text-anchor", "end")
      .text(function(d) { return d.title; });
    this.g = this.svg.append("g")
      .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
  }
/**
  * This method is used to generate the axis scale of the MockTest and Assignment  of bar chart. 
  * @param bar 
  */
  initAxisMockTest_Assignment(bar) {
      this.x = d3Scale.scaleLinear().range([0, this.width*4/5]).nice();
      this.y = d3Scale.scaleBand().range([this.height, 0]).padding(0.2);
      this.y.domain(bar.map((d) => d.title));
      let currentIndex = this.slides.getActiveIndex();
      if(currentIndex==0){
        this.x.domain([0, d3Array.max(this.mockTestList, (d) => d.marks)]);      
      }if(currentIndex==1){
        this.x.domain([0, d3Array.max(this.assignmentMarksList, (d) => d.marks)]);
      }
}
/**
  * This Method is used to set the axis value.
  */
  drawAxisMockTest_Assignment() {
    this.g.append("g")
      .attr("class", "axis--x")
      .attr("transform", "translate(0," + this.height + ")")
      .call(d3Axis.axisBottom(this.x))
      .append("text")
      .attr("x",(this.width)/2)
      .attr("y",(this.margin.bottom+39))
      .style("text-anchor", "middle")
      .attr("font-weight","bold")
      .style("font-size","30px")
      .text("Mark Secured"); 
    this.g.append("g")
      .attr("class", "axis--y")
      .call(d3Axis.axisLeft(this.y))
      .append("text")
      .attr("z-index","3")
      .style("text-anchor", "begin")
    }
/**
 * This Method is used to draw the bar of MockTest and Assignment.
 * @param bar 
 */
 drawBarsMockTest_Assignment(bar) { 
    this.g.selectAll(".bar")
      .data(bar)
      .enter().append("rect")
      .attr("class", "bar")
      .attr("x",0 )
      .attr("width", (d) => this.x(d.marks) )
      .attr("y", (d) => this.y(d.title) )
      .style("fill", (d: any) => this.color(d.title) )
      .attr("height", this.y.bandwidth())
      .on("click",(d)=> {
        if(d.mockTestMarksDomains){
          this.BarChartchildMockTest_Assignment(d.mockTestMarksDomains);
         }
        else{
          this.BarChartchildMockTest_Assignment(d.assignmentMarksDomains);
        }
      });
  }

              /*customization for amravati START*/
/**
  * This method is used to call the all Exam and Relative Test .
  * @param bar  
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // BarChartExam_RelativeTest(bar){  
  //   let currentIndex = this.slides.getActiveIndex();
  //   if(currentIndex==2){
  //     this.barChartHeader="Exam Result";
  //   }if(currentIndex==3){
  //     this.barChartHeader="Test Result";
  //   }
  //     this.barSvgExam_RelativeTest(bar);
  //     this.initAxisExam_RelativeTest(bar);
  //     this.drawAxisExam_RelativeTest();
  //     this.drawBarsExam_RelativeTest(bar);
  // }
/**
  * This Method is used to generate the svg of the Exam and RelativeTest bar chart.
  * @param bar  
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // barSvgExam_RelativeTest(bar) {
  //   this.color = d3Scale.scaleOrdinal().range(this.generateRGB(bar));
  //   this.svg = d3.select("#parentbarchart")
  //     .append("svg")
  //     .attr("width", '100%')
  //     .attr("height", '100%')
  //     .attr('viewBox','0 0 960 600')
  //     .append("g")
  //   this.svg.append("text")
  //     .attr("x",(this.width)/2)
  //     .attr("y",(this.margin.top))
  //     .attr("text-anchor","middle")
  //     .attr('fill','blue')
  //     .attr("font-weight","bold")
  //     .style("font-size","35px")
  //     .style("text-decoration","underline")
  //     .text(this.barChartHeader)
  // var legend = this.svg.selectAll(".legend")
  //     .data(bar.slice())
  //     .enter().append("g")
  //     .attr("class", "legend")
  //     .attr("transform", function(d, i) { return "translate(0," + i * 30 + ")"; });
  // legend.append("rect")
  //     .attr("x", this.width)
  //     .attr("width", 18)
  //     .attr("height", 18)
  //     .style("fill",(d) => this.color(d.courseName));
  // legend.append("text")
  //     .attr("x", this.width - 8)
  //     .attr("y", 10)
  //     .attr("dy", ".30em")
  //     .style("class","legend_text")
  //     .style("text-anchor", "end")
  //     .text(function(d) { return d.courseName; });
  //   this.g = this.svg.append("g")
  //    .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");  
  //   } 
/**
  * This method is used to generate the axis scale of the Axis Exam and RelativeTest  of bar chart. 
  * @param bar 
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // initAxisExam_RelativeTest(bar) {
  //   this.x = d3Scale.scaleLinear().range([0, this.width*4/5]).nice();
  //   this.y = d3Scale.scaleBand().range([this.height, 0]).padding(0.2);
  //   this.y.domain(bar.map((d) => d.courseName));
  //   let currentIndex = this.slides.getActiveIndex();
  //   if(currentIndex==2){
  //     this.x.domain([0, d3Array.max(this.mockTestList, (d) => d.marks)]);
  //   }if(currentIndex==3){
  //     this.x.domain([0, d3Array.max(this.assignmentMarksList, (d) => d.marks)]);
  //   } 
  //  }

  /**
  * This method is used to set the axis value.
  * Comented as per atihaLMS(amravati) customization guidelines
  */
  // drawAxisExam_RelativeTest() {
  //   this.g.append("g")
  //     .attr("class", "axis--x")
  //     .attr("transform", "translate(0," + this.height + ")")
  //     .call(d3Axis.axisBottom(this.x))
  //     .append("text")
  //     .attr("x",(this.width)/2)
  //     .attr("y",(this.margin.bottom+39))
  //     .style("text-anchor", "middle")
  //     .attr("font-weight","bold")
  //     .style("font-size","30px")
  //     .text("Mark Secured");
  
  //   this.g.append("g")
  //     .attr("class", "axis--y")
  //     .call(d3Axis.axisLeft(this.y))
  //     .append("text")
  //     .attr("dy", "1em")
  // }
/**
 * This method is used to draw the bar of Exam and RelativeTest.
 * @param bar 
 * Comented as per atihaLMS(amravati) customization guidelines
 */
  // drawBarsExam_RelativeTest(bar) {   
  //   this.g.selectAll(".bar")
  //     .data(bar)
  //     .enter().append("rect")
  //     .attr("class", "bar")
  //     .attr("x",0 )
  //     .attr("width", (d) => this.x(d.marks) )
  //     .attr("y", (d) => this.y(d.courseName) )
  //     .style("fill", (d: any) => this.color(d.courseName) )
  //     .attr("height", this.y.bandwidth())
  //     .on("click",(d)=> {
  //       let currentIndex = this.slides.getActiveIndex();
  //       if(currentIndex==2){
  //          this.BarChartchild_RelativeTestexam(d.examMarksDomains);
  //       }if(currentIndex==3){
  //         this.BarChartchild_RelativeTest(d.testMarksDomains);
  //       }
  //     });
  // }

              /*customization for amravati END*/

 /**
  * This method is used to call the all MockTest and Assignment child chart method.
  * @param d  
  */                                                                       
  BarChartchildMockTest_Assignment(d){
    this.barshow=true;
    this.barshowbutton=true;
    this.barchildshow=false;  
    this.chartListDatachild  = d;    
    this.barSvgchildMockTest_Assignment(d);
    this.initAxischildMockTest_Assignment();
    this.drawAxischildMockTest_Assignment();
    this.drawBarschilddMockTest_Assignment(d);
 }
/**
  *  This method is used to generate the svg of the MockTest and Assignment bar chart.
  * @param d  
  */
  barSvgchildMockTest_Assignment(d) {
    let currentIndex = this.slides.getActiveIndex();
    if(currentIndex==0){
    this.barChartHeader="Mock Test Result"; 
    }if(currentIndex==1){
    this.barChartHeader="Assignment Result";
    }
    this.color = d3Scale.scaleOrdinal().range(this.generateRGB(this.chartListDatachild));
    this.svgchild = d3.select("#chartname")
      .append("svg")
      .attr("width", '100%')
      .attr("height", '100%')
     .attr('viewBox','0 0 960 600');
    this.svgchild.append("text")
      .attr("x",(this.width)/2)
      .attr("y",(this.margin.top))
      .attr("text-anchor","middle")
      .attr('fill','blue')
      .attr("font-weight","bold")
      .style("font-size","35px")
      .style("text-decoration","underline")
      .text(this.barChartHeader);
  var legend =this.svgchild.selectAll(".legend")
      .data(d.slice())
      .enter().append("g")
      .attr("class", "legend")
      .attr("transform", function(d, i) { return "translate(0," + i * 30 + ")"; });
  legend.append("rect")
      .attr("x", this.width)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill",(d) => this.color(d.title));
  legend.append("text")
      .attr("x", this.width - 8)
      .attr("y", 10)
      .attr("dy", ".30em")
      .style("class","legend_text")
      .style("text-anchor", "end")
      .text(function(d) { return d.title; });
    
    this.childgraph = this.svgchild.append("g")
      .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");      
     }
/**
  * This method is used to generate the axis scale of the Axis MockTest and Assignment of bar chart. 
  *  
  */
  initAxischildMockTest_Assignment(  ) {
    this.x = d3Scale.scaleLinear().range([0, this.width*4/5]).nice();
    this.y = d3Scale.scaleBand().range([this.height, 0]).padding(0.2);
    this.y.domain(this.chartListDatachild.map((d) => d.title));
    let currentIndex = this.slides.getActiveIndex();
    if(currentIndex==0){
    this.x.domain([0, d3Array.max(this.chartListDatachild, (d) => d.marks)]);
    }if(currentIndex==1){
    this.x.domain([0, d3Array.max(this.chartListDatachild, (d) => d.marks)]);
    }   
  }
/**
  * This method is used to set the axis value.
 */
  drawAxischildMockTest_Assignment() {
    this.childgraph.append("g")
      .attr("class", "axis--x")
      .attr("transform", "translate(0," + this.height + ")")
      .call(d3Axis.axisBottom(this.x))
      .append("text")
      .attr("x",(this.width)/2)
      .attr("y",(this.margin.bottom+39))
      .style("text-anchor", "middle")
      .attr("font-weight","bold")
      .style("font-size","30px")
      .text("Mark Secured");

    this.childgraph.append("g")
      .attr("class", "axis--y")
      .call(d3Axis.axisLeft(this.y))
      .append("text")
      .attr("class", "axis-title")
      .attr("dy", "1em")
     
    }
/**
 * This method is used to draw the bar of MockTest and Assignment.
 * @param d
 */
  drawBarschilddMockTest_Assignment(d) {
    this.childgraph.selectAll(".bar")
      .data(this.chartListDatachild)
      .enter().append("rect")
      .attr("class", "bar")
      .attr("x",0 )
      .attr("width", (d) => this.x(d.marks) )
      .attr("y", (d) => this.y(d.title) )
      .style("fill", (d: any) => this.color(d.title) )
      .attr("height", this.y.bandwidth())
      .on("mouseover",(d)=>{
    this.tooltips = d3.select("#ioncardchildbar")
      .append("div").attr("class","toolTip")
      .style("display", "block")
      .style('border','1px solid blue')
      .style('font-size','15px')
      .style("z-index", "1")
      .style("visibility", "hidden")
      .html((d.title) + " " + (d.marks) + "%");
      
    this.tooltips.style("visibility", "visible");})
      .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX- 50)+"px");})
      .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");});
    }

                  /*customization for amravati START*/
/**
  * This method is used to call the all barchart function.
  * @param d 
  * Comented as per atihaLMS(amravati) customization guidelines
  */                                                                  
  // BarChartchild_RelativeTestexam(d){
  //   console.log("child data:",d);
  //   this.barshow=true;
  //   this.barshowbutton=true;
  //   this.barchildshow=false;  
  //   this.chartListDatachild  = d;
  //   this.barSvgchild_RelativeTestexam(d);
  //   this.initAxischild_RelativeTestexam();
  //   this.drawAxischild_RelativeTestexam();
  //   this.drawBarschildd_RelativeTestexam(d);
  //   }
  /**
    * this method is used to generate the svg of the RelativeTestexam bar chart.
    * @param d  
    * Comented as per atihaLMS(amravati) customization guidelines
    */
  // barSvgchild_RelativeTestexam(d) {
  //   this.barChartHeader="Exam Result"
  //   this.color = d3Scale.scaleOrdinal()
  //     .range(this.generateRGB(this.chartListDatachild)) ;
  //   this.svgchild = d3.select("#chartname")
  //     .append("svg")
  //     .attr("width", '100%')
  //     .attr("height", '100%')
  //     .attr('viewBox','0 0 960 600');
  //  this.svgchild.append("text")
  //     .attr("x",(this.width)/2)
  //     .attr("y",(this.margin.top))
  //     .attr("text-anchor","middle")
  //     .attr('fill','blue')
  //     .attr("font-weight","bold")
  //     .style("font-size","35px")
  //     .style("text-decoration","underline")
  //     .text(this.barChartHeader)
  // var legend = this.svgchild.selectAll(".legend")
  //     .data(d.slice())
  //     .enter().append("g")
  //     .attr("class", "legend")
  //     .attr("transform", function(d, i) { return "translate(0," + i * 30 + ")"; });
  // legend.append("rect")
  //     .attr("x", this.width)
  //     .attr("width", 18)
  //     .attr("height", 18)
  //     .style("fill",(d) => this.color(d.examTitle));
  // legend.append("text")
  //     .attr("x", this.width - 8)
  //     .attr("y", 10)
  //     .attr("dy", ".30em")
  //     .style("class","legend_text")
  //     .style("text-anchor", "end")
  //     .text(function(d) { return d.examTitle; });
    
  //   this.childgraph = this.svgchild.append("g")
  //     .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
       
  //   this.childgraph = this.svgchild.append("g")
  //     .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
  // }

  /**
   * This method is used to generate the axis scale of the Axis RelativeTestexam  of child bar chart. 
   *  Comented as per atihaLMS(amravati) customization guidelines
   */
  // initAxischild_RelativeTestexam() {
  //   this.x = d3Scale.scaleLinear().range([0, this.width*4/5]).nice();
  //   this.y = d3Scale.scaleBand().range([this.height, 0]).padding(0.2);
  //   this.y.domain(this.chartListDatachild.map((d) => d.examTitle));
  //  // let currentIndex = this.slides.getActiveIndex();
  //   this.x.domain([0, d3Array.max(this.chartListDatachild, (d) => d.examMarks)]);  
  // }

  /**
   *This method is used to set the axis value.
   *Comented as per atihaLMS(amravati) customization guidelines
   */
  // drawAxischild_RelativeTestexam() {
  //   this.childgraph.append("g")
  //     .attr("class", "axis--x")
  //     .attr("transform", "translate(0," + this.height + ")")
  //     .call(d3Axis.axisBottom(this.x))
  //     .append("text")
  //     .attr("x",(this.width)/2)
  //     .attr("y",(this.margin.bottom+39))
  //     .style("text-anchor", "middle")
  //     .attr("font-weight","bold")
  //     .style("font-size","30px")
  //     .text("Mark Secured");
  //     this.childgraph.append("g")
  //     .attr("class", "axis--y")
  //     .call(d3Axis.axisLeft(this.y))
  //     .append("text")
  //     .attr("class", "axis-title")
  //     .attr("dy", "1em")  
  // }
     
/**
 * This method is used to draw the bar of RelativeTestexamt.
 * @param d
 * Comented as per atihaLMS(amravati) customization guidelines
 */    
  // drawBarschildd_RelativeTestexam(d) {
  //   this.childgraph.selectAll(".bar")
  //     .data(this.chartListDatachild)
  //     .enter().append("rect")
  //     .attr("class", "bar")
  //     .attr("x",0 )
  //     .attr("width", (d) => this.x(d.examMarks) )
  //     .attr("y", (d) => this.y(d.examTitle) )
  //     .style("fill", (d: any) => this.color(d.examTitle) )
  //     .attr("height", this.y.bandwidth())
  //     .on("mouseover",(d)=>{
  //   this.tooltips = d3.select("#ioncardchildbar")
  //     .append("div").attr("class","toolTip")
  //     .style("position", "absolute")
  //     .style("display", "block")
  //     .style('border','1px solid blue')
  //     .style('font-size','15px')
  //     .style("z-index", "10")
  //     .style("visibility", "hidden")
  //     .html((d.examTitle) + " " + (d.examMarks) + "%");
  //      this.tooltips.style("visibility", "visible");})
  //     .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX-50)+"px");})
  //     .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");});          
  // }
 /**
  * This method is used to call the all child bar chart method of Relative test.
  * @param d 
  * Comented as per atihaLMS(amravati) customization guidelines
  */  
  // BarChartchild_RelativeTest(d){
  //   console.log("child data:",d);
  //   this.barshow=true;
  //   this.barshowbutton=true;
  //   this.barchildshow=false;  
  //   this.chartListDatachild  = d; 
  //   this.barSvgchild_RelativeTest(d);
  //   this.initAxischild_RelativeTest();
  //   this.drawAxischild_RelativeTest();
  //   this.drawBarschildd_RelativeTest(d);
  //   }
/**
 * This method is used to generate the svg of the  Relative Test child bar chart.
 * @param d  
 * Comented as per atihaLMS(amravati) customization guidelines
 */
//  barSvgchild_RelativeTest(d) {
//   this.barChartHeader="Test Result"
//   this.color = d3Scale.scaleOrdinal()
//   .range(this.generateRGB(this.chartListDatachild)) ;
//   this.svgchild = d3.select("#chartname")
//     .append("svg")
//     .attr("width", '100%')
//     .attr("height", '100%')
//     .attr('viewBox','0 0 960 600');
//   this.svgchild.append("text")
//     .attr("x",(this.width)/2)
//     .attr("y",(this.margin.top))
//     .attr("text-anchor","middle")
//     .attr('fill','blue')
//     .attr("font-weight","bold")
//     .style("font-size","35px")
//     .style("text-decoration","underline")
//     .text(this.barChartHeader)
// var legend = this.svgchild.selectAll(".legend")
//     .data(d.slice())
//     .enter().append("g")
//     .attr("class", "legend")
//     .attr("transform", function(d, i) { return "translate(0," + i * 30 + ")"; });
// legend.append("rect")
//     .attr("x", this.width)
//     .attr("width", 18)
//     .attr("height", 18)
//     .style("fill",(d) => this.color(d.testTitle));
// legend.append("text")
//     .attr("x", this.width - 8)
//     .attr("y", 10)
//     .attr("dy", ".30em")
//     .style("class","legend_text")
//     .style("text-anchor", "end")
//     .text(function(d) { return d.testTitle; });
//   this.childgraph = this.svgchild.append("g")
//     .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");  
//     }

 /**
 * This method is used to generate the axis scale of the Axis RelativeTest of child bar chart. 
 * Comented as per atihaLMS(amravati) customization guidelines
 */
//   initAxischild_RelativeTest() {
//     this.x = d3Scale.scaleLinear().range([0, this.width*4/5]).nice();
//     this.y = d3Scale.scaleBand().range([this.height, 0]).padding(0.2);
//     this.y.domain(this.chartListDatachild.map((d) => d.testTitle));
//     this.x.domain([0, d3Array.max(this.chartListDatachild, (d) => d.testMark)]); 
// }

 /**
 * This Method is used to set the axis value.
 * Comented as per atihaLMS(amravati) customization guidelines
 */
  // drawAxischild_RelativeTest() {
  //   this.childgraph.append("g")
  //     .attr("class", "axis--x")
  //     .attr("transform", "translate(0," + this.height + ")")
  //     .call(d3Axis.axisBottom(this.x))
  //     .append("text")
  //     .attr("x",(this.width)/2)
  //     .attr("y",(this.margin.bottom+39))
  //     .style("text-anchor", "middle")
  //     .attr("font-weight","bold")
  //     .style("font-size","30px")
  //     .text("Mark Secured");
  //  this.childgraph.append("g")
  //     .attr("class", "axis--y")
  //     .call(d3Axis.axisLeft(this.y))
  //     .append("text")
  //     .attr("class", "axis-title")
  //     .attr("dy", "1em")
     
  //   }
/**
 * This method is used to draw the child bar chart of RelativeTest.
 * @param d
 * Comented as per atihaLMS(amravati) customization guidelines
 */  
  // drawBarschildd_RelativeTest(d) {
  //   this.childgraph.selectAll(".bar")
  //     .data(this.chartListDatachild)
  //     .enter().append("rect")
  //     .attr("class", "bar")
  //     .attr("x",0 )
  //     .attr("width", (d) => this.x(d.testMark) )
  //     .attr("y", (d) => this.y(d.testTitle) )
  //     .style("fill", (d: any) => this.color(d.testTitle) )
  //     .attr("height", this.y.bandwidth())
  //     .on("mouseover",(d)=>{
  //     this.tooltips = d3.select("#ioncardchildbar")
  //      .append("div").attr("class","toolTip")
  //      .style("position", "absolute")
  //      .style("display", "block")
  //      .style('border','1px solid blue')
  //      .style('font-size','15px')
  //      .style("z-index", "10")
  //      .style("visibility", "hidden")
  //      .html((d.testTitle) + " " + (d.testMark) + "%");      
  //     this.tooltips.style("visibility", "visible");})
  //       .on("mousemove", (d)=>{return this.tooltips.style("top", (d3.event.pageY-30)+"px").style("left",(d3.event.pageX-50)+"px");})
  //       .on("mouseout", (d)=>{return this.tooltips.style("visibility", "hidden");});
  // }  

              /*customization for amravati END*/
/**
 *This method is used to display back to pie chart   
 */
  backtopiechart(){
    d3.select("#parentbarchart").selectAll("svg").remove();
    d3.select("#chartname").selectAll("svg").remove();
    this.pietobar=false;   
    this.barshow=true; 
    this.barchildshow=true; 
  }
/**
* This method is used to display bar chart  and hide the pie chart. 
*/   
 BarChartshow(){

    
    let currentIndex = this.slides.getActiveIndex();
    if(currentIndex==0){

      if(this.mockTestList.length !=0){
        this.pietobar=true;
        this.barshow=false;
        this.barshowbutton=false;
        this.barchildshow=true; 
        this.BarChartMockTest_Assignment(this.mockTestList)
      }
    }
    if(currentIndex==1){
      if(this.assignmentMarksList.length !=0){
        this.pietobar=true; 
        this.barshow=false; 
        this.barshowbutton=false;
        this.barchildshow=true; 
        this.BarChartMockTest_Assignment(this.assignmentMarksList)
      }   
    }
    /*customization for amravati START*/
    // if(currentIndex==2){
    //   if(this.examMarksList.length !=0){
    //     this.pietobar=true; 
    //     this.barshow=false; 
    //     this.barshowbutton=false;
    //     this.barchildshow=true; 
    //     this.BarChartExam_RelativeTest(this.examMarksList)
    //   }
    // }
    // if(currentIndex==3){
    //   if(this.testMarksList.length !=0){
    //     this.pietobar=true; 
    //     this.barshow=false; 
    //     this.barshowbutton=false;
    //     this.barchildshow=true; 
    //     this.BarChartExam_RelativeTest(this.testMarksList)
    //   } 
    // }
    /*customization for amravati START*/
  }
/**
 * This method is used to display child to parent bar child
 */
  backtobarchart(){
    d3.select("#chartname").selectAll("svg").remove();
    this.barshow=false;
    this.barshowbutton=false;
    this.barchildshow=true;
  }
}
