/**********************************************************************************
 * Class-name - LoginPage
 * Version -1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 * Generated class for the LoginPage page.
 * LoginPage have methods implementation to perform, checkNetwork for check network status
 * goToHome for fields validation  and call services, configurationPrompt for server configuration,
 * loginValidationUpdate check connection state,
 * Service call userRoleServiceCall,userLoginServiceCall
 * 
 **********************************************************************************/
import { Component} from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, MenuController, Platform, Events } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Observable } from 'rxjs/Observable';
import { ApiProvider } from '../../providers/api/api';
import { HomePage } from '../home/home';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { Device } from '@ionic-native/device';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  username: any;
  password:any
  loginSucess: Observable<any>;
  roleSuccess: Observable<any>;
  ipaddress:any;
  port:any;
  loginServiceParameters:any;
  roleServiceParameters: any;
  roleId:any;
  roleLevelId:any;

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  clientUUID:any;
  sessionRefreshApiCall:any;
  jsonStirng:any;

  backgroundImage:any;

  constructor(public platform: Platform,public menu: MenuController,public navCtrl: NavController,public navParams: NavParams,
  public storage: Storage,public apiProvider :ApiProvider,public loading: LoadingController,private network: Network,
  public events: Events,private device: Device,public updateVallidator:UpdateValidatorProvider) {
    this.backgroundImage = this.apiProvider.fileAccessURL+"LoginBackground/login_background.png";
    this.checkNetwork();
  }

  /**
   * Here menu is disabled and back button is registered 
   */
  ionViewDidEnter() {
    this.menu.enable(false);
    this.menu.swipeEnable(false);
    
    this.platform.registerBackButtonAction(() => {
      this.platform.exitApp();
    });
  }

  /**
   * Don't forget to return the swipe to normal, otherwise 
   * the rest of the pages won't be able to swipe to open menu
   * connection event is unsubscribed
   * 
   */
  ionViewWillLeave() { 
    this.menu.enable(true);
    this.menu.swipeEnable(true);
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
   }

/**
 * this method to check network status 'connect/disconnect' otherwise show error. 
 */
  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
/**
 * this method check network status and validation for username,password fields cannot be empty.
 */
  goToHome(){
    if(this.networkType==='offline'){
      this.updateVallidator.connectionErrorAlert("Connection Error","Check your connection and try again later");
    }else{
      this.userRoleServiceCall(); 
    }
  }

/**
 * this service for user role and call api provider
 * @param url 
 */
  userRoleServiceCall(){
    console.log("user name : ",this.username);
    console.log("password : ",this.password);
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.roleServiceParameters={"userEmail":this.username};
      this.roleSuccess = this.apiProvider.post('getUserRoles',this.roleServiceParameters,'POST');
      this.roleSuccess.subscribe(data =>{
        console.log("user role response : ",data);
        if(data.UserRoles!=null){
          JSON.parse(data.UserRoles).forEach(element => {
            this.roleId = element.roleId;
            this.roleLevelId = element.roleLevelId
          });
          loader.dismiss();
          this.userLoginServiceCall();
        }
        else{
          loader.dismiss();
          this.updateVallidator.validationUpdateToast("Invalid UserName or password. Try again with correct credentials");
        }
      },(err) => {
        loader.dismiss();
        this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
      });
    });
  }
/**
 * this method for user log in and check Sucess/failure,authentication.
 * @param url 
 */
  userLoginServiceCall(){
    this.clientUUID = this.device.uuid;
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.loginServiceParameters={"userEmail":this.username,"userPassword":this.password,"UUID":this.clientUUID,"roleId":this.roleId};
      this.loginSucess = this.apiProvider.post('authenticate',this.loginServiceParameters,'POST');
      this.loginSucess.subscribe(data => {   
        console.log("login response : ",data);   
        if(data.UserId==='Userdetailsdonotexits'){
          this.updateVallidator.validationUpdateToast("Invalid UserName or password. Try again with correct credentials");
        }
        else if(data.UserId==='Failure'){
          this.updateVallidator.validationUpdateToast("Failed in getting user details. Try again later");
        }
        else{
          window.localStorage.setItem('userid', data.UserId);
          window.localStorage.setItem('user_email',this.username);
          window.localStorage.setItem('user_name',data.UserFirstName+data.UserLastName);
          window.localStorage.setItem('roleid',this.roleId);
          window.localStorage.setItem('rolelevelid',this.roleLevelId);
          window.localStorage.setItem('roleAssignmentId',data.roleAssignmentId);
          window.localStorage.setItem('threadid',data.ThreadId);
          window.localStorage.setItem('serverip',data.IPv4Address);
          window.localStorage.setItem('chatFilePath',data.ChatFilePath);
          window.localStorage.setItem('userImagePath',data.SenderImagePath);
          this.events.publish('user:created', '');
          this.navCtrl.setRoot(HomePage);
        }
        loader.dismiss();
      }, (err) => {
        loader.dismiss();
        this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
      });
    });
  }
}

