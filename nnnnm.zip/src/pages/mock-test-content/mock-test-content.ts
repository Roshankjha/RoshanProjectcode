/**********************************************************************************
 * Class-name - MockTest Content
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MockTest Content page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, LoadingController } from 'ionic-angular';
import { Subscription } from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { ApiProvider } from '../../providers/api/api';
import { MockTestInfoPage } from '../mock-test-info/mock-test-info';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-mock-test-content',
  templateUrl: 'mock-test-content.html',
})
export class MockTestContentPage {
  item: any;
  contentTypeName: any;
  jsonStirng:any;
  mockTestContent:any;
  public mockTestContentsList :any[];
  nodataText:string="";

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, private network: Network,public platform: Platform,
  public loading: LoadingController,public apiProvider: ApiProvider,public updateVallidator:UpdateValidatorProvider) {
    this.checkNetwork();  
    this.item = navParams.get('item');
    this.contentTypeName = navParams.get('contentTypeName');
    this. mockTestCourseContentServiceCall();
  }

 /*
*This method is used to perform the back action which goes to the previous page on clicking 
*the back button in the device.
*/
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
  /**
   * connection event is unsubscribed
   */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
/*
In the checkNetwork method there are two subscriptions.
Each subscription checks for the network availability and 
stores the value as online in data if network is available and
stores the value as offline in data if network is not available.
*/
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this. mockTestCourseContentServiceCall();
    }, error => console.error(error));
 
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /**
 * 
 * This method is used to call the service and stored the content of view_previous_tests_attempts and attempt_these_mock_tests.
 */
  mockTestCourseContentServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      if (this.contentTypeName=="view_previous_tests_attempts"){
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"courseId":this.item.courseId};
        this.mockTestContent = this.apiProvider.post('mocktestStudentviewGetAttemptedQuizList',this.jsonStirng,'POST'); 
        this.mockTestContent.subscribe(data =>{ 
          this.mockTestContentsList = JSON.parse(data.mockQuizListCourseList); 
          loader.dismiss();
          if(this.mockTestContentsList.length==0){
            this.nodataText = "No dtails for Mock Test found";
          }else{this.nodataText = "";}
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }else if(this.contentTypeName=="attempt_these_mock_tests"){
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"courseId":this.item.courseId};
        this.mockTestContent = this.apiProvider.post('mocktestStudentviewGetAttemptedNotQuizList',this.jsonStirng,'POST'); 
        this.mockTestContent.subscribe(data =>{ 
          this.mockTestContentsList = JSON.parse(data.mockQuizNotAttemptedCourseList); 
          loader.dismiss();
          if(this.mockTestContentsList.length==0){
            this.nodataText = "No dtails for Mock Test found";
          }else{this.nodataText = "";}
        }, (err) => {
          loader.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
      }    
    });
  }

/**
 * This method is used to display the Mock test instruction page for attempt the online quiz. 
 */
  attemptTest(mocktest){
    this.navCtrl.push(MockTestInfoPage,{
    mockQuizId:mocktest.mockQuizId,
    alertheaderhidden:true,
    viewquestion_btnHidden:true,
    starttest_btnhidden:true
    })
  }

  /**
  * This method is used to display the toast message slide left for attempt the online quiz. 
  */
  attempttest_toast(){
    this.updateVallidator.validationUpdateToast("Slide left side for Attempt Test");
  }
}
