/**********************************************************************************
 * Class-name - MockTest Evaluated
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MockTest Evaluated page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, LoadingController } from 'ionic-angular';
import { Subscription } from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { ApiProvider } from '../../providers/api/api';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-mock-test-evaluated',
  templateUrl: 'mock-test-evaluated.html',
})
export class MockTestEvaluatedPage {
  item:any;
  contentTypeName:any;
  nodataText:string="";

  jsonStirng:any;
  mockTestEvaluated:any;
  public mockTestEvaluatedList :any[];

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, private network: Network,public platform: Platform,
  public loading: LoadingController,public apiProvider: ApiProvider,public updateVallidator:UpdateValidatorProvider) {
    this.checkNetwork();  
    this.item = navParams.get('item');
    this.contentTypeName = navParams.get('contentTypeName');
    this. mockTestEvaluatedServiceCall();
  }
  
  /*
  This method is used to perform the back action which goes to the previous page on clicking 
  the back button in the device.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
/** 
 * This method is life Cycle method of ionic.
 * unsubscribe the events of network connect and disconnected.
*/
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
  /*
  In the checkNetwork method there are two subscriptions.
  Each subscription checks for the network availability and 
  stores the value as online in data if network is available and
  stores the value as offline in data if network is not available.
  */
  checkNetwork() {
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this. mockTestEvaluatedServiceCall();
    }, error => console.error(error));
 
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /**
 * This method is used to call service to stored the mocktest evaluated data in the arrays.
 */
  mockTestEvaluatedServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"courseId":this.item.courseId};
      this.mockTestEvaluated = this.apiProvider.post('mocktestStudentgetEvaluatedAttemptList',this.jsonStirng,'POST'); 
      this.mockTestEvaluated.subscribe(data =>{ 
        this.mockTestEvaluatedList = JSON.parse(data.mtEvaluatedAttemptCourseList); 
        loader.dismiss();
        if(this.mockTestEvaluatedList.length==0){
          this.nodataText = "No evaluated mocktest found";
        }else{this.nodataText="";}
      }, (err) => {
        loader.dismiss();
        this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
      });
    });
  }
}
