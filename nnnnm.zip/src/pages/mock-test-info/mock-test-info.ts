/**********************************************************************************
 * Class-name - MockTest Info
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MockTest Info page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
import { MockTestOnlineQuizPage } from '../mock-test-online-quiz/mock-test-online-quiz';

@IonicPage()
@Component({
  selector: 'page-mock-test-info',
  templateUrl: 'mock-test-info.html',
})
export class MockTestInfoPage {

  alertheaderhidden:boolean=false;
  viewquestion_btnHidden:boolean=false;
  starttest_btnhidden:boolean=false;
  mockQuizId:any;
  constructor(public navCtrl: NavController, public navParams: NavParams,public platform: Platform) {
     this.alertheaderhidden=this.navParams.get('alertheaderhidden');
     this.viewquestion_btnHidden=this.navParams.get('viewquestion_btnHidden');
     this.starttest_btnhidden=this.navParams.get('starttest_btnhidden');
     this.mockQuizId = this.navParams.get('mockQuizId');
  }
  
  /**
   * This method used to start the mock test quiz , display the mock test online quiz page .
   */
  goTOStartTest(){
    this.navCtrl.pop();
    this.navCtrl.push(MockTestOnlineQuizPage,{
      mockQuizId:this.mockQuizId
    });
  }
  /**
 * This method is life Cycle method of ionic.
 * handle back button function.
 */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }

}
