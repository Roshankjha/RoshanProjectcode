/**********************************************************************************
 * Class-name - MockTest Online Quiz
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MockTest Online Quiz page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component ,ViewChild} from '@angular/core';
import { IonicPage, NavController, NavParams, Slides, Platform, AlertController, LoadingController } from 'ionic-angular';
import { Subscription } from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { ApiProvider } from '../../providers/api/api';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-mock-test-online-quiz',
  templateUrl: 'mock-test-online-quiz.html',
})
export class MockTestOnlineQuizPage {

  @ViewChild(Slides) slides: Slides;
  
  selectedOption: any;
  jsonStirng:any;
  mockTestQuizAttempt:any;
  public mockTestQuizAttemptList :any[];
  studentNo:any;
  studentName:any;
  mockQuizDetail:any;
  mockQuizName:any;
  quillEditorContent:any;
  questionTypeId:any;
  mockQuizQuestionId:any;
  public allAnswers:any[] = [];
  quiztime_inHr:number;
  quiztime_inmint:number;
  quiztime_inSec:number;
  quiztime_inSecond:number;
  quizTimeStr:any;
  markedForDiscussionAnswer:any=[];
  mockQuizAttempt:any;
  timertime: number=0;
  time: number;
  remainingTime: number;
  runTimer: boolean;
  hasStarted: boolean;
  hasFinished: boolean;
  displayTime: string;
  mockQuizId:any;
  connected: Subscription;
  disconnected: Subscription;
  networkType:any;
  submitTime:any;
  fulltime:any;
  modules = {};
  backbtn:boolean=true;
  forwarbtn:boolean=false;
  submitbtn:boolean=true;
  displayAlert:boolean=true;
  displayAlertText:any="";
  alertTimer:any;
  endQuizTimer:boolean=false;

  constructor(public navCtrl: NavController, public navParams: NavParams,public platform: Platform,private network: Network,
  private apiProvider:ApiProvider,public alertCtrl: AlertController,public loading: LoadingController,
  public updateVallidator:UpdateValidatorProvider) {
      this.mockQuizId = this.navParams.get('mockQuizId'); 
     this.modules = {
      formula: true,
      toolbar:[
        ['bold', 'italic', 'underline',],        
        [{ 'align': [] }],
        [{ 'indent': '-1'}, { 'indent': '+1' }],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        [{ 'color': [] }, { 'background': [] }],['image','clean']                 
      ]
    }
      this.checkNetwork();
      this.mockTestQuizAttemptServiceCall();
    }

        /**
 * This method is life Cycle method of ionic.
 * handle back button function.
 */
    ionViewDidEnter(){
      this.platform.registerBackButtonAction(() => {
        this.updateVallidator.validationUpdateToast("Can't go out of the screen during MockTest");
      });
    }

/**
  * This method is  handle to stop slide swipe function.
  */
    ngOnInit() {
      this.slides.lockSwipes(true);
    }
    /**
   * This method used to start the timer count down and display on the UI. 
   */ 
    initTimer() {
       // Pomodoro is usually for 25 minutes
     if (!this.timertime) {
        this.timertime=this.quiztime_inSecond;
        //this.timertime=20;
      }
       this.time = this.timertime;
       this.runTimer = false;
       this.hasStarted = false;
       this.hasFinished = false;
       this.remainingTime = this.timertime;
      
       this.displayTime = this.getSecondsAsDigitalClock(this.remainingTime);
       this.startTimer()
    }
    /**
   * This method used to start the timer count down. 
   */   
    startTimer() {
       this.runTimer = true;
      this.hasStarted = true;
      this.timerTick();
    }
    
    pauseTimer() {
      this.runTimer = false;
    }
    
    resumeTimer() {
      this.startTimer();
    }
    /**
   * This method used to get the time as count down. 
   */ 
    timerTick() {
      setTimeout(() => {
        if (!this.runTimer) { return; }
        this.remainingTime--;
        this.displayTime = this.getSecondsAsDigitalClock(this.remainingTime);
        if (this.remainingTime > 0) {
          if (this.displayTime == "00:00:10"){
            this.endQuizTimer=true;
          } 
          this.timerTick();
        }
        else {
          this.hasFinished = true;
          if(this.allAnswers.length===0){
            this.timeUpSubmitAlert("OOPS!!!!You have not attempted any questions",true);
          }else{
            this.timeUpSubmitAlert("Click on ok to submit your answers",false);
          }
        }
      }, 1000);
    }
    /**
   * This method used to get the time as input in seconds and return the time on hour, minute and second format. 
   * @param inputSeconds 
   */ 
    getSecondsAsDigitalClock(inputSeconds: number) {
      var sec_num = parseInt(inputSeconds.toString(), 10); // don't forget the second param
      var hours = Math.floor(sec_num / 3600);
      var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
      var seconds = sec_num - (hours * 3600) - (minutes * 60);
      var hoursString = '';
      var minutesString = '';
      var secondsString = '';
      hoursString = (hours < 10) ? "0" + hours : hours.toString();
      minutesString = (minutes < 10) ? "0" + minutes : minutes.toString();
      secondsString = (seconds < 10) ? "0" + seconds : seconds.toString();
      return hoursString + ':' + minutesString + ':' + secondsString;
    }
  /**
   * This method used to save the selected answer of particular Mcq. 
   * @param value 
   *  @param quizattempt 
   */   
    selected_Option(value,quizattempt) {
      this.selectedOption = value; 
    }
  /**
   * This method used to save the selected answer and stored it and then moves to the next question. 
   * @param quizattempt 
   */  
    save_next(quizattempt){
      let answer;
      if(quizattempt.questionTypeId===1){
        if(this.selectedOption){
           answer = {
            questionId:quizattempt.mockQuizQuestionId,
            questionTypeId : quizattempt.questionTypeId,
            ansChoiceId : this.selectedOption,
            desAns : ""
          };
          for (let _i = 0; _i < this.allAnswers.length; _i++) {
            let answer1 = this.allAnswers[_i];
            if (quizattempt.mockQuizQuestionId == answer1.questionId) {   
              this.allAnswers.splice(_i, 1);          
            }
          }
          this.allAnswers.push(answer); 
          this.submitbtn=false;             
          this.slides.lockSwipes(false);
          this.slides.slideNext(200);
          this.slides.lockSwipes(true);
          this.selectedOption=null;  
          let currentIndex = this.slides.getActiveIndex();
          let lastindex=this.slides.length();
          this.forwarbtn=false;
          if(currentIndex==lastindex-1){
            this.forwarbtn=true;
            }
        }else{
          this.hideWarningInTimer("Select an option and then click on Save!");
        }
      }else{     
        if(this.quillEditorContent){
          answer = {
            questionId : quizattempt.mockQuizQuestionId,
            questionTypeId : quizattempt.questionTypeId,
            ansChoiceId : "",
            desAns : this.quillEditorContent
          };
          for (let _i = 0; _i < this.allAnswers.length; _i++) {
            let answer1 = this.allAnswers[_i];
            if (quizattempt.mockQuizQuestionId == answer1.questionId) {
              this.allAnswers.splice(_i, 1);
            }
          }
          this.allAnswers.push(answer);
          this.forwarbtn=false;
          this.submitbtn=false; 
          this.slides.lockSwipes(false);
          this.slides.slideNext(200);
          this.slides.lockSwipes(true);
          this.quillEditorContent='';
          let currentIndex = this.slides.getActiveIndex();
          let lastindex=this.slides.length();
          if(currentIndex==lastindex-1){
            this.forwarbtn=true;
          }
        }else{
          this.hideWarningInTimer("Type the answer in the editor and then click on save!");
        }
      }   
    }

    /**
     * bind the data from the UI to varriable
     * @param $event 
     */
    contentChange($event:any){
      this.quillEditorContent=$event.html;
    }
    /**
   * This method used to submit the test and stored all the selected question with thier respectives answer. 
   * @param quizattempt 
   * @returns quizId
   */
    submittest(mockQuizId){
      this.submitTime=this.displayTime;
      this.fulltime=this.getSecondsAsDigitalClock(this.quiztime_inSecond);
      if (this.allAnswers.length !== 0) {
        var allAnswerJsonString = "";
        for (let _j = 0; _j <this. allAnswers.length; _j++) {
          allAnswerJsonString = allAnswerJsonString+(JSON.stringify(this.allAnswers[_j]));
        }
        var questionsForDiscussionStr = "";
        questionsForDiscussionStr =  this.markedForDiscussionAnswer.toString();
        let loader = this.loading.create({content : "Loading ,please wait..."});
        loader.present().then(() => {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"allAnswerJsonString":allAnswerJsonString,"questionsForDiscussion":questionsForDiscussionStr,"quizId":mockQuizId,"remainTime":this.displayTime};
          this.mockQuizAttempt = this.apiProvider.post('mocktestStudentPostMockQuizAttempt',this.jsonStirng,'POST'); 
          this.mockQuizAttempt.subscribe(data =>{
            loader.dismiss();
            if(data.studentMockQuizAttemptId==" "){
              this.updateVallidator.testUpdateAlert("Test Submission","Your test submission is failed.");
            }else{
              this.remainingTime=0;
              this.updateVallidator.testUpdateAlert("Test Submission","Test is submited successfully.");
              this.navCtrl.pop();
            }
          }, (err) => {
            loader.dismiss();
            this.updateVallidator.serverErrorAlert("Server Error","Temporary error in submitting your test");
          });  
        });
      }
    }
    /**
   * This method used to swipe the slides back.
   */
    slide_back(){
      this.slides.lockSwipes(false);
      this.slides.slidePrev(200);
      this.slides.lockSwipes(true);

      let currentIndex = this.slides.getActiveIndex();
      this.forwarbtn=false;
      if(currentIndex==0){
        this.backbtn=true;
      }
     
    }
     /**
   * This method used to swipe the slides forward.
   */
    slide_forward(){
      this.backbtn=false;
      let currentIndex = this.slides.getActiveIndex();
      let lastindex=this.slides.length();
      if(currentIndex==lastindex-1){
         this.forwarbtn=true;
         }
     
      this.slides.lockSwipes(false);
      this.slides.slideNext(200);
      this.slides.lockSwipes(true);
    }

   /** 
 * This method is life Cycle method of ionic.
 * unsubscribe the events of network connect and disconnected.
*/
    ionViewWillLeave(){
      this.connected.unsubscribe();
      this.disconnected.unsubscribe();
    }
    /**
 * This method used to check the network status with subscribe and unsubscribe network connection.
 */
    checkNetwork() {
      this.connected = this.network.onConnect().subscribe(data => {
        this.networkType=data.type;
         }, error => console.error(error));
      this.disconnected = this.network.onDisconnect().subscribe(data => {
        this.networkType=data.type;
      }, error => console.error(error));
    }
    /** 
   * This method used to call the service to getting questions list and stored it on arrays.
  */
    mockTestQuizAttemptServiceCall(){
      let loader = this.loading.create({content : "Loading ,please wait..."});  
      loader.present().then(() => {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"mockQuizId":this.mockQuizId};
          this.mockTestQuizAttempt = this.apiProvider.post('mocktestStudentViewGetMockQuizAttempt',this.jsonStirng,'POST'); 
          this.mockTestQuizAttempt.subscribe(data =>{ 
            this.studentNo = data.studentNo; 
            this.studentName =data.studentName;
            this.mockQuizDetail = JSON.parse(data.mockQuizDetail ) ;
            this.mockQuizName =this.mockQuizDetail.quizName;
            this.quizTimeStr= this.mockQuizDetail.timeDuration;
            if(this.quizTimeStr.includes('AM')){
             this.quizTimeStr = this.quizTimeStr.replace('AM',' ');
            }else if(this.quizTimeStr.includes('PM')){
              this.quizTimeStr = this.quizTimeStr.replace('PM',' ');
            }
             let time=this.quizTimeStr.split(':');
             this.quiztime_inHr=parseInt(time[0]);
             if(this.quiztime_inHr ==12){
              this.quiztime_inHr =0;
             }
            this.quiztime_inmint=parseInt(time[1]);
           this.quiztime_inSec=parseInt(time[2]);
      
             this.quiztime_inSecond=(3600 *  this.quiztime_inHr) + (60 * this.quiztime_inmint) + this.quiztime_inSec;
             this.initTimer();
           this.mockTestQuizAttemptList = JSON.parse(data.jsonMockQuizQuestionList); 
           this.mockTestQuizAttemptList.forEach(element => {
            element.markforDiscussion=false;
            element.removeFromdiscussion=true;
          })
           loader.dismiss();
           if(this.mockTestQuizAttemptList.length==0){
            //this.noDataToast("Mock Test Evaluated");
           } 
         }, (err) => {
          loader.dismiss();
        });
      });
    }

     /**
   * This method used to marked the question for disscussion. 
   * @param quizattempt 
   */
    markFor_Discussion(quizattempt){    
      quizattempt.markforDiscussion=true;
      quizattempt.removeFromdiscussion=false;
      this.markedForDiscussionAnswer.push(quizattempt.mockQuizQuestionId);
  }
  /**
   * This method used to remove the question from disscussion. 
   * @param quizattempt 
   */
  removeFrom_Discussion(quizattempt){
    quizattempt.removeFromdiscussion=true;
    quizattempt.markforDiscussion=false;
    for (let _i = 0; _i < this.markedForDiscussionAnswer.length; _i++) {
      let markAnswer = this.markedForDiscussionAnswer[_i];
      if (quizattempt.mockQuizQuestionId == markAnswer) {   
        this.markedForDiscussionAnswer.splice(_i, 1);          
      }
    }
  }


  /**
   * This method used to show alert when without save answer user proceeding to next.
   * @param message 
   */
  hideWarningInTimer(message){
    this.displayAlert=false;
    this.displayAlertText=message;
    this.alertTimer = setInterval(() => this.displayAlertText, 100);
    setTimeout(() => { 
      clearInterval(100);
      this.displayAlert=true;
      this.displayAlertText="";
       }, 2000);
  }

  /**
   * This method used to show alert when time finished of the test and then it will automatically submit the test. 
   * @param message 
   * @param isemptyAnswers 
   */

  timeUpSubmitAlert(message:string,isemptyAnswers:boolean){
    let alert = this.alertCtrl.create({
      title: 'Time up!',
      subTitle: message,
      buttons: [{text:'OK',
      handler: () => {
        if(isemptyAnswers){
          //all answers array is null
          this.navCtrl.pop();
        }
        else{
          this.submittest(this.mockQuizId);
        }
      }
    }],
    enableBackdropDismiss: false
  });
   alert.present();
  }
}
