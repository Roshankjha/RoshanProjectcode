/**********************************************************************************
 * Class-name - MockTest
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MockTest page. 
 * MockTestPage have methods implementation to display assignments,test and exams.
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, LoadingController, MenuController, Events } from 'ionic-angular';
import { HomePage } from '../home/home';
import { ProgramCoursesPage } from '../program-courses/program-courses';
import { MockTestInfoPage } from '../mock-test-info/mock-test-info';

/**
 * Generated class for the MockTestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mock-test',
  templateUrl: 'mock-test.html',
})
export class MockTestPage {
  mockTestListItem: { "title": string; "id": string; }[];
  mocktestIcon: string = "add";
  hideMocktest:boolean=true;

  menuOpened:boolean;
  
  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,
  public loading: LoadingController,public events: Events,public menuCtrl: MenuController) {
    this.loadUI();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });
  }

  /**
   *This method is used to perform the back action which goes to the Home Page on clicking 
   * the back button in the device.
   */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }else{
        this.navCtrl.setRoot(HomePage);
      }
    });
  }
  /**
   * This method is used to show the option on toggle to procced on the mock test.
   */
  loadUI() {
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.mockTestListItem = [
        {"title":"View Previous Tests Attempts ", "id":"view_previous_tests_attempts" },
        { "title":"Attempt These Mock Tests", "id":"attempt_these_mock_tests"},
        { "title":"View Evaluated Tests Attempts","id":"view_evaluated_tests_attempts" }
      ];
       loader.dismiss();
    });
  }
/**
   * This method is used to show and hide  the option on toggle to procced on the mock test.
   */
  togglemockTest(){
    this.hideMocktest = !this.hideMocktest;
    if (this.mocktestIcon === 'remove') {
      this.mocktestIcon = "add";
    }else if (this.mocktestIcon === 'add') {
      this.mocktestIcon = "remove";
    }
  }
/**
   * This method used to passed the item on the program course. 
   * @param item 
   */  
  goToProgramCourses(item){
    this.navCtrl.push(ProgramCoursesPage,{
      contentType: item,
      fromPage:'MockTest',
      contentModule:'mocktest'
    });
  }
  /**
   * This method used to show intruction page of the mocktest. 
   */ 
  mockTestInstruction(){
    this.navCtrl.push(MockTestInfoPage);
  }
}
