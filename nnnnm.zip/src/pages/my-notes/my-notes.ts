/**********************************************************************************
 * Class-name - MyNotes
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the MyNotes page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, LoadingController, ModalController, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Item } from '../../models/item';
import { CreateNotePage } from '../create-note/create-note';
import { NoteDetailsPage } from '../note-details/note-details';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

/**
 * Generated class for the MyNotesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-my-notes',
  templateUrl: 'my-notes.html',
})
export class MyNotesPage {
  noteListType:string="text";

  public noteDataArray:any[]=[];
  public noteDataDict:any = {};
  pageNumbers:any;
  pdfTitle:any;

  jsonStirng:any;
  noteListApiCall:any;
  noteList:any[]=[];
  mynoteList:any[]=[];
  noNotesNotifier:any;
  deleteNoteApiCall:any;

  hideNoNotes_TextList:boolean=true;
  hideNoNotes_FreehandList:boolean=true;

  imagepath:any;

  constructor(public viewCtrl: ViewController, public navParams: NavParams,public loading: LoadingController,
  public apiProvider: ApiProvider,public modalCtrl: ModalController,public platform:Platform,
  public updateVallidator:UpdateValidatorProvider) {  
    this.pdfTitle = navParams.data.pdfTitle;    
    this.getAllNotesServiceCall();
    this.imagepath = this.apiProvider.fileAccessURL+"NoteFreeHandFiles/";
  } 
  /*
  *This method is used to perform the back action which goes to the previous page on clicking 
  *the back button in the device.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.viewCtrl.dismiss();
    });
  }

  /**
   * this method is called to the close the view controll
   */
  closeMyNotes(){
    this.viewCtrl.dismiss();
  }
  /**
   * This method is used to call service to delete the note
   * @param roleId
   * @param noteId 
   * @returns note deleted successfully/failed 
   */
  deleteNotes(item:Item){    
    let loader = this.loading.create({content : "Loading ,please wait..."});
    loader.present().then(() => {
      this.jsonStirng = { "roleId":window.localStorage.getItem('roleid'),"noteId":item.noteId};
      this.deleteNoteApiCall = this.apiProvider.post('deleteNote',this.jsonStirng,'POST');
      this.deleteNoteApiCall.subscribe(data =>{
        loader.dismiss();
        if(data.message==="Note deleted successfully!!"){
          for(let i = 0; i < this.noteList.length; i++){
            if(this.noteList[i] == item){
              this.noteList.splice(i, 1);
            }
          }
          this.updateVallidator.deleteUpdate("Note Deletion",data.message);
        }
        else{
          this.updateVallidator.deleteUpdate("Note Deletion",data.message);
        }
      }, (err) => {
        loader.dismiss();
        this.updateVallidator.deleteUpdate("Note Deletion","Error in deleting the note ...try again");
      });
    });
  }
  /**
   * This mehod is navigate to the create note page
   * @param item 
   */
  editNotes(item:Item){
    let modal = this.modalCtrl.create(CreateNotePage,{
      fromPage:'MyNotesPage',
      noteDetails:item
    });
    modal.present({
    });
    this.viewCtrl.dismiss();
  }
  /**
   * show the details of the note in a popover/modals
   * @param item 
   */
  noteDetails(item){
    let modal = this.modalCtrl.create(NoteDetailsPage,{
      fromPage:"MyNotes",
      Item : item
    });
    modal.present({
    });
  }
  /**
   * This method for calling service to get the all notes data
   * @param userId
   * @param roleId
   * @param contentId
   * @param tableName
   * @returns NotePageList
   */
  getAllNotesServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng = { "userId":window.localStorage.getItem('userid'),
                          "roleId":window.localStorage.getItem('roleid'),
                          "contentId":this.navParams.data.typeOfContentId,
                          "tableName":this.navParams.data.tableName
                        };
      this.noteListApiCall = this.apiProvider.post('viewNoteAllPage',this.jsonStirng,'POST'); 
      this.noteListApiCall.subscribe(data =>{
        if(data.NotePageList==="No Notes Present! Click on Add Note to Create a Note"){
          this.hideNoNotes_TextList = false;
          this.hideNoNotes_FreehandList = false;
          this.noNotesNotifier = data.NotePageList;
        }else{
          this.mynoteList = JSON.parse(data.NotePageList);
          console.log("note list response",this.mynoteList);
          for(var i = 0; i < this.mynoteList.length; i++) {
            var obj = this.mynoteList[i];
            //console.log(obj.noteContent);
            var div = document.createElement("div");
            div.innerHTML = obj.noteContent;
            let text = div.textContent || div.innerText || "";
            //console.log("textValuedd", text);
            this.noteList.push ({
              "contentProgramCourseId":obj.contentProgramCourseId,
              "createdById":obj.createdById,
              "createdTimestamp":obj.createdTimestamp,
              "deletedflag":obj.deletedflag,
              "type":obj.fileType,
              "noteHandwritingImage":obj.noteHandwritingImage,
              "noteContent":text,
              "noteId":obj.noteId,
              "noteTitle":obj.noteTitle,
              "pageNumber":obj.pageNumber
            });

          }
          console.log("Final Note List",this.noteList)
        }
        loader.dismiss();
      }, (err) => {
        loader.dismiss();
      });
    });
  }
}
