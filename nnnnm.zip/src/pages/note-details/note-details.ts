/**********************************************************************************
 * Class-name - NOteDetails
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the NoteDetails page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, ModalController, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';

/**
 * Generated class for the NoteDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-note-details',
  templateUrl: 'note-details.html',
})
export class NoteDetailsPage {
  item:any;
  imagepath:any;

  hasTextContent:boolean = false;
  hasFHContent:boolean = false;

  constructor(public viewCtrl: ViewController, public navParams: NavParams,public modalCtrl: ModalController,
    public platform:Platform,public apiProvider: ApiProvider) {
    this.item = navParams.get("Item");
    console.log('Item',this.item);
    if(navParams.data.fromPage==="MyNotes"){
      this.imagepath = this.apiProvider.fileAccessURL+"NoteFreeHandFiles/";
      console.log("NoteContent:",this.item.noteContent)
      console.log("FreehandContent:",this.item.noteHandwritingImage)
      if(this.item.noteContent==undefined||this.item.noteContent=="undefined"){
        this.hasTextContent = false;
        this.hasFHContent = true;
        console.log(" Inside if")
      }else if(this.item.noteHandwritingImage==undefined||this.item.noteHandwritingImage=="undefined"){
        this.hasTextContent = true;
        this.hasFHContent = false;
        console.log(" Inside else if")
      }
    }else if(navParams.data.fromPage==="AllNotes"){
      this.imagepath = this.apiProvider.fileAccessURL;
      console.log("NoteContent:",this.item.noteContent)
      console.log("FreehandContent:",this.item.noteHandwritingImage)
      if(this.item.noteContent==" "){
        this.hasTextContent = false;
        this.hasFHContent = true;
      }else if(this.item.noteHandwritingImage==" "){
        this.hasTextContent = true;
        this.hasFHContent = false;
      }
    }
  }
  /*
  This method is used to perform the back action which goes to the previous page on clicking 
  the back button in the device.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.viewCtrl.dismiss();
    });
  }

/**
 * This method used to close the view controll
 */
  closePopOver(){
    this.viewCtrl.dismiss();
  }
}
