/**********************************************************************************
 * Class-name - NoteInfo
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the NoteInfo page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, Platform } from 'ionic-angular';

/**
 * Generated class for the NoteInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-note-info',
  templateUrl: 'note-info.html',
})
export class NoteInfoPage {
  
  constructor(public viewCtrl: ViewController, public navParams: NavParams,public platform:Platform) {
  }

  /*
  This method is used to perform the back action which goes to the previous page on clicking 
  the back button in the device.
  */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.viewCtrl.dismiss();
    });
  }

  /**
   * close the view 
   */
  close(){
    this.viewCtrl.dismiss();
  }
}
