/**********************************************************************************
 * Class-name - NotificationDetailsPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the NotificationDetailsPage page. 
 * NotificationDetailsPage have methods implementation to display the content information.  
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';

@IonicPage()
@Component({
  selector: 'page-notification-details',
  templateUrl: 'notification-details.html',
})
export class NotificationDetailsPage {

  notificationCode:any;
  item:any;

  hideAssignment:boolean = true;
  hideAssignmentEvaluation:boolean = true;
  hideTestOrExam:boolean = true;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams,public apiProvider: ApiProvider,public loading: LoadingController) {
      this.notificationCode = navParams.get('notificationCode');
      this.item = navParams.get('item');
      this.validateUI();
  }
/** 
 * this method is handle back button function.
*/
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
/** 
 * validateUI method generate to validate the UI based on Notification Code.
*/
  validateUI(){
    if(this.notificationCode==='QA001'){
      this.hideAssignment= false;
      this.hideAssignmentEvaluation= true;
      this.hideTestOrExam= true;
    }
    else if(this.notificationCode==='QA002'){
      this.hideAssignment= true;
      this.hideAssignmentEvaluation= true;
      this.hideTestOrExam= false;
    }
    else if(this.notificationCode==='QA003'){
      this.hideAssignment= true;
      this.hideAssignmentEvaluation= true;
      this.hideTestOrExam= false;
    }
    else if(this.notificationCode==='QA005'){
      this.hideAssignment= true;
      this.hideAssignmentEvaluation= false;
      this.hideTestOrExam= true;
    }
    else if(this.notificationCode==='QA006'){
      this.hideAssignment= true;
      this.hideAssignmentEvaluation= false;
      this.hideTestOrExam= true;
    }
  }
}
