/**********************************************************************************
 * Class-name - NotificationsPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the NotificationsPage page. 
 * NotificationsPage have methods implementation to display the notification updates of Digital Library, Quantitative Assessment and Mock Test.  
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, MenuController, Events } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { ContentDetailsPage } from '../content-details/content-details';
import { NotificationDetailsPage } from '../notification-details/notification-details';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { HomePage } from '../home/home';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-notifications',
  templateUrl: 'notifications.html',
})
export class NotificationsPage {
  public notificationList: any;
  notificationApiCall:any;
  jsonStirng:any;

  public notificationdetail: any;
  notificationDetailApiCall:any;
  public item:any;

  groupNames:any;
  cmList:any[] = [];
  qaList:any[] = [];
  mtList:any[] = [];

  notiUrl:string[];
  notiParam:string[];
  notificationCode:any;

  hideCMList: boolean = true;
  hideQAList: boolean = true;
  hideMTList: boolean = true;
  notificationIconDigilib: string = "add";
  notificationIconQa: string = "add";
  notificationIconMt: string = "add";

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  menuOpened:boolean;

  constructor(public platform: Platform,public navCtrl: NavController, public navParams: NavParams, public apiProvider: ApiProvider,public loading: LoadingController,
  private network: Network,public updateVallidator:UpdateValidatorProvider,public events: Events,public menuCtrl: MenuController) {
    this.checkNetwork();
    this.notificationServicecall();

    this.events.subscribe('menu:opened', () => {
      this.menuOpened = true;
    });
    this.events.subscribe('menu:closed', () => {
      this.menuOpened = false;
    });
  }
/**
 * this method is handle back button function.
 */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      if(this.menuOpened==true){
        this.menuCtrl.close();
      }else{
        this.navCtrl.setRoot(HomePage);
      }
    });
  }
/**
 * this method generate to check the network status. 
 */

  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.notificationServicecall();
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
  /**
  * this method is unsubscribe the events of network connect and disconnected.
 */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }

/**
 * this method generate to go the notification details page of Quantitative Assessment,Digital Library and Mock Test.
 * shows the progress toast 
 * @param params 
 */
  goToNotificationDetails(params){
    if(params.componentName==='QA'){
      this.notiUrl = (params.notificationURL).split('.'); 
      this.notiParam = (params.notificationURL).split('?');
      this.notificationCode = params.notificationCode;
      this.notificationDetailsServiceCall();
    }
    else if(params.componentName==='CM'){
      this.notiUrl = (params.notificationURL).split('.'); 
      this.notiParam = (params.notificationURL).split('?');
      this.notificationCode = params.notificationCode;
      this.navCtrl.push(ContentDetailsPage,{
        fromPage:"Notification",
        notificationCode: params.notificationCode,
        notificationUrl: this.notiUrl[0],
        notificationParameters: this.notiParam[1]
      });
    }
    else if(params.componentName==='MT'){
      this.updateVallidator.noNotificationToast("Mock Test is in progress");
    }
    else{
      this.updateVallidator.noNotificationToast("Details page is in progress");
    }
  }

/**
 * this method used to show and hide the toggle view list of digital library. 
 */
  toggleCMListView(){
    if(this.cmList.length==0){
      this.updateVallidator.noNotificationToast("No notification found for digital library");
    }
    else{
      this.hideCMList=!this.hideCMList;
      if (this.notificationIconDigilib === 'remove') {
        this.notificationIconDigilib = "add";
      }else if (this.notificationIconDigilib === 'add') {
        this.notificationIconDigilib = "remove";
      }
    }
  }
/**
 * this method used to show and hide the toggle view list of Quantitative assessment. 
 */
  toggleQAListView(){
    if(this.qaList.length==0){
      this.updateVallidator.noNotificationToast("No notification found for Quantitative assessment");
    }else{
      this.hideQAList=!this.hideQAList;
      if (this.notificationIconQa === 'remove') {
        this.notificationIconQa = "add";
      }else if (this.notificationIconQa === 'add') {
        this.notificationIconQa = "remove";
      }
    } 
  }
/**
 * this method used to show and hide the toggle view list of Mock Test. 
 */
  toggleMTListView(){
    if(this.mtList.length==0){
      this.updateVallidator.noNotificationToast("No notification found for Mock Test");
    }else{
      this.hideMTList=!this.hideMTList;
      if (this.notificationIconMt === 'remove') {
        this.notificationIconMt = "add";
      }else if (this.notificationIconMt === 'add') {
        this.notificationIconMt = "remove";
      }
    }
  }
/**
  * this method generate to service call api of notification for Digital Library, Quantitative assessment and Mock Test. 
  * @param url 
  */
  notificationServicecall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid'),"roleId":window.localStorage.getItem('roleid')};
      this.notificationApiCall = this.apiProvider.post('dashboardGetNotifications',this.jsonStirng,'POST'); 
      this.notificationApiCall.subscribe(data => { 
       this.notificationList = JSON.parse(data.notificationList);  
       for (let _i = 0; _i < this.notificationList.length; _i++){
         var compName =this.notificationList[_i];
         if(compName.componentName==="QA"){
          this.qaList.push(this.notificationList[_i]);
         }else if(compName.componentName==="CM"){
          this.cmList.push(this.notificationList[_i]);
        }else if(compName.componentName==="MT"){
          this.mtList .push(this.notificationList[_i]); 
        }
       }
       this.groupNames =[
         {
           "componentName":"Quantitative Assessment",
           "componentList":this.qaList
         },
         {
          "componentName":"Digital Library",
          "componentList":this.cmList
         },
         {
          "componentName":"Mock Test",
          "componentList":this.mtList
         }
        ]
        loader.dismiss();
      }, (err) => {
        loader.dismiss();
      });
      
    });
    
  }
/**
 * this method generate to service call api of notification details for Quantitative assessment.
 */
  notificationDetailsServiceCall(){
    let loader = this.loading.create({content : "Loading ,please wait..."});  
    loader.present().then(() => {
      this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid'),"parameterValues":this.notiParam[1]};
      this.notificationDetailApiCall = this.apiProvider.post(this.notiUrl[0],this.jsonStirng,'POST'); 
      this.notificationDetailApiCall.subscribe(data => {
        if(this.notificationCode==='QA001'){
          this.notificationdetail = JSON.parse(data.AssignmentNotificationDetails);
          for (let _i = 0; _i < this.notificationdetail.length; _i++) {
            this.item = this.notificationdetail[_i];
          }
          loader.dismiss();
          this.navCtrl.push(NotificationDetailsPage,{
            notificationCode: this.notificationCode,
            item:this.item
         });  
        }
        else if(this.notificationCode==='QA002'){
          this.notificationdetail = JSON.parse(data.TestNotificationDetails);
          for (let _i = 0; _i < this.notificationdetail.length; _i++) {
            this.item = this.notificationdetail[_i];
          }
          loader.dismiss();
          this.navCtrl.push(NotificationDetailsPage,{
            notificationCode: this.notificationCode,
            item:this.item
         });    
        }
        else if(this.notificationCode==='QA003'){
          this.notificationdetail = JSON.parse(data.ExamNotificationDetails);  
          for (let _i = 0; _i < this.notificationdetail.length; _i++) {
            this.item = this.notificationdetail[_i];
          }
          loader.dismiss();
          this.navCtrl.push(NotificationDetailsPage,{
            notificationCode: this.notificationCode,
            item:this.item
         });    
        }
        else if(this.notificationCode==='QA005'){
          this.notificationdetail = JSON.parse(data.AssignmentEvaluationNotificationDetails); 
          for (let _i = 0; _i < this.notificationdetail.length; _i++) {
            this.item = this.notificationdetail[_i];
          }
          loader.dismiss();
          this.navCtrl.push(NotificationDetailsPage,{
            notificationCode: this.notificationCode,
            item:this.item
         });     
        }
        else if(this.notificationCode==='QA006'){
          this.notificationdetail = JSON.parse(data.AssignmentSubmissionsNotificationDetails);
          for (let _i = 0; _i < this.notificationdetail.length; _i++) {
            this.item = this.notificationdetail[_i];
          }
          loader.dismiss();
          this.navCtrl.push(NotificationDetailsPage,{
            notificationCode: this.notificationCode,
            item:this.item
         });    
        }
      }, (err) => {
        loader.dismiss();
      });
    });
  }

}
