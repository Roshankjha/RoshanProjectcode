/**********************************************************************************
 * Class-name - ProgramCoursesPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the ProgramCoursesPage page. 
 * ProgramCoursesPage have methods implementation to display the program courses.
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Platform, ViewController } from 'ionic-angular';
import { CourseContentPage } from '../course-content/course-content';
import { ApiProvider } from '../../providers/api/api';
import { Item } from '../../models/item';
import { AssessmentCourseContentPage } from '../assessment-course-content/assessment-course-content';
import { FilterPage } from '../filter/filter';
import { Network } from '@ionic-native/network';
import { Subscription} from 'rxjs/Subscription';
import { MockTestEvaluatedPage } from '../mock-test-evaluated/mock-test-evaluated';
import { MockTestContentPage } from '../mock-test-content/mock-test-content';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

@IonicPage()
@Component({
  selector: 'page-program-courses',
  templateUrl: 'program-courses.html',
})
export class ProgramCoursesPage {
  public programCourses: any[];
  pgmCourse:any;
  jsonStirng:any;

  contentModule:any;
  contentType: any;
  departmentID:any;
  programId:any;
  fromPage:any;

  hideSearchBar:boolean = true;
  hideFilter:boolean=true;

  searchedItems:any;
  nodataText:string="";

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;
/**
 * constructor will call page loading and imports the classes
 * @param platform 
 * @param navCtrl 
 * @param navParams 
 * @param apiProvider 
 * @param loadingController 
 * @param network 
 * @param viewCtrl 
 */
  constructor(public platform: Platform,public navCtrl: NavController, navParams: NavParams, public apiProvider: ApiProvider,
  public loadingController:LoadingController, private network: Network,private viewCtrl: ViewController,
  public updateVallidator:UpdateValidatorProvider) {
    this.checkNetwork();
    this.fromPage = navParams.get('fromPage');
    
    if(this.fromPage==='DigitalLibrary'){
      this.contentType = navParams.get('contentType');  
    }
    else if(this.fromPage==='Assessment'){
      this.contentType = navParams.get('contentType');  
      this.contentModule = navParams.get('contentModule');
    }
    else if(this.fromPage==='MockTest'){
      this.contentType = navParams.get('contentType');  
      this.contentModule = navParams.get('contentModule');
    }else if(this.fromPage==='MockTest'){
      this.contentType = navParams.get('contentType');  
      this.contentModule = navParams.get('contentModule');
    }else if(this.fromPage==='Filter'){
      this.contentType=navParams.get('contentType');  
      this.departmentID=navParams.get('departmentID');
      this.programId=navParams.get('programId');
    }
    this.validateUI();
    this.programCoursesServiceCalls();  
  }
/**
 * this method is handle back button function.
 */
  ionViewDidEnter(){
    this.platform.registerBackButtonAction(() => {
      this.navCtrl.pop();
    });
  }
/**
 * this method generate to check the network status. 
 */
  checkNetwork(){
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.programCoursesServiceCalls(); 
    }, error => console.error(error));
   
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }
/**
  * this method is unsubscribe the events of network connect and disconnected.
  */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
/**
 * clicking on the serch bar and will get program course data
 * @param ev 
 */
  getProgramCourses(ev:any){
    let servVal=ev.target.value;
    if(servVal && servVal.trim()!=''){
      this.programCourses = this.programCourses.filter((pc)=>{
        return (pc.courseName.toLowerCase().indexOf(servVal.toLowerCase()) > -1);
      })
    }
    else{
      this.programCoursesServiceCalls();
    }
  }
/**
 * this method is hiding and showing the search bar and filter
 */
  validateUI(){
    if(this.contentType.id==='browseContent'){
      this.hideSearchBar = false;
      this.hideFilter = false;
    }
    else{
      this.hideSearchBar = true;
      this.hideFilter = true;
    }
  }
/**
 * this method is to navigate content page for content module
 * @param item 
 */
  goToCourseContent(item: Item){
    if (!item) item = {};
    if(this.contentModule=="assessment"){
      this.navCtrl.push(AssessmentCourseContentPage,{
        fromPage:"ProgramCourse",
        item: item,
        contentTypeName : this.contentType.id
      });
    }else if(this.contentModule=="mocktest"){
      if(this.contentType.id =="view_evaluated_tests_attempts"){
        this.navCtrl.push(MockTestEvaluatedPage,{
          fromPage:"ProgramCourse",
          item: item,
          contentTypeName : this.contentType.id
        });
      }else {
        this.navCtrl.push(MockTestContentPage,{
          fromPage:"ProgramCourse",
          item: item,
          contentTypeName : this.contentType.id
        });
      }
     
    }else{
      this.navCtrl.push(CourseContentPage,{
        fromPage:"ProgramCourse",
        item: item,
        contentTypeName : this.contentType.id
      });
    }
  }
/**
 *this methos is to navigate filter page
 */
  goToFilter(){
      this.navCtrl.push(FilterPage,{
        contentType : this.contentType,
        fromPage:"ProgramCourse"
      }).then(() => {
        const index = this.viewCtrl.index;
        this.navCtrl.remove(index);
      });
  }

/**
 * service call for getting programm course data
 * jsonStirng:constructing json string for content type
 * @param userId
 * @param roleLevelId
 * @param roleId
 * @param contentType
 * @param departmentId
 * @param programId
 * apiProvider : to connect the server and get the data
 * @param url
 * @param requestMapping('String')
 * @param jsonString ('String')
 * @param requestMethod(POST/GET)
 */
  programCoursesServiceCalls(){
    let loading = this.loadingController.create({content : "Loading ,please wait..."});
    loading.present().then(() =>{
      if(this.fromPage==='DigitalLibrary'||this.fromPage==='Assessment' || this.fromPage==='MockTest'){
        if(this.contentType.id =="view_previous_tests_attempts"){
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid')};
          this.pgmCourse = this.apiProvider.post('mocktestStudentgetCoursedAttemptedQuizList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.mockQuizListCourses); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No Program Courses found for previous tests"
           }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if(this.contentType.id =="attempt_these_mock_tests"){
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid')};
          this.pgmCourse = this.apiProvider.post('mocktestStudentgetCourseAttemptedNotQuizList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.mockQuizNotAttemptedCourse); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No Program Courses found for new tests"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if(this.contentType.id =="view_evaluated_tests_attempts"){
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleId":window.localStorage.getItem('roleid')};
          this.pgmCourse = this.apiProvider.post('mocktestStudentgetCourseEvaluatedAttemptList',this.jsonStirng,'POST'); 
          this.pgmCourse
          .subscribe(data =>{ 
           this.programCourses = JSON.parse(data.mtEvaluatedAttemptCourseList); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No Program Courses found for Evaluated tests"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }
        else if (this.contentType.id=="view_all_assignments") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('assignmentListFilter',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.assignmentList); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No Assignments found "
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }  else if (this.contentType.id=="view_opened_Assignments") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('openAssignmentListFilter',this.jsonStirng,'GET'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.assignmentList);
           loading.dismiss(); 
           if(this.programCourses.length==0){
            this.nodataText = "No Open assignments found"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        } else if (this.contentType.id=="view_my_assignment_submissions") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('qaGetMyStudentAssignmentCourses',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.assignmentList);
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No data for assignment submission found"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if (this.contentType.id=="view_all_tests") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('qaGetFilteredTestList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.testCourseList);
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No data for test found"
          }else{this.nodataText="";}  
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if (this.contentType.id=="student_test_marks") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('qaGetStudentTestMarksList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.testCourseList); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No data for student test marks found"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if (this.contentType.id=="view_all_exams") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('qaGetFilteredExamList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.examCourseList);
           loading.dismiss(); 
           if(this.programCourses.length==0){
            this.nodataText = "No data for exams found"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if (this.contentType.id=="student_exam_marks") {
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"roleLevelId":window.localStorage.getItem('rolelevelid')};
          this.pgmCourse = this.apiProvider.post('qaGetStudentExamMarksList',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.examCourseList); 
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No data for student exam marks found"
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }else if (this.contentType.id=="browseContent") {
          this.jsonStirng={"roleId": window.localStorage.getItem('roleid')};
          this.pgmCourse = this.apiProvider.post('BrowseCourseContent',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
           this.programCourses = JSON.parse(data.libraryPcmCourseList);
           loading.dismiss();
           if(this.programCourses.length==0){
            this.nodataText = "No Program Courses found "
          }else{this.nodataText="";}
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        } else {
          this.jsonStirng={"roleId":window.localStorage.getItem('roleid'),"contentType":this.contentType.id,"userId":window.localStorage.getItem('userid')};
          this.pgmCourse = this.apiProvider.post('StudentCourseContentType',this.jsonStirng,'POST'); 
          this.pgmCourse.subscribe(data => { 
            if (this.contentType.id=="handouts"){
              this.programCourses = JSON.parse(data.libraryPcmProgramList);
            }else{
              this.programCourses = JSON.parse(data.libraryPcmCourseList);
            }  
            loading.dismiss();    
            if(this.programCourses.length==0){
              this.nodataText = "No Program Courses found"
          }else{this.nodataText="";}      
         }, (err) => {
          loading.dismiss();
          this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
        });
        }
      }
      else if(this.fromPage==='Filter'){
        this.jsonStirng={"roleId": window.localStorage.getItem('roleid'),"departmentId":this.departmentID,"programId":this.programId};
        this.pgmCourse = this.apiProvider.post('contentmanagementGetFilterCourses',this.jsonStirng,'POST'); 
        this.pgmCourse.subscribe(data => { 
         this.programCourses = JSON.parse(data.libraryPcmCourseList);
         loading.dismiss();
         if(this.programCourses.length==0){
          this.nodataText = "No data found with selected filters"
          }else{this.nodataText="";}
       }, (err) => {
        loading.dismiss();
        this.updateVallidator.serverErrorAlert("Server Error","Temporary error in fetching data from server");
      });
      }
    });
  }

}
