/**********************************************************************************
 * Class-name - ShareViaEmail
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the ShareViaEmail page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, LoadingController, Platform } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { UpdateValidatorProvider } from '../../providers/update-validator/update-validator';

/**
 * Generated class for the ShareViaEmailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-share-via-email',
  templateUrl: 'share-via-email.html',
})
export class ShareViaEmailPage {

  item:any;
  emailIds:any;

  jsonStirng:any;
  shareNoteApiCall:any;

  constructor(public viewCtrl: ViewController, public navParams: NavParams, public apiProvider: ApiProvider,
  public loading: LoadingController,public updateVallidator:UpdateValidatorProvider,public platform: Platform) {
    this.item = navParams.get("item");
  }

  /*
  This method is used to perform the back action which goes to the previous page on clicking 
  the back button in the device.
  */
 ionViewDidEnter(){
  this.platform.registerBackButtonAction(() => {
    this.viewCtrl.dismiss();
  });
}

  /**
   * Service call for sending the note in a mail
   * @param emailIds 
   * @param noteId
   * @returns success message
   */
  sendEmail(){
    let loader = this.loading.create({content : "Loading ,please wait..."});
    loader.present().then(() => {
      this.jsonStirng = { "emailId":this.emailIds,"noteId":this.item.noteId};
      this.shareNoteApiCall = this.apiProvider.post('sendEmail',this.jsonStirng,'POST');
      this.shareNoteApiCall.subscribe(data =>{
        if(data.message==="Email Sent Successfully"){
          this.viewCtrl.dismiss();
          this.updateVallidator.shareUpdate(data.message);
        }
        else if(data.message==="Email Sending Failed"){
          this.viewCtrl.dismiss();
          this.updateVallidator.shareUpdate(data.message);
        }else{
          this.emailIds = "";
          this.updateVallidator.shareUpdate("Server Error.....Try again");
        }
        loader.dismiss();
      }, (err) => {
        this.viewCtrl.dismiss();
        this.updateVallidator.shareUpdate("Server Error.....Try again");
        loader.dismiss();
      });
    });
  }

  closePopOver(){
    this.viewCtrl.dismiss();
  }
}
