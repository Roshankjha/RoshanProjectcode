/**********************************************************************************
 * Class-name - SplashPage
 * Version - 1.0
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 *
 * Description: Generated class for the SplashPage page. 
 * 
 * 
 *
 **********************************************************************************/
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, ModalController, AlertController, Events } from 'ionic-angular';
import { Subscription } from 'rxjs/Subscription';
import { Network } from '@ionic-native/network';
import { ApiProvider } from '../../providers/api/api';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { Device } from '@ionic-native/device';

/**
 * Generated class for the SplashPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-splash',
  templateUrl: 'splash.html',
})
export class SplashPage {

  connected: Subscription;
  disconnected: Subscription;
  networkType:any;

  clientUUID:any;
  sessionRefreshApiCall:any;

  jsonStirng:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,private screenOrientation: ScreenOrientation,
  private device: Device,public network: Network,public platform: Platform,public modalCtrl: ModalController,
  public alertCtrl: AlertController,public events: Events,public apiProvider :ApiProvider,public splashScreen: SplashScreen) {
    this.screenOrientation.lock('portrait')
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
    this.checkNetwork();
    this.checkAuthentication();
  }

  /**
   * Default splash screen is hide
   */
  ionViewDidLoad() {
    this.splashScreen.hide();
  }

  /**
   * screen orientation is unlocked
   */
  ionViewDidLeave(){
    this.screenOrientation.unlock();
  }

  /**
   * In the checkNetwork method there are two subscriptions.
   * Each subscription checks for the network availability and
   * stores the value as online in data if network is available and
   * stores the value as offline in data if network is not available.
   */
  checkNetwork() {
    this.networkType = this.network.type;
    this.connected = this.network.onConnect().subscribe(data => {
      this.networkType=data.type;
      this.checkAuthentication();
    }, error => console.error(error));
    this.disconnected = this.network.onDisconnect().subscribe(data => {
      this.networkType=data.type;
    }, error => console.error(error));
  }

  /**
   * In this coonection event is unsubscribed
   */
  ionViewWillLeave(){
    this.connected.unsubscribe();
    this.disconnected.unsubscribe();
  }
  /**
   * this method is called to check userid and threadid values are undefined/null or not
   * these values are undefined/null,then it will start splash screen, then these values are stored then
   * it will call session refresh
   */
  checkAuthentication(){
    if((window.localStorage.getItem('userid') === "undefined" || window.localStorage.getItem('userid') === null) && 
       (window.localStorage.getItem('threadid') === "undefined" || window.localStorage.getItem('threadid') === null)) { 
        setTimeout(() => {
          this.navCtrl.setRoot(LoginPage);
        }, 5000);
    }else{
      this.sessionRefresh();
    }
  }

   /**
   * Here the service is called to refresh the session
   * jsonStirng : constructing json string
   * @param userId
   * @param IPv4Address
   * apiProvider : to connect the server and get the data
   * @param url
   * @param requestMapping('String')
   * @param jsonString ('String')
   * @param requestMethod(POST/GET) 
   */
  sessionRefresh(){
    setTimeout(() => {
      if(this.networkType==='online'){
          this.clientUUID = this.device.uuid;
          this.jsonStirng={"userId":window.localStorage.getItem('userid'),"UUID": this.clientUUID};
          this.sessionRefreshApiCall = this.apiProvider.post('sesionRefresh',this.jsonStirng,'POST');
          this.sessionRefreshApiCall.subscribe(data => {
            if(data=== ""|| data=== undefined){
              //toast session refresh failed
              this.refreshSessionDialog('Somthing went wrong... click on Refresh or try again later');
            }
            else{
              window.localStorage.setItem('threadid',data.ThreadId);
              window.localStorage.setItem('serverip',data.IPv4Address);
              window.localStorage.setItem('isSessionRefreshed','true');
              this.events.publish('user:created', '');
              this.navCtrl.setRoot(HomePage);
            }
          }, (err) => {
            window.localStorage.setItem('isSessionRefreshed','false');
          });
      }
      else{
        this.clientUUID = this.device.uuid;
        this.jsonStirng={"userId":window.localStorage.getItem('userid'),"UUID": this.clientUUID};
        this.sessionRefreshApiCall = this.apiProvider.post('sesionRefresh',this.jsonStirng,'POST');
        this.sessionRefreshApiCall.subscribe(data => {
          if(data=== ""|| data=== undefined){
            //toast session refresh failed
            this.refreshSessionDialog('Somthing went wrong... click on Refresh or try again later');
          }
          else{
            window.localStorage.setItem('threadid',data.ThreadId);
            window.localStorage.setItem('serverip',data.IPv4Address);
            window.localStorage.setItem('isSessionRefreshed','true');
            this.events.publish('user:created', '');
            this.navCtrl.setRoot(HomePage);
          }
        }, (err) => {
          window.localStorage.setItem('isSessionRefreshed','false');
        });
      }
    }, 3000);
  }

   /**
   *this method is to notify the toast session refresh 
   */
  refreshSessionDialog(message:string){
    let alert = this.alertCtrl.create({
      title: 'Refresh Session',
      subTitle: message,
      buttons: [
        {
          text: 'Refresh',
          handler: data => {
            this.sessionRefresh();
          }
        }
      ]
    });
    alert.present();
  }
}
