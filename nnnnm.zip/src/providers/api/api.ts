/**********************************************************************************
 * Class-name - ApiProvider
 * Version - 0.1
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c)SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 * Generated class for the ApiProvider provider.
 * ApiProvider have methods implementation to perform the normal http url's 
 * post ,get,put,delete,patch and getSlides
 **********************************************************************************/
import { HttpClient , HttpParams} from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable()
export class ApiProvider{
  url: string = 'https://atihalms.srmap.edu.in/AtihaLMSMobile';
  fileAccessURL: string = 'https://atihalms.srmap.edu.in/';

  constructor(public http: HttpClient) {
  
  }

  /**
   * calling the services with GET
   * @param endpoint 
   * @param params 
   * @param reqOpts 
   */
  get(endpoint: string, params?: any, reqOpts?: any) {
    if (!reqOpts) {
      reqOpts = {
        params: new HttpParams()
      };
    }

    // Support easy query params for GET requests
    if (params) {
      reqOpts.params = new HttpParams();
      for (let k in params) {
        reqOpts.params = reqOpts.params.set(k, params[k]);
      }
    }
    return this.http.get(this.url + '/' + endpoint, reqOpts);
  }

  /**
   * calling the services of the slide share url
   * @param url 
   * @param params 
   * @param reqOpts 
   */
  getSlide(url: string, params?: any, reqOpts?: any){
    if (!reqOpts) {
      reqOpts = {
        params: new HttpParams()
      };
    }

    // Support easy query params for GET requests
    if (params) {
      reqOpts.params = new HttpParams();
      for (let k in params) {
        reqOpts.params = reqOpts.params.set(k, params[k]);
      }
    }
    return this.http.get(url, reqOpts);
  }

  /**
   * calling the services with POST
   * @param endpoint 
   * @param body 
   * @param reqOpts 
   */
  post(endpoint: string, body: any, reqOpts?: any) {
    return this.http.post(this.url + '/' + endpoint, body, reqOpts);
  }

  /**
   * calling the services with PUT
   * @param url 
   * @param endpoint 
   * @param body 
   * @param reqOpts 
   */
  put(url: string,endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(url + '/' + endpoint, body, reqOpts);
  }

  /**
   * calling the services with DELETE
   * @param url 
   * @param endpoint 
   * @param reqOpts 
   */
  delete(url: string,endpoint: string, reqOpts?: any) {
    return this.http.delete(url + '/' + endpoint, reqOpts);
  }

  /**
   * calling the services with PATCH
   * @param url 
   * @param endpoint 
   * @param body 
   * @param reqOpts 
   */
  patch(url: string,endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(url + '/' + endpoint, body, reqOpts);
  }
}
