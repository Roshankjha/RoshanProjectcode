import { AlertController, ToastController } from 'ionic-angular';
import { Injectable } from '@angular/core';

/*
  Generated class for the UpdateValidatorProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class UpdateValidatorProvider {

  constructor(public alertCtrl: AlertController,private toast: ToastController) {
    console.log('Hello UpdateValidatorProvider Provider');
  }

  connectionErrorAlert(title,message){
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [{text:'ok'}],
      enableBackdropDismiss: false
    });
    alert.present();
  }

  networkUpdateToast(connectionState){
    this.toast.create({
      message: `You are now ${connectionState}`,
      duration: 3000
    }).present();
  }

  serverErrorAlert(title,message){
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [{text:'ok'}],
      enableBackdropDismiss: false
    });
    alert.present();
  }

  downloadUpdateAlert(title:string,message:string,filepath:string,success:boolean){
    if(success){
      let alert = this.alertCtrl.create({
        title: title,
        subTitle: message,
        buttons: [
          {
            text: 'Ok',
            handler: () => {
            }
          },
          {
            text: 'Open',
            handler: () => {
            }
          }
        ]
      });
      alert.present();
    }else{
      let alert = this.alertCtrl.create({
        title: title,
        subTitle: message,
        buttons: [
          {
            text: 'Ok',
            handler: () => {
            }
          }
        ]
      });
      alert.present();
    }
  }

  uploadUpdateAlert(title:string,message:string){
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [
        {
          text: 'Ok',
          handler: () => {
          }
        }
      ]
    });
    alert.present();
  }

  fileSelectionErrorToast(fileName,errorMessage){
    this.toast.create({
      message: `Your file ${fileName} is ${errorMessage}`,
      duration: 3000
    }).present();
  }

  noNotificationToast(message){
    this.toast.create({
      message: `${message}`,
      duration: 3000
    }).present();
  }

  deleteUpdate(title:string,message:string){
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [
        {
          text: 'Ok',
          handler: () => {
          }
        }
      ]
    });
    alert.present();
  }

  shareUpdate(updateMessage){
    let alert = this.alertCtrl.create({
      title: updateMessage,
      buttons: [
        {
          text: 'Ok',
          handler: () => {
          }
        },
      ]
    });
    alert.present();
  }

  testUpdateAlert(title,message){
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [
        {
          text: 'Ok',
          handler: () => {
          }
        }
      ]
    });
    alert.present();
  }

  inProgressToast(message){
    this.toast.create({
      message: `${message}`,
      duration: 3000
    }).present();
  }

  validationUpdateToast(message){
    this.toast.create({
      message: `${message}`,
      duration: 3000
    }).present();
  }
}
