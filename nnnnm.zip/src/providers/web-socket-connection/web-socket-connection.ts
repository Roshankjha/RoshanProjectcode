/**********************************************************************************
 * Class-name - WebSocketConnectionProvider
 * Version - 0.1
 * Author - SRM Institute of Science and Technology
 ***********************************************************************************
 *
 * Copyright (c) SRM Institute of Science and Technology. All rights reserved.
 * No part of this product may be reproduced in any form by any means without prior
 * written authorization of SRM Institute of Science and Technology and its licensors, if any.
 *
 ***********************************************************************************
 * Generated class for the WebSocketConnectionProvider provider.
 * WebSocketConnectionProvider have methods implementation to perform sendMessage,closeSession method for session closing,
 * In GetInstanceStatus method include all websocket method for connection open,close,connection error
 * onopen method for connection open
 * onmessage for incoming message
 * onclose for server connection closing
 * onerror for server connection error 
 **********************************************************************************/
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { UpdateValidatorProvider } from '../update-validator/update-validator';

@Injectable()
export class WebSocketConnectionProvider {

  private websocket: WebSocket;

  constructor(public http: HttpClient,public updateVallidator:UpdateValidatorProvider) {
  
  }
/**
 * this is for sending message
 * @param text 
 */
  public sendMessage(text: string) {
    if(this.websocket.readyState==1){
      this.websocket.send(text);
    }else{
      this.updateVallidator.connectionErrorAlert("Connection Problem!","Message cannot be sent due to bad connection");
    }
  }
/**
 * websocket session close
 */
  public closeSession(){
    this.websocket.close();
  }
/**
 * This is method include all websocket method for connection open,close,connection error
 * onopen method for connection open
 * onmessage for incoming message
 * onclose for server connection closing
 * onerror for server connection error 
 */
 	public GetInstanceStatus(): Observable<any> {
    this.websocket = new WebSocket('wss://atihalms.srmap.edu.in/atihaLMS/atihaLMSChat/'+window.localStorage.getItem('roleAssignmentId')+'/'+window.localStorage.getItem('user_name')+'/mobile');
 /**
  * server connection open
  */
    this.websocket.onopen = (evt) => {
    };
     /**
     * server error
     */
    this.websocket.onerror = function(error){

      return error;
    };
 /**
 * incoming message
 */   
    this.websocket.onmessage = function incoming (data){
    };
    /**
     * server close
     */
    this.websocket.onclose = function CloseEvent(event:CloseEvent){
    };
		
	return Observable.fromEvent(this.websocket, 'message').map(res => (<any>res).data);
}

}
