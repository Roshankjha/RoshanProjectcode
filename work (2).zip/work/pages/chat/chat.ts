import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { WebSocketProvider } from '../../providers/web-socket/web-socket';
import { DatePipe } from '@angular/common';
import {  ViewController, IonicApp, Events } from 'ionic-angular';


/**
 * Generated class for the ChatPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-chat',
  templateUrl: 'chat.html',
})
export class ChatPage {
  receiverName:any;
  friendId:any;
  senderName:any;
  senderId:any;
  templateId:any;

  timeStamp:any;
  apiCall:any;
  chatHistoryApiCall:any;
  jsonStirng:any;
  messagesList: any[] = [];
  wrappedMessage:any;
  typedmsg:any;



  constructor(public navCtrl: NavController, public viewCtrl: ViewController,public navParams: NavParams,public apiProvider: ApiProvider,
  public websocket:WebSocketProvider,private _ngZone: NgZone,public _date:DatePipe) {
    this.receiverName=this.navParams.get('friendName');
    this.friendId=this.navParams.get('friendId');
    this.senderName=this.navParams.get('senderName');
    this.senderId=this.navParams.get('senderId');
    this.apiCall='http://'+'192.168.1.146'+':'+'8080'+'/PlatoAndroid';
   //this.getChatHistoryServiceCall(this.senderId,this.friendId);
   this.timeStamp=new Date()
  let latest_date=this._date.transform(this.timeStamp, 'yyyy-MM-dd');


    this.websocket.GetInstanceStatus().subscribe((result) => {
      this._ngZone.run(() => {
        console.log('ServerMessage : ',JSON.parse(result));
        let serverMsg=JSON.parse(result)
        console.log('ServerMessage : ',serverMsg.id+"--"+serverMsg.time+"--"+serverMsg.message);
          if(serverMsg.id == this.friendId ){
        this.messagesList.push({
          senderId: serverMsg.id,
          dateSent: serverMsg.time,
         senderMessage: serverMsg.message
        })}
      });
    });
 }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChatPage');
  }

  getChatHistoryServiceCall(senderId:any, receiverId:any){
    this.jsonStirng={"senderRoleAssignmentId":window.localStorage.getItem('roleAssignmentId'),"receiverRoleAssignmentId":this.friendId};
    this.chatHistoryApiCall = this.apiProvider.post(this.apiCall,'getTheChatHistory',this.jsonStirng,'POST'); 
    this.chatHistoryApiCall.subscribe(data => { 
      console.log('chatHistoryList  : ',data);

    for (let _i = 0; _i < data.length; _i++) {
      this.templateId=data[_i].id;
      this.messagesList.push({
      senderId: data[_i].id,
      dateSent: data[_i].time,
      senderMessage: data[_i].message
    })
    }
    console.log("MessageList:  ",this.messagesList);
    this.messagesList=[];
  }, (err) => {console.log(err);});
}

public closechat(): void {
  this.viewCtrl.dismiss()
}

sendMessage(): void {
  this.timeStamp=new Date()
  let latest_date=this._date.transform(this.timeStamp, 'dd-MM-yyyy HH.mm');
  this.wrappedMessage=this.friendId+"|"+this.typedmsg;
  this.websocket.sendMessage(this.wrappedMessage);
 
  this.messagesList.push({
    senderId: this.senderId,
    dateSent: latest_date,
    senderMessage: this.typedmsg
  })
  this.typedmsg=" ";
}


}
