import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ChatPage } from '../chat/chat';

/**
 * Generated class for the FriendListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-friend-list',
  templateUrl: 'friend-list.html',
})
export class FriendListPage {

  onlineFriendsList:any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.onlineFriendsList = [
      { "roleAssignid":"1", "name":"Sarah"},
      { "roleAssignid":"2", "name":"Veena"},
      { "roleAssignid":"3", "name":"Sushma" },
      { "roleAssignid":"4","name":"Nalina" },
      { "roleAssignid":"5", "name":"Janani" },
      { "roleAssignid":"6","name":"Saket"},
      { "roleAssignid":"7","name":"Arjun"},
      { "roleAssignid":"8","name":"Sai"},
      { "roleAssignid":"9","name":"Sheshadhri"},
      { "roleAssignid":"10","name":"Miley"}
    ];
    console.log("UserName: ",window.localStorage.getItem('userName'));
    console.log("RoleAssignmentId: ",window.localStorage.getItem('roleAssignmentId'));
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad FriendListPage');
  }
  onFriendListItemClick(params) {
    console.log("roleAssignid: ",params.roleAssignid);
    console.log("Receiver name: ",params.name);    
    this.navCtrl.push(ChatPage,{
      friendName:params.name,
      friendId:params.roleAssignid,
      senderName:window.localStorage.getItem('userName'),
      senderId:window.localStorage.getItem('roleAssignmentId'),
      fromPage:"FriendListPage" 
    });
  }
}
