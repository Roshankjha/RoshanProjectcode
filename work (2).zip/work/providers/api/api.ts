import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the ApiProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ApiProvider {

  constructor(public http: HttpClient) {
    console.log('Hello ApiProvider Provider');
  }
  get(url: string,endpoint: string, params?: any, reqOpts?: any) {
    if (!reqOpts) {
      reqOpts = {
        params: new HttpParams()
      };
    }

    // Support easy query params for GET requests
    if (params) {
      reqOpts.params = new HttpParams();
      for (let k in params) {
        reqOpts.params = reqOpts.params.set(k, params[k]);
      }
    }
    return this.http.get(url + '/' + endpoint, reqOpts);
  }

  getSlide(url: string, params?: any, reqOpts?: any){
    if (!reqOpts) {
      reqOpts = {
        params: new HttpParams()
      };
    }

    // Support easy query params for GET requests
    if (params) {
      reqOpts.params = new HttpParams();
      for (let k in params) {
        reqOpts.params = reqOpts.params.set(k, params[k]);
      }
    }
    return this.http.get(url, reqOpts);
  }

  post(url: string,endpoint: string, body: any, reqOpts?: any) {
    return this.http.post(url + '/' + endpoint, body, reqOpts);
  }

  put(url: string,endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(url + '/' + endpoint, body, reqOpts);
  }

  delete(url: string,endpoint: string, reqOpts?: any) {
    return this.http.delete(url + '/' + endpoint, reqOpts);
  }

  patch(url: string,endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(url + '/' + endpoint, body, reqOpts);
  }

}
