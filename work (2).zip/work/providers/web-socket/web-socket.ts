import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Rx';
/*
  Generated class for the WebSocketProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class WebSocketProvider {
	private websocket: WebSocket;

  constructor(public http: HttpClient) {
    console.log('Hello WebSocketProvider Provider');
  }
  public sendMessage(text: string) {
		this.websocket.send(text);
	}
 	public GetInstanceStatus(): Observable<any> {
		this.websocket = new WebSocket("ws://192.168.1.151:8080/Plato_Chat/platoChat/"+window.localStorage.getItem('roleAssignmentId')+"/"+window.localStorage.getItem('userName')+"/mobile");
		this.websocket.onopen = (evt) => {
		};
		this.websocket.onerror = function(error){
			console.log('connection or the server is down.');
		};
		this.websocket.onmessage = function incoming (data){
		console.log("******************");
		console.log(data);
	}
	this.websocket.onclose = function CloseEvent(event:CloseEvent){
		console.log("connection.....close");
	}
	return Observable.fromEvent(this.websocket, 'message').map(res => (<any>res).data);
}
}
