/**
***********************************************************************************
* Version - 1.0 
* Author - SRM RI
***********************************************************************************
*
* Copyright (c) SRM Institute of Science and Technology. All rights reserved.
* No part of this product may be reproduced in any form by any means without prior
* written authorization of SRM Institute of Science and Technology and its licensors, if any.
*
***********************************************************************************
 */
package com.srmri.atihaLMS.chat.controller;

import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.srmri.atihaLMS.core.rbac.service.RbacRoleAssignmentService;
import com.srmri.atihaLMS.core.rbac.service.RbacRoleService;

import au.com.bytecode.opencsv.CSVReader;
import main.java.com.srmri.atihaLMS.core.login.bean.UserBean;
import main.java.com.srmri.atihaLMS.core.usermanagement.model.UmFaculty;
import main.java.com.srmri.atihaLMS.core.usermanagement.model.UmStudent;
import main.java.com.srmri.atihaLMS.core.usermanagement.model.UmUserDetails;
import main.java.com.srmri.atihaLMS.core.usermanagement.service.UmFacultyService;
import main.java.com.srmri.atihaLMS.core.usermanagement.service.UmStudentService;
import main.java.com.srmri.atihaLMS.core.usermanagement.service.UmUserDetailsService;

@Controller
public class PrivateChatController {

	@Autowired
	private RbacRoleAssignmentService roleAssignmentService;

	@Autowired
	private RbacRoleService roleService;

	@Autowired
	private UmUserDetailsService umUserDetailsService;

	@Autowired
	private UmStudentService umStudentService;

	@Autowired
	private UmFacultyService umFacultyService;

	@Value("${config.filePath}") private String chatHistoryFilePath;

	@RequestMapping(value = "/privateChat", method = RequestMethod.GET)
	public String goToPrivateChat(Model model, @ModelAttribute("user") UserBean userBean) {
		System.out.println("came here");
		return "/chat/privateChatRoom";
	}

	/**
	 * Get the history of chat between two users
	 */
	@RequestMapping(value="/getTheChatHistory", method = RequestMethod.GET)
	public @ResponseBody String getTheChatHistory(@RequestParam(value = "senderId") Long senderId, @RequestParam(value = "receiverId") Long receiverId) throws ParseException {
		try {
			/*String rootPath = System.getProperty("catalina.home");*/
			String rootPath = chatHistoryFilePath;
			// storePath Format:
			String storePath = File.separator + "atihaLMS" + File.separator + "Chat"
				+ File.separator + "Chat_History";
			File dir = new File(rootPath + storePath);
			if (!dir.exists())
				dir.mkdirs();
			String csvFileName = dir+File.separator+receiverId+"_"+senderId+".csv";
			String csvFileNameReverse = dir+File.separator+senderId+"_"+receiverId+".csv";
			File file = new File(csvFileName);
			File fileReverse = new File(csvFileNameReverse);
			if(file.exists()) {
				String chatHistory = getTheDetailsOfChat(file);
				return chatHistory;
			} if(fileReverse.exists()) {
				String chatHistory = getTheDetailsOfChat(fileReverse);
				return chatHistory;
			} else {
				Gson gson = new Gson();
				String json = gson.toJson("No Record Found");
				return json;
			}
		} catch(Exception e) {
			Gson gson = new Gson();
			String json = gson.toJson("error");
			return json;
		}
	}

	/**
	 * Get the chat history
	 * @param fileName
	 * @return
	 */
	private String getTheDetailsOfChat(File fileName) {
		try {
			List<HashMap<String, String>> chatHistory = new ArrayList<HashMap<String, String>>();
			CSVReader reader = new CSVReader(new FileReader(fileName), ',');
			List<String[]> csvBody = reader.readAll();
			reader.close();
			int reducedValue = csvBody.size()-10;
			if(csvBody.size()<=10) {
				for(int i=0;i<csvBody.size();i++) {
					HashMap<String, String> currentMsg = new HashMap<String, String>();
					currentMsg.put("id", csvBody.get(i)[0]);
					currentMsg.put("time", csvBody.get(i)[1]);
					currentMsg.put("message", csvBody.get(i)[2]);
					currentMsg.put("flag", csvBody.get(i)[3]);
					chatHistory.add(currentMsg);
				}
			} else {
				for(int i=reducedValue;i<=csvBody.size();i++) {
					HashMap<String, String> currentMsg = new HashMap<String, String>();
					currentMsg.put("id", csvBody.get(i-1)[0]);
					currentMsg.put("time", csvBody.get(i-1)[1]);
					currentMsg.put("message", csvBody.get(i-1)[2]);
					currentMsg.put("flag", csvBody.get(i-1)[3]);
					chatHistory.add(currentMsg);
				}
			}
			Gson gson = new Gson();
			List<HashMap<String, String>> chatHistory1 = new ArrayList<HashMap<String, String>>();
			String json1 = gson.toJson(chatHistory1);
			System.out.println("check empty json string : "+json1);
			String json = gson.toJson(chatHistory);
			return json;
		} catch(Exception e) {
			e.printStackTrace();
			Gson gson = new Gson();
			String json = gson.toJson("error");
			return json;
		}
	}

	@RequestMapping(value="/getTheLiveUsersList", method = RequestMethod.POST)
	public @ResponseBody String getTheLiveUsersList(@RequestBody String listOfLiveUsers){
		try {
			System.out.println("----------");
			System.out.println(listOfLiveUsers);
			JsonObject newJObject = null;
			JsonParser parser = new JsonParser();
			newJObject = (JsonObject) parser.parse(listOfLiveUsers);
			System.out.println(newJObject.get("id").getAsString());
			System.out.println("----------");
			List<HashMap<String, String>> idAndName = new ArrayList<HashMap<String, String>>();
			String initialList = newJObject.get("id").getAsString();
			String secondList = initialList.replace("[", "");
			String finalList = secondList.replace("]", "");
			System.out.println(finalList);
			String[] listOfOnlineUsers = finalList.split(",");
			for(int i=0; i<listOfOnlineUsers.length; i++) {
				listOfOnlineUsers[i] = listOfOnlineUsers[i].replaceAll("\\s+","");
				Integer roleLevelId = roleService.rbacBsGetRole(roleAssignmentService.rbacBsGetRoleAssignment(Long.parseLong(listOfOnlineUsers[i])).getRoleId()).getRoleLevelId();
				HashMap<String, String> currentLi = new HashMap<String, String>();
				UmUserDetails currUser = umUserDetailsService.blGetUser(roleAssignmentService.rbacBsGetRoleAssignment(Long.parseLong(listOfOnlineUsers[i])).getUserId());
				String profileImage = "../ProfileImages"+"/" +currUser.getEmailId() +"/" + currUser.getImage();
				if(roleLevelId == 1) {
					currentLi.put("id", listOfOnlineUsers[i]+";;"+currUser.getUserName()+";;"+profileImage);
					currentLi.put("name", currUser.getUserName());
					currentLi.put("imagePath", profileImage);
					currentLi.put("roleAssignmentId", listOfOnlineUsers[i]);
				} else if(roleLevelId == 2) {
					UmFaculty currFaculty = umFacultyService.blGetFacultyByUserId(currUser.getUserId());
					currentLi.put("id", listOfOnlineUsers[i]+";;"+currFaculty.getFirstName()+" "+currFaculty.getLastName()+";;"+profileImage);
					currentLi.put("name", currFaculty.getFirstName()+" "+currFaculty.getLastName());
					currentLi.put("imagePath", profileImage);
					currentLi.put("roleAssignmentId", listOfOnlineUsers[i]);
				} else if(roleLevelId == 3) {
					UmStudent currStudent = umStudentService.blGetStudentByUserId(currUser.getUserId());
					currentLi.put("id", listOfOnlineUsers[i]+";;"+currStudent.getFirstName()+" "+currStudent.getLastName()+";;"+profileImage);
					currentLi.put("name", currStudent.getFirstName()+" "+currStudent.getLastName());
					currentLi.put("imagePath", profileImage);
					currentLi.put("roleAssignmentId", listOfOnlineUsers[i]);
				}
				idAndName.add(currentLi);
			}
			System.out.println("-----------------------------------------");
			for(int i=0; i<idAndName.size();i++) {
				System.out.println(idAndName.get(i).get("id"));
			}
			System.out.println("-----------------------------------------");
			System.out.println(idAndName.size());
			Gson gson = new Gson();
			String json = gson.toJson(idAndName);
			return json;
		} catch(Exception e) {
			e.printStackTrace();
			Gson gson = new Gson();
			String json = gson.toJson("error");
			return json;
		}
	}
}
