/**
***********************************************************************************
* Version - 1.0 
* Author - SRM RI
***********************************************************************************
*
* Copyright (c) SRM Institute of Science and Technology. All rights reserved.
* No part of this product may be reproduced in any form by any means without prior
* written authorization of SRM Institute of Science and Technology and its licensors, if any.
*
***********************************************************************************
 */
package com.srmri.atihaLMS.chat.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.websocket.Session;

@Singleton
public class SessionRegistryPrivateChat {

	private final HashMap<Long, Session> liveUsers = new HashMap<Long, Session>();
	private final HashMap<Long, List<Long>> listOfLiveChat = new HashMap<Long, List<Long>>();

	/**
	 * Add the HashMap value
	 * @param roleAssignmentId
	 * @param session
	 */
	@Lock(LockType.WRITE)
	public void addLiveUser(Long roleAssignmentId, Session session) {
		liveUsers.put(roleAssignmentId, session);
		if(listOfLiveChat.get(roleAssignmentId)==null) {
			List<Long> receiverList = new ArrayList<Long>();
			listOfLiveChat.put(roleAssignmentId, receiverList);
		}
	}

	/**
	 * Update both sender and receiver listOfLiveChat hashamp
	 * @param roleAssignmentId
	 * @param session
	 */
	@Lock(LockType.WRITE)
	public void updateListOfLiveChat(Long senderRoleAssignmentId, Long receiverRoleAssignmentId) {
		List<Long> senderList = listOfLiveChat.get(senderRoleAssignmentId);
		senderList.add(receiverRoleAssignmentId);
		listOfLiveChat.put(senderRoleAssignmentId, senderList);
		List<Long> receiverList = listOfLiveChat.get(receiverRoleAssignmentId);
		receiverList.add(senderRoleAssignmentId);
		listOfLiveChat.put(receiverRoleAssignmentId, receiverList);
	}

	/**
	 * Update sender live chat hashMap
	 * @param roleAssignmentId
	 * @param session
	 */
	@Lock(LockType.WRITE)
	public void updateLiveChatSenderHashMap(Long senderRoleAssignmentId, Long receiverRoleAssignmentId) {
		List<Long> senderList = listOfLiveChat.get(senderRoleAssignmentId);
		senderList.add(receiverRoleAssignmentId);
		listOfLiveChat.put(senderRoleAssignmentId, senderList);
	}

	/**
	 * Update receiver live chat hashMap
	 * @param roleAssignmentId
	 * @param session
	 */
	@Lock(LockType.WRITE)
	public void updateLiveChatReceiverHashMap(Long senderRoleAssignmentId, Long receiverRoleAssignmentId) {
		List<Long> receiverList = listOfLiveChat.get(receiverRoleAssignmentId);
		receiverList.add(senderRoleAssignmentId);
		listOfLiveChat.put(receiverRoleAssignmentId, receiverList);
	}

	/**
	 * Get the session object of a particular roleAssignmentId
	 * @param receiverRoleAssignmentId
	 * @return
	 */
	@Lock(LockType.READ)
	public Session getTheSessionOfReceiver(Long receiverRoleAssignmentId) {
		return liveUsers.get(receiverRoleAssignmentId);
	}

	/**
	 * Get the list of live chat of a particular roleAssignmentId
	 * @param receiverRoleAssignmentId
	 * @return
	 */
	@Lock(LockType.READ)
	public List<Long> getTheSenderChatList(Long receiverRoleAssignmentId) {
		return listOfLiveChat.get(receiverRoleAssignmentId);
	}

	@Lock(LockType.READ)
	public Session checkReceiverIsChattingWith(Long receiverRoleAssignmentId) {
		return liveUsers.get(receiverRoleAssignmentId);
	}

	/**
	 * Get list of all live Users
	 * @param receiverRoleAssignmentId
	 * @return
	 */
	@Lock(LockType.READ)
	public List<Long> getListOfAllLiveUsers() {
		List<Long> allUserList = new ArrayList<Long>();
		for(Map.Entry<Long, Session> currentLiveUser : liveUsers.entrySet()) {
			allUserList.add(currentLiveUser.getKey());
		}
		return allUserList;
	}

	/**
	 * Delete the two hashmap value
	 * @param roleAssignment
	 */
	@Lock(LockType.WRITE)
	public void deleteRoleAssignmentEntry(Long roleAssignmentId) {
		liveUsers.remove(roleAssignmentId);
		listOfLiveChat.remove(roleAssignmentId);
	}

	/**
	 * Delete the receiverId from sender list
	 * @param senderRoleAssignmentId
	 * @param receiverRoleAssignmentId
	 */
	@Lock(LockType.WRITE)
	public void deleteReceiverFromSender(Long senderRoleAssignmentId, Long receiverRoleAssignmentId) {
		List<Long> senderList = listOfLiveChat.get(senderRoleAssignmentId);
		senderList.remove(receiverRoleAssignmentId);
		listOfLiveChat.put(senderRoleAssignmentId, senderList);
	}

	/**
	 * Check whether the given roleAssignmentId have session or not
	 * 1 - session is available
	 * 0 - session is not available
	 * @param roleAssingmentId
	 * @return
	 */
	@Lock(LockType.READ)
	public Integer roleAssignmentCheck(Long roleAssingmentId) {
		if(liveUsers.get(roleAssingmentId) != null) {
			return 1;
		} else {
			return 0;
		}
	}
}