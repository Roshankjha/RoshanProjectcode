/**
***********************************************************************************
* Version - 1.0 
* Author - SRM RI
***********************************************************************************
*
* Copyright (c) SRM Institute of Science and Technology. All rights reserved.
* No part of this product may be reproduced in any form by any means without prior
* written authorization of SRM Institute of Science and Technology and its licensors, if any.
*
***********************************************************************************
 */
package com.srmri.atihaLMS.chat.controller;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.inject.Inject;
import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.json.JSONObject;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

@ServerEndpoint("/atihaLMSChat/{roleAssignmentId}/{nameOfUser}/{deviceFrom}")
public class WebSocketPrivateChat {

	/**
	 * ***************************************************** *
	 * ***************************************************** *
	 * 				WEB CHAT MESSAGE CODES					 *
	 * ***************************************************** *
	 * ***************************************************** *
	 * Message Code Details									 *
	 * ***************************************************** *
	 * 1 - Update Sender RoleAssignment Receiver List		 *
	 * ***************************************************** *
	 * 2 - Send message to sender and receiver				 *
	 * 		2a - First time message from sender to receiver	 *
	 * 		2b - Normal message from sender to receiver		 *
	 * ***************************************************** *
	 * 3 - Delete a particular Receiver RoleAssignmentId	 *
	 * 		from sender										 *
	 * ***************************************************** *
	 * 4 - Update Status of a RoleAssignmentId				 *
	 * 		4a - User is online								 *
	 * 		4b - User is offline or busy					 *
	 * ***************************************************** *
	 * 5 - Get the list of live users						 *
	 * ***************************************************** *
	 */

	@Inject
	private SessionRegistryPrivateChat sessionRegistry;

	@Inject
	private MobileSessionRegistry mobileSessoinRegistry;

	@OnOpen
	public void open(Session session, @PathParam("roleAssignmentId") Long roleAssignmentId, @PathParam("nameOfUser") String nameOfUser,
			@PathParam("deviceFrom") String deviceFrom) {
		if(deviceFrom.equalsIgnoreCase("web")) {
			sessionRegistry.addLiveUser(roleAssignmentId, session);
		} else {
			mobileSessoinRegistry.addLiveUser(roleAssignmentId, session);
		}
	}

	@OnMessage
	public void receiveMessage(String message, Session session, @PathParam("roleAssignmentId") Long roleAssignmentId,
			@PathParam("nameOfUser") String nameOfUser, @PathParam("deviceFrom") String deviceFrom) throws IOException{
		System.out.println("-------------------");
		System.out.println("device From");
		System.out.println("-------------------");
		System.out.println(deviceFrom);
		System.out.println("-------------------");
		if(deviceFrom.equalsIgnoreCase("web")) {
			/**
			 * WEB @OnMessage CODE
			 */
			System.out.println(message);
			String[] messageInfo =  message.split(";;");
			if(messageInfo[0].equalsIgnoreCase("5")) {
				List<Long> webLiveUsers = sessionRegistry.getListOfAllLiveUsers();
				List<Long> mobileLiveUsers = mobileSessoinRegistry.getListOfAllLiveUsers();
				List<Long> liveUsers = new ArrayList<Long>();
				for(Long currUser : webLiveUsers) {
					liveUsers.add(currUser);
				}
				for(Long currUser : mobileLiveUsers) {
					if(!liveUsers.contains(currUser)) {
						liveUsers.add(currUser);
					}
				}
				session.getAsyncRemote().sendText("5;;"+liveUsers);
			}
			if(messageInfo[0].equalsIgnoreCase("1")) {
				List<Long> getTheListOfLiveChatIdsSender = sessionRegistry.getTheSenderChatList(roleAssignmentId);
				if(!(getTheListOfLiveChatIdsSender.contains(Long.parseLong(messageInfo[2])))) {
					sessionRegistry.updateLiveChatSenderHashMap(roleAssignmentId, Long.parseLong(messageInfo[2]));
				}
			}
			if(messageInfo[0].equalsIgnoreCase("2")) {
				Integer receiverCheckValue = sessionRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[1]));
				Integer receiverMobileCheckValue = mobileSessoinRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[1]));
				System.out.println("--------------------------------");
				System.out.println("web sender");
				System.out.println("--------------------------------");
				System.out.println("receiverCheckValue : "+receiverCheckValue);
				System.out.println("receiverMobileCheckValue : "+receiverMobileCheckValue);
				System.out.println("--------------------------------");
				if(receiverCheckValue == 1 && receiverMobileCheckValue == 1) {
					System.out.println("came inside : receiverCheckValue == 1 && receiverMobileCheckValue == 1");
					System.out.println("--------------------------------");
					sendToWebReceiverFromWebSender(message, roleAssignmentId, nameOfUser, session, 1);
					sendToMobileReceiverFromWebSender(message, roleAssignmentId, nameOfUser, 0);
				} else if(receiverCheckValue == 1) {
					System.out.println("came inside : receiverCheckValue == 1");
					System.out.println("--------------------------------");
					sendToWebReceiverFromWebSender(message, roleAssignmentId, nameOfUser, session, 1);
				} else if(receiverMobileCheckValue == 1) {
					System.out.println("came inside : receiverMobileCheckValue == 1");
					System.out.println("--------------------------------");
					sendToMobileReceiverFromWebSender(message, roleAssignmentId, nameOfUser, 1);
				} else {
					System.out.println("came inside : final else part");
					System.out.println("--------------------------------");
					session.getAsyncRemote().sendText("4c;; User went offline!...Message did not go.. Try after some time..;;"+messageInfo[1]);
				}

				/**
				 * *************************************************************************************************************************************
				 * Syncing Code
				 * Sender is online in both web and mobile device
				 * *************************************************************************************************************************************
				 */
				Integer senderMobileRoleAssignmentCheck = mobileSessoinRegistry.roleAssignmentCheck(roleAssignmentId);
				if(senderMobileRoleAssignmentCheck == 1 && deviceFrom.equalsIgnoreCase("web")) {
					JSONObject messageobj = new JSONObject();
					try {
						String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
						messageobj.put("id", roleAssignmentId);
						messageobj.put("time", timeStamp);
						messageobj.put("message", messageInfo[2]);
						messageobj.put("flag", new Boolean(true));
						messageobj.put("name", nameOfUser + ":");
					} catch (Exception e) {
						e.printStackTrace();
					}
					mobileSessoinRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText(messageobj.toString());
				}
				/**
				 * *************************************************************************************************************************************
				 */
			}
			if(messageInfo[0].equalsIgnoreCase("3")) {
				sessionRegistry.deleteReceiverFromSender(roleAssignmentId, Long.parseLong(messageInfo[1]));
			}
			if(messageInfo[0].equalsIgnoreCase("4")) {
				/**
				 * 4a,4b Message format
				 * <message_code>;;<message>;;<receiverId>;;<divId>
				 */
				Integer receiverCheckValue = sessionRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[1]));
				if(receiverCheckValue == 1) {
					if(sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1]))!=null) {
						if(sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1])).size() < 4) {
							session.getAsyncRemote().sendText("4a;;"+messageInfo[2]+" is online now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
						} else {
							session.getAsyncRemote().sendText("4b;;"+messageInfo[2]+" is busy now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
						}
					} else {
						session.getAsyncRemote().sendText("4b;;"+messageInfo[2]+" is offline now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
					}
				}
				Integer receiverCheckValueForMobile = mobileSessoinRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[1]));
				if(receiverCheckValueForMobile == 1) {
					if(mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1]))!=null) {
						if (mobileSessoinRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1])).size() < 1) {
							session.getAsyncRemote().sendText("4a;;"+messageInfo[2]+" is online now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
						} else {
							session.getAsyncRemote().sendText("4b;;"+messageInfo[2]+" is busy now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
						}
					}
					else {
						session.getAsyncRemote().sendText("4b;;"+messageInfo[2]+" is offline now!...;;"+messageInfo[1]+";;"+messageInfo[3]);
					}
				}
			}
		} else {
			/**
			 * MOBILE @OnMessage CODE
			 */
			String[] messageInfo = message.split(Pattern.quote("|"));
			if(messageInfo[0].equalsIgnoreCase("5")) {
				List<Long> webLiveUsers = sessionRegistry.getListOfAllLiveUsers();
				List<Long> mobileLiveUsers = mobileSessoinRegistry.getListOfAllLiveUsers();
				List<Long> liveUsers = new ArrayList<Long>();
				for(Long currUser : mobileLiveUsers) {
					if(roleAssignmentId.compareTo(currUser) != 0){
						liveUsers.add(currUser);
					}
				}
				for(Long currUser : webLiveUsers) {
					if(!liveUsers.contains(currUser) && roleAssignmentId.compareTo(currUser) != 0) {
						liveUsers.add(currUser);
					}
				}
				mobileSessoinRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText(liveUsers.toString());
			} else {
				Integer receiverCheckValue = sessionRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[0]));
				Integer receiverMobileCheckValue = mobileSessoinRegistry.roleAssignmentCheck(Long.parseLong(messageInfo[0]));
				System.out.println("--------------------------------");
				System.out.println("mobile sender");
				System.out.println("--------------------------------");
				System.out.println("receiverMobileCheckValue : "+receiverMobileCheckValue);
				System.out.println("receiverCheckValue : "+receiverCheckValue);
				System.out.println("--------------------------------");
				if(receiverMobileCheckValue == 1 && receiverCheckValue == 1) {
					System.out.println("receiverMobileCheckValue == 1 && receiverCheckValue == 1");
					System.out.println("--------------------------------");
					sendToMobileReceiverFromMobileSender(message, roleAssignmentId, nameOfUser, 1);
					sendToWebReceiverFromMobileSender(message, roleAssignmentId, nameOfUser, 0);
				} else if(receiverMobileCheckValue == 1) {
					System.out.println("receiverMobileCheckValue == 1");
					System.out.println("--------------------------------");
					sendToMobileReceiverFromMobileSender(message, roleAssignmentId, nameOfUser, 1);
				} else if(receiverCheckValue == 1) {
					System.out.println("receiverCheckValue == 1");
					System.out.println("--------------------------------");
					sendToWebReceiverFromMobileSender(message, roleAssignmentId, nameOfUser, 1);
				} else {
					System.out.println("final else");
					System.out.println("--------------------------------");
					JSONObject messageobj = new JSONObject();
					try {
						String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
						messageobj.put("id", roleAssignmentId);
						messageobj.put("time", timeStamp);
						messageobj.put("message", "USER IS OFFLINE.. your message did not go. Try after some time");
						messageobj.put("flag", new Boolean(true));
					} catch (Exception e) {
						e.printStackTrace();
					}
					mobileSessoinRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText(messageobj.toString());
				}
				
				/**
				 * *************************************************************************************************************************************
				 * Syncing Code
				 * Sender is online in both mobile device and web
				 * *************************************************************************************************************************************
				 */
				Integer senderWebRoleAssignmentCheck = sessionRegistry.roleAssignmentCheck(roleAssignmentId);
				if(senderWebRoleAssignmentCheck == 1 && deviceFrom.equalsIgnoreCase("mobile")) {
					List<Long> getTheListOfLiveChatIdsOfSender = sessionRegistry.getTheSenderChatList(roleAssignmentId);
					if(getTheListOfLiveChatIdsOfSender.contains(Long.parseLong(messageInfo[0]))) {
						sessionRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText("2c;;"+messageInfo[0]+";;"+messageInfo[1]);
					}
				}
				/**
				 * *************************************************************************************************************************************
				 */
			}
		}
	}

	@OnClose
	public void close(Session session, CloseReason c, @PathParam("roleAssignmentId") Long roleAssignmentId,
			@PathParam("nameOfUser") String nameOfUser, @PathParam("deviceFrom") String deviceFrom) throws IOException {
		sessionRegistry.deleteRoleAssignmentEntry(roleAssignmentId);
		session.close();
	}

	public void saveTheMessage(Long senderRoleAssignmentId, Long receiverRoleAssignmentId, String message, String filePath) {
		String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
		String[] currentMessage = new String[4];
		currentMessage[0] = ""+senderRoleAssignmentId;
		currentMessage[1] = timeStamp;
		currentMessage[2] = message;
		currentMessage[3] = "true";
		/*String rootPath = System.getProperty("catalina.home");*/
		String rootPath = filePath;
		System.out.println("rootPath : "+rootPath);
		/**
		 * STORAGE PATH FORMAT
		 */
		String storePath = File.separator + "atihaLMS" + File.separator + "Chat"
			+ File.separator + "Chat_History";
		File dir = new File(rootPath + storePath);
		if (!dir.exists())
			dir.mkdirs();
		/**
		 * File Name Pattern
		 * senderId_receiverId.csv or receiverId_senderId.csv
		 */
		String csvFileName = dir+File.separator+receiverRoleAssignmentId+"_"+senderRoleAssignmentId+".csv";
		String csvFileNameReverse = dir+File.separator+senderRoleAssignmentId+"_"+receiverRoleAssignmentId+".csv";
		File file = new File(csvFileName);
		File fileReverse = new File(csvFileNameReverse);
		try {
			if(file.exists()) {
				CSVReader reader = new CSVReader(new FileReader(csvFileName), ',');
				List<String[]> csvBody = reader.readAll();
				csvBody.add(currentMessage);
				reader.close();
				CSVWriter writer = new CSVWriter(new FileWriter(csvFileName), ',');
				writer.writeAll(csvBody);
				writer.flush();
				writer.close();
			} else if(fileReverse.exists()) {
				CSVReader reader = new CSVReader(new FileReader(csvFileNameReverse), ',');
				List<String[]> csvBody = reader.readAll();
				csvBody.add(currentMessage);
				reader.close();
				CSVWriter writer = new CSVWriter(new FileWriter(csvFileNameReverse), ',');
				writer.writeAll(csvBody);
				writer.flush();
				writer.close();
			} else {
				CSVWriter writer = new CSVWriter(new FileWriter(csvFileName), ',');
				List<String[]> csvBody = new ArrayList<String[]>();
				csvBody.add(currentMessage);
				writer.writeAll(csvBody);
				writer.flush();
				writer.close();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sender WEB - Receiver MOBILE
	 * @param message
	 * @param roleAssignmentId
	 * @param nameOfUser
	 */
	public void sendToMobileReceiverFromWebSender(String message, Long roleAssignmentId, String nameOfUser, Integer saveFlag) {
		System.out.println("------------------");
		System.out.println("came inside : sendToMobileReceiverFromWebSender");
		System.out.println("------------------");
		/**
		 * CODE for Integration of Mobile
		 * SENDER WEB - RECEIVER MOBILE
		 */
		/**
		 * code for sending message from web to mobile
		 */
		String[] messageInfo = message.split(";;");
		if(saveFlag == 1) {
			saveTheMessage(roleAssignmentId, Long.parseLong(messageInfo[1]), messageInfo[2], messageInfo[4]);
		}
		if (mobileSessoinRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1])).size() < 1) {
			mobileSessoinRegistry.updateLiveChatReceiverHashMap(roleAssignmentId, Long.parseLong(messageInfo[1]));
			JSONObject messageobj = new JSONObject();
			try {
				String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
				messageobj.put("id", roleAssignmentId);
				messageobj.put("time", timeStamp);
				messageobj.put("message", messageInfo[2]);
				messageobj.put("flag", new Boolean(true));
				messageobj.put("name", nameOfUser + ":");
			} catch (Exception e) {
				e.printStackTrace();
			}
			mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText(messageobj.toString());
		} else {
			JSONObject messageobj = new JSONObject();
			try {
				String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
				messageobj.put("id", roleAssignmentId);
				messageobj.put("time", timeStamp);
				messageobj.put("message", messageInfo[2]);
				messageobj.put("flag", new Boolean(true));
				messageobj.put("name", nameOfUser + ":");
			} catch (Exception e) {
				e.printStackTrace();
			}
			mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText(messageobj.toString());
		}
	}

	/**
	 * Sender WEB - Web Receiver
	 * @param message
	 * @param roleAssignmentId
	 * @param nameOfUser
	 * @param session
	 */
	public void sendToWebReceiverFromWebSender(String message, Long roleAssignmentId, String nameOfUser, Session session, Integer saveFlag) {
		System.out.println("------------------");
		System.out.println("came inside : sendToWebReceiverFromWebSender");
		System.out.println("------------------");
		/**
		 * SENDER WEB - RECEIVER WEB
		 */
		/**
		 * <message_code>;;<message>;;<sender_id>;;<nameOfSender>;;<senderImagePath>
		 */
		String[] messageInfo = message.split(";;");
		if(sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1]))!=null) {
			/**
			 * RECEIVER IS ONLINE
			 */
			if(saveFlag == 1) {
				saveTheMessage(roleAssignmentId, Long.parseLong(messageInfo[1]), messageInfo[2], messageInfo[4]);
			}
			if(sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1])).size() < 4) {
				/**
				 * RECEIVER IS NOT BUSY
				 */
				List<Long> getTheListOfLiveChatIdsReceiver = sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1]));
				if(getTheListOfLiveChatIdsReceiver.contains(roleAssignmentId)) {
					/**
					 * RECEIVER IS ALREADY CHATTING WITH SENDER
					 */
					sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText("2b;;"+messageInfo[2]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
				} else {
					/**
					 * RECEIVER IS NOT CHATTING WITH SENDER BUT FREE TO TAKE MORE MESSAGES
					 */
					sessionRegistry.updateLiveChatReceiverHashMap(roleAssignmentId, Long.parseLong(messageInfo[1]));
					sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText("2a;;"+messageInfo[2]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
				}
			} else {
				/**
				 * RECEIVER IS BUSY
				 */
				List<Long> getTheListOfLiveChatIdsReceiver = sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[1]));
				if(getTheListOfLiveChatIdsReceiver.contains(roleAssignmentId)) {
					sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText("2b;;"+messageInfo[2]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
				} else {
					sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[1])).getAsyncRemote().sendText("2a;;"+messageInfo[2]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
				}
			}
		} else {
			/**
			 * RECEIVER IS OFFLINE
			 */
			session.getAsyncRemote().sendText("4c;; User went offline!...Message did not go.. Try after some time..;;"+messageInfo[1]);
		}
	}

	/**
	 * Sender MOBILE - Receiver MOBILE
	 * @param message
	 * @param roleAssignmentId
	 * @param nameOfUser
	 */
	public void sendToMobileReceiverFromMobileSender(String message, Long roleAssignmentId, String nameOfUser, Integer saveFlag) {
		System.out.println("------------------");
		System.out.println("came inside : sendToMobileReceiverFromMobileSender");
		System.out.println("------------------");
		/**
		 * SENDER MOBILE - RECEIVER MOBILE
		 */
		String[] messageInfo = message.split(Pattern.quote("|"));
		if (mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])) != null) {
			if (mobileSessoinRegistry.getTheSenderChatList(Long.parseLong(messageInfo[0])).size() < 1) {
				mobileSessoinRegistry.updateLiveChatReceiverHashMap(roleAssignmentId, Long.parseLong(messageInfo[0]));
				if(saveFlag == 1) {
					saveTheMessage(roleAssignmentId, Long.parseLong(messageInfo[0]), messageInfo[1], messageInfo[2]);
				}
				JSONObject messageobj = new JSONObject();
				try {
					String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
					messageobj.put("id", roleAssignmentId);
					messageobj.put("time", timeStamp);
					messageobj.put("message", messageInfo[1]);
					messageobj.put("flag", new Boolean(true));
					messageobj.put("name", nameOfUser + ":");
				} catch (Exception e) {
					e.printStackTrace();
				}
				mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText(messageobj.toString());
			} else {
				List<Long> receiverTalkingWith = mobileSessoinRegistry.getTheSenderChatList(Long.parseLong(messageInfo[0]));
				if(receiverTalkingWith.contains(roleAssignmentId)) {
					saveTheMessage(roleAssignmentId, Long.parseLong(messageInfo[0]), messageInfo[1], messageInfo[2]);
					JSONObject messageobj = new JSONObject();
					try {
						String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
						messageobj.put("id", roleAssignmentId);
						messageobj.put("time", timeStamp);
						messageobj.put("message", messageInfo[1]);
						messageobj.put("flag", new Boolean(true));
						messageobj.put("name", nameOfUser + ":");
					} catch (Exception e) {
						e.printStackTrace();
					}
					mobileSessoinRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText(messageobj.toString());
				} else {
					JSONObject messageobj = new JSONObject();
					try {
						String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
						messageobj.put("id", roleAssignmentId);
						messageobj.put("time", timeStamp);
						messageobj.put("message", messageInfo[1] + ". --USER BUSY");
						messageobj.put("flag", new Boolean(true));
					} catch (Exception e) {
						e.printStackTrace();
					}
					mobileSessoinRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText(messageobj.toString());
					System.out.println("clientdata" + messageInfo[0] + " is busy");
				}
			}
		} else {
			JSONObject messageobj = new JSONObject();
			try {
				messageobj.put("id", roleAssignmentId);
				String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH.mm").format(new Timestamp(System.currentTimeMillis()));
				messageobj.put("time", timeStamp);
				messageobj.put("message", "USER IS OFFLINE");
				messageobj.put("flag", new Boolean(true));
			} catch (Exception e) {
				e.printStackTrace();
			}
			mobileSessoinRegistry.getTheSessionOfReceiver(roleAssignmentId).getAsyncRemote().sendText(messageobj.toString());
		}
	}

	public void sendToWebReceiverFromMobileSender(String message, Long roleAssignmentId, String nameOfUser, Integer saveFlag) {
		System.out.println("------------------");
		System.out.println("came inside : sendToWebReceiverFromMobileSender");
		System.out.println("------------------");
		/**
		 * CODE for Integration of Mobile
		 * SENDER MOBILE - RECEIVER WEB
		 */
		/**
		 * code for sending message from mobile to web
		 */
		String[] messageInfo = message.split(Pattern.quote("|"));
		if(saveFlag == 1) {
			saveTheMessage(roleAssignmentId, Long.parseLong(messageInfo[0]), messageInfo[1], messageInfo[2]);
		}
		if(sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[0])).size() < 4) {
			/**
			 * RECEIVER IS NOT BUSY
			 */
			List<Long> getTheListOfLiveChatIdsReceiver = sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[0]));
			if(getTheListOfLiveChatIdsReceiver.contains(roleAssignmentId)) {
				/**
				 * RECEIVER IS ALREADY CHATTING WITH SENDER
				 */
				sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText("2b;;"+messageInfo[1]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
			} else {
				/**
				 * RECEIVER IS NOT CHATTING WITH SENDER BUT FREE TO TAKE MORE MESSAGES
				 */
				sessionRegistry.updateLiveChatReceiverHashMap(roleAssignmentId, Long.parseLong(messageInfo[0]));
				sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText("2a;;"+messageInfo[1]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
			}
		} else {
			List<Long> getTheListOfLiveChatIdsReceiver = sessionRegistry.getTheSenderChatList(Long.parseLong(messageInfo[0]));
			if(getTheListOfLiveChatIdsReceiver.contains(roleAssignmentId)) {
				sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText("2b;;"+messageInfo[1]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
			} else {
				sessionRegistry.getTheSessionOfReceiver(Long.parseLong(messageInfo[0])).getAsyncRemote().sendText("2a;;"+messageInfo[1]+";;"+roleAssignmentId+";;"+nameOfUser+";;"+messageInfo[3]);
			}
		}
	}
}
